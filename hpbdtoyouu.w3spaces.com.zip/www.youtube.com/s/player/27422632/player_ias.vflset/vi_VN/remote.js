(function(g) {
    var window = this;
    'use strict';
    var Z7f = function(K, W) {
            if (U_(K) && !K.U) {
                var U = null;
                W && (U = {
                    style: K.D.getSubtitlesUserSettings()
                }, Object.assign(U, W));
                K.fg.Im(K.D.getVideoData(1).videoId, U);
                K.W = h$(K.fg).trackData
            }
        },
        m4 = function(K, W) {
            return g.dG(K, function(U) {
                return j4(U, W)
            })
        },
        S4 = function() {
            return g.vB("yt.mdx.remote.connection_")
        },
        j4 = function(K, W) {
            return !!W && (K.id == W || K.uuid == W)
        },
        sP4 = function(K) {
            var W = {};
            W.pairingCode = K.DA;
            W.theme = K.tK;
            b7v() && (W.env_useStageMdx = 1);
            return g.NH(W)
        },
        XrF = function() {
            var K = fK(),
                W = t$();
            g.tA() && g.qP(K, W);
            K = VFj(K);
            if (K.length == 0) try {
                g.S2("remote_sid")
            } catch (U) {} else try {
                g.AQ("remote_sid", K.join(","), -1)
            } catch (U) {}
        },
        UqI = function(K, W) {
            var U = null;
            if (K.j == W) {
                GH(K);
                va4(K);
                K.j = null;
                var h = 2
            } else if (q0n(K.X, W)) U = W.uX, xjb(K.X, W), h = 1;
            else return;
            if (K.p_ != 0)
                if (W.G)
                    if (h == 1) {
                        U = W.jV ? W.jV.length : 0;
                        W = Date.now() - W.Ns;
                        var m = K.Ns;
                        h = CEO();
                        h.dispatchEvent(new l6F(h, U, W, m));
                        I7(K)
                    } else Ld3(K);
            else {
                var S = W.Qg;
                m = W.getLastError();
                if (m == 3 || m == 0 && S > 0 || !(h == 1 && K0t(K, W) || h == 2 && W0H(K))) switch (U && U.length > 0 && (W = K.X, W.N = W.N.concat(U)), m) {
                    case 1:
                        d7(K, 5);
                        break;
                    case 4:
                        d7(K, 10);
                        break;
                    case 3:
                        d7(K, 6);
                        break;
                    default:
                        d7(K, 2)
                }
            }
        },
        hNZ = function(K) {
            g.qE(K.jV);
            K.jV = g.FE(function() {
                K.z3(1)
            }, 864E5)
        },
        j1I = function(K) {
            J$(K);
            K.J && (g.qs.clearTimeout(K.J), K.J = null);
            GH(K);
            K.X.cancel();
            K.G && (typeof K.G === "number" && g.qs.clearTimeout(K.G), K.G = null)
        },
        mq4 = function(K, W) {
            return g.dG(K, function(U) {
                return U || W ? !U != !W ? !1 : U.id == W.id : !0
            })
        },
        SKF = function(K) {
            window.chrome && chrome.cast && chrome.cast.logMessage && chrome.cast.logMessage(K)
        },
        fbW = function(K) {
            g.SI("yt-remote-connected-devices", K, 86400)
        },
        GoO = function() {
            var K = g.Dk.wK();
            K && tE3(K, K.D1.Cv(!0))
        },
        IbZ = function(K) {
            if (K.X != null) return K.N.concat(K.X.uX);
            if (K.j != null && K.j.size !== 0) {
                var W = K.N;
                K = g.z(K.j.values());
                for (var U = K.next(); !U.done; U = K.next()) W = W.concat(U.value.uX);
                return W
            }
            return g.k4(K.N)
        },
        eNZ = function(K, W) {
            K.compatibleSenderThemes.clear();
            g.yb(W.split(","), g.jt(dqZ, J6t)).forEach(function(U) {
                K.compatibleSenderThemes.add(U)
            })
        },
        EEh = function() {},
        r6W = function(K, W) {
            var U = null;
            if (W) {
                var h = BlH(K);
                h && (U = {
                    clientName: h.clientName,
                    deviceMake: h.brand,
                    deviceModel: h.model,
                    osVersion: h.osVersion
                })
            }
            g.Vk("yt.mdx.remote.remoteClient_", U);
            W && (DqF(K), HX4(K));
            U = K.X.Kj() && isNaN(K.G);
            W == U ? W && (e4(K, 1), E_(K, "getSubtitlesTrack")) : W ? (K.IV() && K.j.reset(), e4(K, 1), E_(K, "getNowPlaying"), hNZ(K)) : K.z3(1)
        },
        abj = function(K) {
            g.wP.call(this, K);
            this.bA = {
                key: TlI(),
                name: "M\u00e1y t\u00ednh n\u00e0y"
            };
            this.gX = null;
            this.subscriptions = [];
            this.GW = this.fg = null;
            this.sS = [this.bA];
            this.UO = this.bA;
            this.RR = new g.Kw(64);
            this.Wc = 0;
            this.n_ = -1;
            this.Kd = !1;
            this.zz = this.En = this.We = null;
            if (!g.r8(this.player.V()) && !g.l1(this.player.V())) {
                K = this.player;
                var W = g.dK(K);
                W && (W = W.Es()) && (W = new B0(K, W), g.k(this, W));
                W = new Dw(K);
                g.k(this, W);
                g.HW(K, W.element, 4);
                this.We = new H0;
                g.k(this, this.We);
                g.HW(K, this.We.element, 4);
                this.Kd = !!r7()
            }
        },
        e4 = function(K, W) {
            K.publish("proxyStateChange",
                W)
        },
        r7 = function() {
            var K = g.tA();
            if (!K) return null;
            var W = TH();
            if (!W) return null;
            W = W.Ha();
            return m4(W, K)
        },
        Q1W = function(K) {
            return Array.isArray(K) ? g.CB(K, waj) : []
        },
        $qf = function(K, W) {
            var U = new a7;
            if (g.qs.Image) {
                var h = new Image;
                h.onload = g.jt(w7, U, "TestLoadImage: loaded", !0, W, h);
                h.onerror = g.jt(w7, U, "TestLoadImage: error", !1, W, h);
                h.onabort = g.jt(w7, U, "TestLoadImage: abort", !1, W, h);
                h.ontimeout = g.jt(w7, U, "TestLoadImage: timeout", !1, W, h);
                g.qs.setTimeout(function() {
                    if (h.ontimeout) h.ontimeout()
                }, 1E4);
                h.src = K
            } else W(!1)
        },
        tE3 = function(K, W) {
            YKb(K, W).forEach(function(U) {
                g.mI.prototype.remove.call(this, U)
            }, K)
        },
        OX4 = function(K) {
            return "chrome-extension://" + K + "/cast_sender.js"
        },
        c6h = function(K, W) {
            return new g.eF(K, W)
        },
        nEW = function(K, W, U) {
            var h = new Image;
            h.onload = function() {
                try {
                    Q9(h), U(!0)
                } catch (m) {}
            };
            h.onerror = function() {
                try {
                    Q9(h), U(!1)
                } catch (m) {}
            };
            h.onabort = function() {
                try {
                    Q9(h), U(!1)
                } catch (m) {}
            };
            h.ontimeout = function() {
                try {
                    Q9(h), U(!1)
                } catch (m) {}
            };
            g.qs.setTimeout(function() {
                if (h.ontimeout) h.ontimeout()
            }, W);
            h.src = K
        },
        $O = function(K, W) {
            var U = K.j;
            K.X && (U = K.scheme + "://" + K.domain + K.port + K.j);
            return g.sL(U + W, {})
        },
        O_ = function(K) {
            if (K.size != K.j.length) {
                for (var W = 0, U = 0; W < K.j.length;) {
                    var h = K.j[W];
                    YO(K.X, h) && (K.j[U++] = h);
                    W++
                }
                K.j.length = U
            }
            if (K.size != K.j.length) {
                W = {};
                for (h = U = 0; U < K.j.length;) {
                    var m = K.j[U];
                    YO(W, m) || (K.j[h++] = m, W[m] = 1);
                    U++
                }
                K.j.length = h
            }
        },
        l6F = function(K, W, U, h) {
            g.nO.call(this, "timingevent", K);
            this.size = W;
            this.rtt = U;
            this.retries = h
        },
        nK = function(K, W) {
            c0.call(this, K, W, "ManualSession");
            this.N = g.FE((0, g.wr)(this.Zz, this, null), 150)
        },
        F0O = function(K, W, U) {
            K.tK = 1;
            K.J = g7(W.clone());
            K.jV = U;
            K.hK = !0;
            gEW(K, null)
        },
        g7 = function(K) {
            g.aT(K, "zx", Math.floor(Math.random() * 2147483648).toString(36) + Math.abs(Math.floor(Math.random() * 2147483648) ^ g.hi()).toString(36));
            return K
        },
        kot = function(K, W) {
            var U = K.screens.length != W.length;
            K.screens = g.yb(K.screens, function(S) {
                return !!mq4(W, S)
            });
            for (var h = W.length, m = 0; m < h; m++) U = uJt(K, W[m]) || U;
            return U
        },
        iXj = function(K, W) {
            K.experiments.clear();
            W.split(",").forEach(function(U) {
                K.experiments.add(U)
            })
        },
        zNn = function(K, W) {
            this.j = K;
            this.map = W;
            this.context = null
        },
        MEW = function() {
            if (NlN) {
                var K = 2,
                    W = A6b(),
                    U = function() {
                        K--;
                        K == 0 && W && W(!0)
                    };
                window.__onGCastApiAvailable = U;
                RNn("//www.gstatic.com/cast/sdk/libs/sender/1.0/cast_framework.js", y6h, U)
            }
        },
        P0Z = function(K) {
            if (K instanceof g.Gl) return K;
            if (typeof K.Cv == "function") return K.Cv(!1);
            if (g.y3(K)) {
                var W = 0,
                    U = new g.Gl;
                U.next = function() {
                    for (;;) {
                        if (W >= K.length) return g.dg;
                        if (W in K) return g.JN(K[W++]);
                        W++
                    }
                };
                return U
            }
            throw Error("Not implemented");
        },
        Fv = function(K) {
            K || (g.HX("yt-remote-session-screen-id"), g.HX("yt-remote-session-video-id"));
            XrF();
            K = fK();
            g.sS(K, t$());
            fbW(K)
        },
        xjb = function(K, W) {
            K.X && K.X == W ? K.X = null : K.j && K.j.has(W) && K.j.delete(W)
        },
        uA = function(K, W) {
            g.p.call(this);
            this.j = new g.QC(this.bCs, 0, this);
            g.k(this, this.j);
            this.y6 = 5E3;
            this.QE = 0;
            if (typeof K === "function") W && (K = (0, g.wr)(K, W));
            else if (K && typeof K.handleEvent === "function") K = (0, g.wr)(K.handleEvent, K);
            else throw Error("Invalid listener argument");
            this.X = K
        },
        paO = function(K) {
            return g.CB(K, function(W) {
                return {
                    key: W.id,
                    name: W.name
                }
            })
        },
        kO = function(K) {
            return K ? '{name:"' + K.name + '",id:' + K.id.substr(0, 6) + "..,token:" + ((K.token ? ".." + K.token.slice(-6) : "-") + ",uuid:" + (K.uuid ? ".." + K.uuid.slice(-6) : "-") + ",idType:" + K.idType + ",secret:") + ((K.secret ? ".." + K.secret.slice(-6) : "-") + "}") : "null"
        },
        iA = function(K) {
            if (g.qs.JSON) try {
                return g.qs.JSON.parse(K)
            } catch (W) {}
            return oEI(K)
        },
        zH = function(K, W, U) {
            return U && U.ige ? U.ige[K] || W : W
        },
        ZXN = function() {
            return g.vB("yt.mdx.remote.channelParams_") || {}
        },
        bXZ = function(K, W) {
            for (var U = K.screens.length,
                    h = 0; h < U; ++h)
                if (K.screens[h].name == W) return K.screens[h];
            return null
        },
        NA = function(K) {
            K.N.CC() || K.eV || UqI(K.N, K)
        },
        J$ = function(K) {
            K.j && (va4(K), K.j.cancel(), K.j = null)
        },
        R7 = function(K, W, U) {
            var h = g.uF(U);
            if (h.j != "") W && g.Ld(h, W + "." + h.j), g.T7(h, h.N);
            else {
                var m = window.location;
                h = s1t(m.protocol, W ? W + "." + m.hostname : m.hostname, +m.port, U)
            }
            K.KS && g.hI(K.KS, function(S, f) {
                g.aT(h, f, S)
            });
            g.aT(h, "VER", K.K4);
            A$(K, h);
            return h
        },
        VE4 = function() {
            return g.SZ("yt-remote-local-screens") || []
        },
        Xaj = function() {
            g.SI("yt-remote-lounge-token-expiration", !0, 86400)
        },
        MA = function(K, W) {
            if (W == 2 || W == 9) {
                var U = null;
                K.rj && (U = null);
                var h = (0, g.wr)(K.H_V, K);
                U || (U = new g.FS("//www.google.com/images/cleardot.gif"), g7(U));
                nEW(U.toString(), 1E4, h)
            } else y9(2);
            vEN(K, W)
        },
        qKW = function() {
            P0("clearCurrentReceiver");
            g.HX("yt-remote-cast-receiver")
        },
        xqI = function(K) {
            return K.X ? !0 : K.j ? K.j.size >= K.W : !1
        },
        C03 = function(K, W, U) {
            if (g.y3(K)) g.tD(K, W, U);
            else
                for (K = P0Z(K);;) {
                    var h = K.next();
                    if (h.done) break;
                    W.call(U, h.value, void 0, K)
                }
        },
        pK = function(K, W) {
            lbj(g.CB(K.screens, L0I));
            W && Xaj()
        },
        K1f = function() {
            var K = o7();
            this.j = K;
            K.jD("/client_streamz/youtube/living_room/mdx/channel/closed", g.Mk("channel_type"))
        },
        Zw = function(K, W) {
            K.eV && g.hI(K.eV, function(U, h) {
                g.aT(W, h, U)
            });
            K.U && g.hI({}, function(U, h) {
                g.aT(W, h, U)
            })
        },
        hr4 = function(K, W) {
            if (W)
                if (K.K4 > 6) {
                    K.X = K.N.concat(K.X);
                    K.N.length = 0;
                    var U = K.F2 - 1;
                    W = W1I(K)
                } else U = W.Y, W = W.E2;
            else U = K.F2++, W = W1I(K);
            var h = K.fQ.clone();
            g.aT(h, "SID", K.W);
            g.aT(h, "RID", U);
            g.aT(h, "AID", K.RE);
            A$(K, h);
            U = new bA(K, K.W, U, K.IE + 1);
            U.w2 = K.Pa;
            U.setTimeout(1E4 + Math.round(1E4 * Math.random()));
            K.BS = U;
            U1v(U, h, W)
        },
        I7 = function(K) {
            xqI(K.X) || K.G || (K.G = !0, g.kK(K.Dm, K), K.Ns = 0)
        },
        TH = function() {
            if (!jhO) {
                var K = g.vB("yt.mdx.remote.screenService_");
                jhO = K ? new m1f(K) : null
            }
            return jhO
        },
        flb = function(K) {
            s_(K) && K.N.getDialAppInfo(function(W) {
                K.info("getDialAppInfo dialLaunchData: " + JSON.stringify(W));
                W = W.extraData || {};
                var U = null;
                if (W.loungeToken) {
                    var h;
                    ((h = K.j) == null ? void 0 : h.token) == W.loungeToken && (U = "staleLoungeToken")
                } else U = "missingLoungeToken";
                U ? (K.Ns = U, V9(K, 3E4)) : (K.uX = !1, K.Ns = "unknown", SDj(K, W.loungeToken), V9(K, W.loungeTokenRefreshIntervalMs))
            }, function(W) {
                K.info("getDialAppInfo error: " + W);
                K.Ns = "noLoungeTokenResponse";
                V9(K, 3E4)
            })
        },
        tDO = function() {
            var K = o7();
            this.j = K;
            K.jD("/client_streamz/youtube/living_room/mdx/browser_channel/undelivered_maps")
        },
        GWn = function(K, W) {
            return K === W
        },
        Xv = function(K) {
            K.publish("handlerOpened");
            K.Ik.Vh("BROWSER_CHANNEL")
        },
        wN4 = function(K, W) {
            W = W.message;
            W.params ? v0("Received: action=" + W.action + ", params=" + g.rc(W.params)) : v0("Received: action=" + W.action + " {}");
            switch (W.action) {
                case "loungeStatus":
                    W = iA(W.params.devices);
                    K.N = g.CB(W, function(h) {
                        return new qA(h)
                    });
                    W = !!g.dG(K.N, function(h) {
                        return h.type == "LOUNGE_SCREEN"
                    });
                    r6W(K, W);
                    W = K.l8("mlm");
                    K.publish("multiStateLoopEnabled", W);
                    break;
                case "loungeScreenDisconnected":
                    g.Br(K.N, function(h) {
                        return h.type == "LOUNGE_SCREEN"
                    });
                    r6W(K, !1);
                    break;
                case "remoteConnected":
                    var U = new qA(iA(W.params.device));
                    g.dG(K.N, function(h) {
                        return h.equals(U)
                    }) || Ilb(K.N, U);
                    break;
                case "remoteDisconnected":
                    U = new qA(iA(W.params.device));
                    g.Br(K.N, function(h) {
                        return h.equals(U)
                    });
                    break;
                case "gracefulDisconnect":
                    break;
                case "playlistModified":
                    d14(K, W, "QUEUE_MODIFIED");
                    break;
                case "nowPlaying":
                    JM4(K, W);
                    break;
                case "onStateChange":
                    erH(K, W);
                    break;
                case "onAdStateChange":
                    E2f(K, W);
                    break;
                case "onVolumeChanged":
                    BvZ(K, W);
                    break;
                case "onSubtitlesTrackChanged":
                    D1Z(K, W);
                    break;
                case "nowAutoplaying":
                    HGZ(K, W);
                    break;
                case "autoplayDismissed":
                    K.publish("autoplayDismissed");
                    break;
                case "autoplayUpNext":
                    rMH(K, W);
                    break;
                case "onAutoplayModeChanged":
                    Tv3(K, W);
                    break;
                case "onHasPreviousNextChanged":
                    al3(K,
                        W);
                    break;
                case "requestAssistedSignIn":
                    K.publish("assistedSignInRequested", W.params.authCode);
                    break;
                case "onLoopModeChanged":
                    K.publish("loopModeChange", W.params.loopMode);
                    break;
                default:
                    v0("Unrecognized action: " + W.action)
            }
        },
        xO = function(K) {
            K.length ? RNn(K.shift(), function() {
                xO(K)
            }) : y6h()
        },
        QhW = function(K) {
            g.nO.call(this, "statevent", K)
        },
        s1t = function(K, W, U, h) {
            var m = new g.FS(null);
            K && g.WS(m, K);
            W && g.Ld(m, W);
            U && g.T7(m, U);
            h && (m.X = h);
            return m
        },
        $1F = function(K, W) {
            K.j ? K.j.add(W) : K.X = W
        },
        Q9 = function(K) {
            K.onload = null;
            K.onerror = null;
            K.onabort = null;
            K.ontimeout = null
        },
        d7 = function(K, W) {
            if (W == 2) {
                var U = (0, g.wr)(K.nqU, K),
                    h = K.Dp,
                    m = !h;
                h = new g.FS(h || "//www.google.com/images/cleardot.gif");
                g.qs.location && g.qs.location.protocol == "http" || g.WS(h, "https");
                g7(h);
                m ? $qf(h.toString(), U) : YDh(h.toString(), U)
            } else CK(2);
            K.p_ = 0;
            K.U && K.U.Lb(W);
            OG3(K);
            j1I(K)
        },
        lA = function(K) {
            var W = CEO();
            W.dispatchEvent(new cMH(W, K))
        },
        GH = function(K) {
            K.Ms != null && (g.qs.clearTimeout(K.Ms), K.Ms = null)
        },
        n2W = function(K) {
            K.audioTrackId = null;
            K.trackData = null;
            K.playerState = -1;
            K.cM = !1;
            K.zP = !1;
            K.G = 0;
            K.U = g.hi();
            K.X = 0;
            K.Y = 0;
            K.N = 0;
            K.J = 0;
            K.j = NaN;
            K.W = !1
        },
        a7 = function() {},
        u33 = function() {
            var K = g2b();
            !K && LK() && F1W() && (K = {
                key: "cast-selector-receiver",
                name: F1W()
            });
            return K
        },
        bA = function(K, W, U, h) {
            this.j = K;
            this.W = W;
            this.Y = U;
            this.G = h || 1;
            this.X = 45E3;
            this.N = new g.wv(this);
            this.U = new g.j8;
            this.U.setInterval(250)
        },
        YO = function(K, W) {
            return Object.prototype.hasOwnProperty.call(K, W)
        },
        zrN = function() {
            P0("dispose");
            var K = Ks();
            K && K.dispose();
            g.Vk("yt.mdx.remote.cloudview.instance_", null);
            kWH(!1);
            g.Df(iGb);
            iGb.length = 0
        },
        W9 = function(K, W) {
            g.kh[K] = !0;
            var U = g.Rz();
            U && U.publish.apply(U, arguments);
            g.kh[K] = !1
        },
        UO = function(K, W, U, h) {
            c0.call(this, K, W, "DialSession");
            this.config_ = h;
            this.N = this.J = null;
            this.DA = "";
            this.tK = U;
            this.Le = null;
            this.Ms = function() {};
            this.jV = NaN;
            this.eV = (0, g.wr)(this.xb, this);
            this.U = function() {};
            this.Y = this.G = 0;
            this.uX = !1;
            this.Ns = "unknown"
        },
        NvH = function() {
            g.nO.call(this, "p")
        },
        AM3 = function(K) {
            return K.X ? 1 : K.j ? K.j.size : 0
        },
        CEO = function() {
            return RrI = RrI || new g.Uj
        },
        yMj = function() {
            var K = r7();
            K ? (hz("Resume connection to: " + kO(K)), jM(K, 0)) : (Fv(), qKW(), hz("Skipping connecting because no session screen found."))
        },
        SM = function(K) {
            m_("cloudview", K)
        },
        v0 = function(K) {
            m_("conn", K)
        },
        A6b = function() {
            return typeof window.__onGCastApiAvailable == "function" ? window.__onGCastApiAvailable : null
        },
        L0I = function(K) {
            return {
                name: K.name,
                screenId: K.id,
                loungeToken: K.token,
                dialId: K.uuid,
                screenIdType: K.idType,
                screenIdSecret: K.secret
            }
        },
        W1I = function(K) {
            var W = Math.min(K.X.length, 1E3),
                U = ["count=" + W];
            if (K.K4 > 6 && W > 0) {
                var h = K.X[0].j;
                U.push("ofs=" + h)
            } else h = 0;
            for (var m = {}, S = 0; S < W; m = {
                    oG: void 0
                }, S++) {
                m.oG = K.X[S].j;
                var f = K.X[S].map;
                m.oG = K.K4 <= 6 ? S : m.oG - h;
                try {
                    g.hI(f, function(G) {
                        return function(I, d) {
                            U.push("req" + G.oG + "_" + d + "=" + encodeURIComponent(I))
                        }
                    }(m))
                } catch (G) {
                    U.push("req" + m.oG + "_type=" + encodeURIComponent("_badmap"))
                }
            }
            K.N = K.N.concat(K.X.splice(0, W));
            return U.join("&")
        },
        BlH = function(K) {
            return g.dG(K.N, function(W) {
                return W.type == "LOUNGE_SCREEN"
            })
        },
        fs = function(K, W, U) {
            K.EN = K.G == null ? U : !K.G;
            K.df = W.Pg;
            K.J || MDb(K)
        },
        tz = function(K) {
            K = K || {};
            this.name = K.name || "";
            this.id = K.id || K.screenId || "";
            this.token = K.token || K.loungeToken || "";
            this.uuid = K.uuid || K.dialId || "";
            this.idType = K.screenIdType || "normal";
            this.secret = K.screenIdSecret || ""
        },
        PpH = function(K) {
            K.G = g.FE(function() {
                v0("Connecting timeout");
                K.z3(1)
            }, 2E4)
        },
        shh = function(K) {
            pNZ(K);
            K.X = new Gu(K.W);
            K.X.subscribe("screenChange", (0, g.wr)(K.Y5p, K));
            o2b(K);
            K.Y || (K.N = Q1W(g.SZ("yt-remote-automatic-screen-cache") || []));
            pNZ(K);
            K.info("Initializing automatic screens: " + ZGh(K.N));
            K.j = new bGF(K.W, (0, g.wr)(K.Ha, K, !0));
            K.j.subscribe("screenChange", (0, g.wr)(function() {
                this.publish("onlineScreenChange")
            }, K))
        },
        XNI = function(K) {
            return g.Bz(K.tK().then(function(W) {
                VDO(K, W)
            }).Df(function() {}), function() {
                K.DA = null
            })
        },
        L1n = function(K, W, U) {
            var h = this;
            U = U === void 0 ? function() {
                return ""
            } : U;
            var m = m === void 0 ? new v2F : m;
            var S = S === void 0 ? new g.fj : S;
            this.pathPrefix = K;
            this.j = W;
            this.Ns = U;
            this.U = S;
            this.J = null;
            this.jV = this.Y = 0;
            this.channel = null;
            this.G = 0;
            this.N = new uA(function() {
                h.N.isActive();
                var f;
                ((f = h.channel) == null ? void 0 : AM3((new qDj(f, f.j)).j.X)) === 0 && h.connect(h.J, h.Y)
            });
            this.W = {};
            this.X = {};
            this.Ms = !1;
            this.logger = null;
            this.uX = [];
            this.Bo = void 0;
            this.Le = new x1f;
            this.DA = new K1f;
            this.eV = new CpO;
            this.hK = new llt
        },
        KAv = function(K, W, U) {
            U = Math.min(K.N.length, U);
            var h = K.U ? (0, g.wr)(K.U.A4, K.U, K) : null;
            a: {
                for (var m = K.N, S = -1;;) {
                    var f = ["count=" + U];
                    S == -1 ? U > 0 ? (S = m[0].j, f.push("ofs=" + S)) : S = 0 : f.push("ofs=" + S);
                    for (var G = !0, I = 0; I < U; I++) {
                        var d = m[I].j,
                            J = m[I].map;
                        d -= S;
                        if (d < 0) S = Math.max(0, m[I].j - 100), G = !1;
                        else try {
                            d = "req" + d + "_" || "";
                            try {
                                var e = J instanceof Map ? J : Object.entries(J);
                                for (var E = g.z(e), B = E.next(); !B.done; B = E.next()) {
                                    var D = g.z(B.value),
                                        a = D.next().value,
                                        Q = D.next().value,
                                        u = Q;
                                    g.SG(Q) && (u = g.rc(Q));
                                    f.push(d + a + "=" + encodeURIComponent(u))
                                }
                            } catch (O) {
                                throw f.push(d + "type=" +
                                    encodeURIComponent("_badmap")), O;
                            }
                        } catch (O) {
                            h && h(J)
                        }
                    }
                    if (G) {
                        e = f.join("&");
                        break a
                    }
                }
                e = void 0
            }
            K = K.N.splice(0, U);
            W.uX = K;
            return e
        },
        Gu = function(K) {
            IB.call(this, "LocalScreenService");
            this.X = K;
            this.j = NaN;
            dm(this);
            this.info("Initializing with " + ZGh(this.screens))
        },
        WAn = function(K) {
            this.j = K;
            this.X = new Jz
        },
        UJv = function(K) {
            K.U = K.W.Ed(K.DA, K.X.label, K.X.friendlyName, s_(K), function(W, U) {
                K.U = function() {};
                K.uX = !0;
                eM(K, W);
                W.idType == "shortLived" && U > 0 && V9(K, U)
            }, function(W) {
                K.U = function() {};
                K.uK(W)
            })
        },
        h_3 = function(K) {
            K.aA && (K.aA.abort(), K.aA = null);
            K.NZ && (K.NZ.cancel(), K.NZ = null);
            K.cg && (g.qs.clearTimeout(K.cg), K.cg = null);
            EO(K);
            K.BS && (K.BS.cancel(), K.BS = null);
            K.F4 && (g.qs.clearTimeout(K.F4), K.F4 = null)
        },
        jHI = function() {
            var K = o7();
            this.j = K;
            K.jD("/client_streamz/youtube/living_room/mdx/browser_channel/pending_maps")
        },
        mJn = function(K) {
            g.Vk("yt.mdx.remote.currentScreenId_", K)
        },
        Sjf = function(K) {
            g.tD("nowAutoplaying autoplayDismissed remotePlayerChange remoteQueueChange autoplayModeChange autoplayUpNext previousNextChange multiStateLoopEnabled loopModeChange".split(" "), function(W) {
                this.G.push(this.W.subscribe(W, g.jt(this.DbH, W), this))
            }, K)
        },
        fgh = function() {
            var K = S4();
            return !!K && K.getProxyState() != 3
        },
        B9 = function(K, W, U) {
            c0.call(this, K, W, "CastSession");
            var h = this;
            this.config_ = U;
            this.N = null;
            this.uX = (0, g.wr)(this.Pk, this);
            this.DA = (0, g.wr)(this.HCx, this);
            this.Ms = g.FE(function() {
                t8N(h, null)
            }, 12E4);
            this.Y = this.U = this.G = this.J = 0;
            this.Ns = !1;
            this.jV = "unknown"
        },
        Jih = function(K, W, U, h, m) {
            G$b(K);
            if (K.j) {
                var S = g.TA("ID_TOKEN"),
                    f = K.j.Pa || {};
                S ? f["x-youtube-identity-token"] = S : delete f["x-youtube-identity-token"];
                K.j.Pa = f
            }
            IgH(K);
            h ? (h.getState() != 3 && dJf(h) == 0 || h.getState(), K.j.connect(W, U, K.Ms, h.W, h.RE)) : m ? K.j.connect(W, U, K.Ms, m.sessionId, m.arrayId) : K.j.connect(W, U, K.Ms)
        },
        e_W = function(K, W, U) {
            var h = g.uF(U);
            h.j != "" ? (W && g.Ld(h, W + "." + h.j), g.T7(h, h.N)) : (h = g.qs.location, h = s1t(h.protocol, W ? W + "." + h.hostname : h.hostname, +h.port, U));
            W = K.hK;
            U = K.bG;
            W && U && g.aT(h, W, U);
            g.aT(h, "VER", K.Ud);
            Zw(K, h);
            return h
        },
        ERj = function(K) {
            var W = K.player.V();
            return !W.L("mdx_enable_privacy_disclosure_ui") || K.isLoggedIn() || K.Kd || !K.We ? !1 : g.YC(W) || g.Hh(W)
        },
        Htf = function() {
            MEW();
            var K = Bn4();
            K.push.apply(K, g.z4(DJW.map(OX4)));
            K.push("//www.gstatic.com/eureka/clank/cast_sender.js");
            xO(K)
        },
        rin = function(K, W) {
            if (K.Ka != null) throw Error("WatchDog timer not null");
            K.Ka = DZ((0, g.wr)(K.Bk, K), W)
        },
        Tnv = function() {
            var K = TH().di.$_gos();
            var W = H9();
            W && S4() && (mq4(K, W) || K.push(W));
            return paO(K)
        },
        VFj = function(K) {
            if (K.length == 0) return [];
            var W = K[0].indexOf("#"),
                U = W == -1 ? K[0] : K[0].substring(0, W);
            return g.CB(K, function(h, m) {
                return m == 0 ? h : h.substring(U.length)
            })
        },
        ag4 = function(K, W) {
            this.action = K;
            this.params = W || {}
        },
        QHN = function(K) {
            g.p4(K.channel, "m", function() {
                K.G = 3;
                K.N.reset();
                K.J = null;
                K.Y = 0;
                for (var W = g.z(K.uX), U = W.next(); !U.done; U = W.next()) U = U.value, K.channel && K.channel.send(U);
                K.uX = [];
                K.publish("webChannelOpened");
                K.Le.Vh("WEB_CHANNEL")
            });
            g.p4(K.channel, "n", function() {
                K.G = 0;
                K.N.isActive() || K.publish("webChannelClosed");
                var W, U = (W = K.channel) == null ? void 0 : wyN(new qDj(W, W.j));
                U && (K.uX = [].concat(g.z4(U)));
                K.DA.Vh("WEB_CHANNEL")
            });
            g.p4(K.channel, "p", function(W) {
                var U = W.data;
                U[0] === "gracefulReconnect" ? (K.N.start(), K.channel && K.channel.close()) : K.publish("webChannelMessage", new ag4(U[0], U[1]));
                K.Bo = W.statusCode;
                K.eV.Vh("WEB_CHANNEL")
            });
            g.p4(K.channel, "o", function() {
                K.Bo === 401 || K.N.start();
                K.publish("webChannelError");
                K.hK.Vh("WEB_CHANNEL", "")
            })
        },
        $JI = function(K) {
            var W = S4();
            rm(null);
            K || mJn("");
            g.Vk("yt.mdx.remote.connection_", K);
            Tu && (g.tD(Tu, function(U) {
                U(K)
            }), Tu.length = 0);
            W && !K ? W9("yt-remote-connection-change", !1) : !W && K && W9("yt-remote-connection-change", !0)
        },
        Yjh = function(K) {
            K.Ms && (g.qs.clearTimeout(K.Ms), K.Ms = null)
        },
        Tv3 = function(K, W) {
            K.U = W.params.autoplayMode;
            K.publish("autoplayModeChange", K.U);
            K.U == "DISABLED" && K.publish("autoplayDismissed")
        },
        aB = function(K, W) {
            var U = K.U;
            U.j.length + U.X.length < 50 && K.U.enqueue(W)
        },
        Q0 = function(K, W) {
            wm() ? Ks().setConnectedScreenStatus(K, W) : SM("setConnectedScreenStatus called before ready.")
        },
        Otv = function(K) {
            g.qE(K.uX);
            K.uX = NaN
        },
        cif = function(K, W, U, h, m) {
            if (h == 0) U(!1);
            else {
                var S = m || 0;
                h--;
                nEW(K, W, function(f) {
                    f ? U(!0) : g.qs.setTimeout(function() {
                        cif(K, W, U, h, S)
                    }, S)
                })
            }
        },
        nRZ = function() {
            var K = o7();
            this.j = K;
            K.jD("/client_streamz/youtube/living_room/mdx/channel/success")
        },
        gRn = function(K, W) {
            try {
                K.j.qT(K, W), K.j.Cn(4)
            } catch (U) {}
        },
        FAW = function(K) {
            g.nO.call(this, "channelMessage");
            this.message = K
        },
        Yt = function(K, W) {
            g.Uj.call(this);
            this.j = new uIN(W);
            this.U = K;
            this.X = W && W.c7k || null;
            K = W && W.fOx || null;
            W && W.Ur5 && (K ? K["X-Client-Protocol"] = "webchannel" : K = {
                "X-Client-Protocol": "webchannel"
            });
            this.j.jV = K;
            K = W && W.Uos || null;
            W && W.R_ && (K ? K["X-WebChannel-Content-Type"] = W.R_ : K = {
                "X-WebChannel-Content-Type": W.R_
            });
            W && W.kp && (K ? K["X-WebChannel-Client-Profile"] = W.kp : K = {
                "X-WebChannel-Client-Profile": W.kp
            });
            this.j.W3 = K;
            (K = W && W.hRH) && !g.YD(K) && (this.j.Y = K);
            this.G = W && W.O_k || !1;
            this.W = W && W.dIX || !1;
            (W = W && W.fAe) && !g.YD(W) && (this.j.hK = W, g.r5(this.X, W) && (K =
                this.X, W in K && delete K[W]));
            this.N = new $t(this)
        },
        k$n = function(K, W) {
            if (K.Ms != null) throw Error("WatchDog timer not null");
            K.Ms = OO((0, g.wr)(K.Yb, K), W)
        },
        Ait = function(K, W, U, h, m) {
            function S() {
                return new it3($O(K, "/bc"), W, !1, U, h)
            }
            U = U === void 0 ? function() {
                return ""
            } : U;
            return g.hc("enable_mdx_web_channel_desktop") ? new z_Z(function() {
                return new L1n($O(K, "/wc"), W, U)
            }) : new NnI(S, m)
        },
        R_O = function() {
            MEW();
            var K = Bn4();
            K.push("//www.gstatic.com/eureka/clank/cast_sender.js");
            xO(K)
        },
        d14 = function(K, W, U) {
            var h = W.params.videoId || W.params.video_id,
                m = parseInt(W.params.currentIndex, 10);
            K.j.listId = W.params.listId || K.j.listId;
            c9(K.j, h, m);
            K.publish("remoteQueueChange", U)
        },
        Jz = function() {},
        cMH = function(K) {
            g.nO.call(this, "serverreachability", K)
        },
        oEI = function(K) {
            try {
                return g.qs.JSON.parse(K)
            } catch (W) {}
            K = String(K);
            if (/^\s*$/.test(K) ? 0 : /^[\],:{}\s\u2028\u2029]*$/.test(K.replace(/\\["\\\/bfnrtu]/g, "@").replace(/(?:"[^"\\\n\r\u2028\u2029\x00-\x08\x0a-\x1f]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?)[\s\u2028\u2029]*(?=:|,|]|}|$)/g, "]").replace(/(?:^|:|,)(?:[\s\u2028\u2029]*\[)+/g, ""))) try {
                return eval("(" + K + ")")
            } catch (W) {}
            throw Error("Invalid JSON string: " + K);
        },
        al3 = function(K, W) {
            var U = W.params.hasNext == "true";
            K.j.cM = W.params.hasPrevious == "true";
            K.j.zP = U;
            K.publish("previousNextChange")
        },
        TlI = function() {
            return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function(K) {
                var W = Math.random() * 16 | 0;
                return (K == "x" ? W : W & 3 | 8).toString(16)
            })
        },
        PVW = function(K, W) {
            var U = K.Rs,
                h = W.indexOf("\n", U);
            if (h == -1) return yiZ;
            U = Number(W.substring(U, h));
            if (isNaN(U)) return M8W;
            h += 1;
            if (h + U > W.length) return yiZ;
            W = W.slice(h, h + U);
            K.Rs = h + U;
            return W
        },
        uJt = function(K, W) {
            var U = K.get(W.uuid) || K.get(W.id);
            if (U) return K = U.name, U.id = W.id || U.id, U.name = W.name, U.token = W.token, U.uuid = W.uuid || U.uuid, U.name != K;
            K.screens.push(W);
            return !0
        },
        pyZ = function(K) {
            K.j = new ns(K, K.W, "rpc", K.q5);
            K.Y === null && (K.j.Le = K.jV);
            K.j.Pp = 0;
            var W = K.Ea.clone();
            g.aT(W, "RID", "rpc");
            g.aT(W, "SID", K.W);
            g.aT(W, "AID", K.tK);
            g.aT(W, "CI", K.Bp ? "0" : "1");
            !K.Bp && K.AS && g.aT(W, "TO", K.AS);
            g.aT(W, "TYPE", "xmlhttp");
            Zw(K, W);
            K.Y && K.jV && g.w_(W, K.Y, K.jV);
            K.Pp && K.j.setTimeout(K.Pp);
            var U = K.j;
            K = K.Cg;
            U.tK = 1;
            U.J = g7(W.clone());
            U.jV = null;
            U.hK = !0;
            gEW(U, K)
        },
        H9 = function() {
            var K = gm();
            if (!K) return null;
            var W = TH().Ha();
            return m4(W, K)
        },
        A$ = function(K, W) {
            K.rj && (K = K.rj.VW()) && g.hI(K, function(U, h) {
                g.aT(W, h, U)
            })
        },
        oRZ = function(K) {
            K.j.CC() || K.Jo || K.j.ma(K)
        },
        hz = function(K) {
            m_("remote", K)
        },
        btj = function(K) {
            if (K.NZ || K.cg || K.FZ >= 3) return !1;
            K.Y++;
            K.cg = DZ((0, g.wr)(K.Zm, K), Zth(K, K.FZ));
            K.FZ++;
            return !0
        },
        F6 = function(K, W) {
            K.G = W;
            K.U = g.hi()
        },
        V8j = function(K, W) {
            K.w8 = Date.now();
            sHN(K);
            K.KQ = K.By.clone();
            uM(K.KQ, "t", K.G);
            K.Rs = 0;
            K.BN = K.j.nI(K.j.Eg() ? W : null);
            K.DK > 0 && (K.E$ = new g.VF((0, g.wr)(K.kf, K, K.BN), K.DK));
            K.N.listen(K.BN, "readystatechange", K.J4);
            W = K.w2 ? g.Ni(K.w2) : {};
            K.E2 ? (K.Is = "POST", W["Content-Type"] = "application/x-www-form-urlencoded", K.BN.send(K.KQ, K.Is, K.E2, W)) : (K.Is = "GET", K.i6 && !g.$U && (W.Connection = "close"), K.BN.send(K.KQ, K.Is, null, W));
            K.j.Cn(1)
        },
        Xyf = function(K, W, U, h, m) {
            K.F3 = 1;
            K.By = g7(W.clone());
            K.E2 = null;
            K.hK = U;
            m && (K.i6 = !1);
            V8j(K, h)
        },
        kt = function(K) {
            return K.isPlaying() ? (g.hi() - K.U) / 1E3 : 0
        },
        G$b = function(K) {
            if (K.j) {
                var W = K.eV(),
                    U = K.j.Pa || {};
                W ? U["x-youtube-lounge-xsrf-token"] = W : delete U["x-youtube-lounge-xsrf-token"];
                K.j.Pa = U
            }
        },
        vRW = function(K, W) {
            g.S$.call(this, K);
            this.j = W
        },
        iM = function(K, W, U) {
            W != K.j && (g.vZ(K.j), (K.j = W) ? (U ? K.publish("yt-remote-cast2-receiver-resumed", W.X) : K.publish("yt-remote-cast2-receiver-selected", W.X), W.subscribe("sessionScreen", (0, g.wr)(K.fD, K, W)), W.subscribe("sessionFailed", function() {
                return qjN(K, W)
            }), W.j ? K.publish("yt-remote-cast2-session-change", W.j) : U && K.j.Zz(null)) : K.publish("yt-remote-cast2-session-change", null))
        },
        OG3 = function(K) {
            K.p_ = 0;
            K.DO = [];
            if (K.U) {
                var W = IbZ(K.X);
                if (W.length != 0 || K.N.length != 0) g.Ms(K.DO, W), g.Ms(K.DO, K.N), K.X.N.length = 0, g.k4(K.N), K.N.length = 0;
                K.U.Hw()
            }
        },
        xJn = function(K, W) {
            var U;
            W ? U = W.Cg : U = K.JK++;
            var h = K.Le.clone();
            g.aT(h, "SID", K.W);
            g.aT(h, "RID", U);
            g.aT(h, "AID", K.tK);
            Zw(K, h);
            K.Y && K.jV && g.w_(h, K.Y, K.jV);
            U = new ns(K, K.W, U, K.Ns + 1);
            K.Y === null && (U.Le = K.jV);
            W && (K.N = W.uX.concat(K.N));
            W = KAv(K, U, 1E3);
            U.setTimeout(Math.round(K.Iu * .5) + Math.round(K.Iu * .5 * Math.random()));
            $1F(K.X, U);
            F0O(U, h, W)
        },
        VDO = function(K, W) {
            if (K.j) {
                var U = K.j.Pa || {};
                W && Object.keys(W).length > 0 ? U = Object.assign({}, U, W) : delete U.Authorization;
                K.j.Pa = U
            }
        },
        CVh = function(K, W, U) {
            var h = h$(K);
            F6(h, U);
            h.playerState != -1E3 && (h.playerState = W);
            zu(K, h)
        },
        D1Z = function(K, W) {
            var U = W.params.videoId;
            delete W.params.videoId;
            U == K.j.videoId && (g.Tb(W.params) ? K.j.trackData = null : K.j.trackData = W.params, K.publish("remotePlayerChange"))
        },
        lgn = function() {
            this.N = null;
            this.j = "";
            this.X = !1
        },
        Nu = function(K) {
            m_("CP", K)
        },
        W9h = function(K, W, U, h, m, S) {
            K.info("getAutomaticScreenByIds " + U + " / " + W);
            U || (U = K.U[W]);
            var f = K.Ha(),
                G = U ? m4(f, U) : null;
            U && (K.Y || G) || (G = m4(f, W));
            if (G) {
                G.uuid = W;
                var I = Az(K, G);
                LAh(K.j, I, function(d) {
                    m(d ? I : null)
                })
            } else U ? K9t(K, U, (0, g.wr)(function(d) {
                var J = Az(this, new tz({
                    name: h,
                    screenId: U,
                    loungeToken: d,
                    dialId: W || ""
                }));
                LAh(this.j, J, function(e) {
                    m(e ? J : null)
                })
            }, K), S) : m(null)
        },
        UtO = function(K, W) {
            var U = K.Ev + Math.floor(Math.random() * K.rS);
            K.isActive() || (U *= 2);
            return U * W
        },
        jyn = function(K, W, U) {
            g.p.call(this);
            var h = this;
            this.j = K;
            this.D = W;
            this.fg = U;
            this.events = new g.Te(this);
            this.U = !1;
            this.G = new g.Kw(64);
            this.X = new g.QC(this.qx, 500, this);
            this.N = new g.QC(this.tb, 1E3, this);
            this.J = new RB(this.fce, 0, this);
            this.W = {};
            this.jV = new g.QC(this.Zn, 1E3, this);
            this.Y = new g.VF(this.seekTo, 1E3, this);
            this.Ms = this.events.S(this.D, "onVolumeChange", function(m) {
                hgj(h, m)
            });
            g.k(this, this.events);
            this.events.S(W, "onCaptionsTrackListChanged", this.W1K);
            this.events.S(W, "captionschanged", this.eAp);
            this.events.S(W, "captionssettingschanged", this.sI);
            this.events.S(W, "videoplayerreset", this.xQ);
            this.events.S(W, "mdxautoplaycancel", function() {
                h.fg.CL()
            });
            W.L("enable_mdx_video_play_directly") && this.events.S(W, "videodatachange", function() {
                ERj(h.j) || U_(h) || y0(h, 0)
            });
            K = this.fg;
            K.qs();
            K.subscribe("proxyStateChange", this.Il, this);
            K.subscribe("remotePlayerChange", this.dw, this);
            K.subscribe("remoteQueueChange", this.xQ, this);
            K.subscribe("previousNextChange", this.w7, this);
            K.subscribe("nowAutoplaying", this.v6, this);
            K.subscribe("autoplayDismissed", this.hN, this);
            g.k(this, this.X);
            g.k(this, this.N);
            g.k(this, this.J);
            g.k(this, this.jV);
            g.k(this, this.Y);
            this.sI();
            this.xQ();
            this.dw()
        },
        qjN = function(K, W) {
            K.j == W && K.publish("yt-remote-cast2-session-failed")
        },
        mt3 = function() {
            var K = window.navigator.userAgent.match(/Chrome\/([0-9]+)/);
            return K ? parseInt(K[1], 10) : 0
        },
        Mu = function(K, W) {
            W = W === void 0 ? !1 : W;
            IB.call(this, "ScreenService");
            this.W = K;
            this.Y = W;
            this.j = this.X = null;
            this.N = [];
            this.U = {};
            shh(this)
        },
        S2n = function(K) {
            K.Ka && (g.qs.clearTimeout(K.Ka), K.Ka = null)
        },
        jM = function(K, W) {
            gm();
            H9() && H9();
            if (P9) ps = K;
            else {
                mJn(K.id);
                var U = g.vB("yt.mdx.remote.enableConnectWithInitialState_") || !1;
                K = new oB(ZZ, K, ZXN(), U);
                K.connect(W, fWO());
                K.subscribe("beforeDisconnect", function(h) {
                    W9("yt-remote-before-disconnect", h)
                });
                K.subscribe("beforeDispose", function() {
                    S4() && (S4(), $JI(null))
                });
                K.subscribe("browserChannelAuthError", function() {
                    var h = H9();
                    h && h.idType == "shortLived" && (wm() ? Ks().handleBrowserChannelAuthError() : SM("refreshLoungeToken called before API ready."))
                });
                $JI(K)
            }
        },
        v2F = function() {},
        tS4 = function(K, W) {
            var U = !1;
            Ks() || (K = new bM(K, W), K.subscribe("yt-remote-cast2-availability-change", function(h) {
                g.SI("yt-remote-cast-available", h);
                W9("yt-remote-cast2-availability-change", h)
            }), K.subscribe("yt-remote-cast2-receiver-selected", function(h) {
                P0("onReceiverSelected: " + h.friendlyName);
                g.SI("yt-remote-cast-receiver", h);
                W9("yt-remote-cast2-receiver-selected", h)
            }), K.subscribe("yt-remote-cast2-receiver-resumed", function(h) {
                P0("onReceiverResumed: " + h.friendlyName);
                g.SI("yt-remote-cast-receiver", h);
                W9("yt-remote-cast2-receiver-resumed", h)
            }), K.subscribe("yt-remote-cast2-session-change", function(h) {
                P0("onSessionChange: " + kO(h));
                h || g.HX("yt-remote-cast-receiver");
                W9("yt-remote-cast2-session-change", h)
            }), g.Vk("yt.mdx.remote.cloudview.instance_", K), U = !0);
            P0("cloudview.createSingleton_: " + U);
            return U
        },
        BvZ = function(K, W) {
            var U = W.params.muted == "true";
            K.j.volume = parseInt(W.params.volume, 10);
            K.j.muted = U;
            K.publish("remotePlayerChange")
        },
        c0 = function(K, W, U) {
            g.GP.call(this);
            this.hK = U;
            this.W = K;
            this.X = W;
            this.j = null
        },
        y0 = function(K, W) {
            var U = K.D.getPlaylist();
            if (U == null ? 0 : U.listId) {
                var h = U.index;
                var m = U.listId.toString()
            }
            U = K.D.getVideoData(1);
            K.fg.playVideo(U.videoId, W, h, m, U.playerParams, U.Ms, G7f(U));
            K.uY(new g.Kw(1))
        },
        JM4 = function(K, W) {
            W.params = W.params || {};
            d14(K, W, "NOW_PLAYING_MAY_CHANGE");
            erH(K, W);
            K.publish("autoplayDismissed")
        },
        EO = function(K) {
            K.Fq != null && (g.qs.clearTimeout(K.Fq), K.Fq = null)
        },
        IWH = function(K, W, U, h, m) {
            g.GP.call(this);
            this.N = K;
            this.Y = W;
            this.W = U;
            this.G = h;
            this.U = m;
            this.X = 0;
            this.j = null;
            this.In = NaN
        },
        va4 = function(K) {
            K.DA != null && (g.qs.clearTimeout(K.DA), K.DA = null)
        },
        vEN = function(K, W) {
            K.j = 0;
            K.rj && K.rj.Su(W);
            dtH(K);
            h_3(K)
        },
        it3 = function(K, W, U, h, m, S, f, G, I, d, J, e, E, B, D) {
            var a = this;
            U = U === void 0 ? !1 : U;
            h = h === void 0 ? function() {
                return ""
            } : h;
            m = m === void 0 ? !1 : m;
            S = S === void 0 ? !1 : S;
            f = f === void 0 ? !1 : f;
            G = G === void 0 ? function() {
                return g.EC({})
            } : G;
            I = I === void 0 ? !1 : I;
            J = J === void 0 ? !1 : J;
            e = e === void 0 ? !1 : e;
            E = E === void 0 ? !1 : E;
            B = B === void 0 ? !1 : B;
            this.vp = K;
            this.Ms = W;
            this.G = new g.fj;
            this.X = (this.hK = !!D) ? D(function() {
                a.O6()
            }) : new uA(this.O6, this);
            this.j = null;
            this.Y = !1;
            this.jV = null;
            this.Ns = "";
            this.uX = this.J = 0;
            this.N = [];
            this.q5 = U;
            this.eV = h;
            this.U = S;
            this.tK = G;
            this.Le = d;
            this.Cg = f;
            this.DA = null;
            this.W = g.EC();
            this.Ez = m;
            this.DO = I;
            this.Qg = J;
            this.M5 = e;
            this.XI = E;
            this.W3 = B;
            this.Ik = new x1f;
            this.Bp = new K1f;
            this.gk = new nRZ;
            this.Pp = new CpO;
            this.JK = new llt;
            this.oW = new jHI;
            this.Ny = new tDO
        },
        egH = function(K, W) {
            g.qE(K.U);
            K.U = 0;
            var U = null;
            if (W)
                if (W.loungeToken) {
                    var h;
                    ((h = K.j) == null ? void 0 : h.token) == W.loungeToken && (U = "staleLoungeToken")
                } else U = "missingLoungeToken";
            else U = "noLoungeTokenResponse";
            U ? (K.info("Did not receive a new lounge token in onLoungeToken_ with data: " + (JSON.stringify(W) + ", error: " + U)), K.jV = U, J7v(K, 3E4)) : (SDj(K, W.loungeToken), K.Ns = !1, K.jV = "unknown", J7v(K, W.loungeTokenRefreshIntervalMs))
        },
        EQO = function(K, W) {
            if (K.j == 1) {
                if (!W) {
                    K.F2 = Math.floor(Math.random() * 1E5);
                    W = K.F2++;
                    var U = new bA(K, "", W);
                    U.w2 = K.Pa;
                    var h = W1I(K),
                        m = K.fQ.clone();
                    g.aT(m, "RID", W);
                    g.aT(m, "CVER", "1");
                    A$(K, m);
                    U1v(U, m, h);
                    K.BS = U;
                    K.j = 2
                }
            } else K.j == 3 && (W ? hr4(K, W) : K.X.length == 0 || K.BS || hr4(K))
        },
        HGZ = function(K, W) {
            K.Y = W.params.videoId;
            K.publish("nowAutoplaying", parseInt(W.params.timeout, 10))
        },
        BcH = function() {
            var K = sO;
            if (V0[0]) {
                var W = X6 ? v9 : -1,
                    U = {};
                do U = {
                    v5: void 0
                }, W = (W + 1) % 50, U.v5 = V0[W], g.tD(K, function(h) {
                    return function(m) {
                        m(h.v5)
                    }
                }(U));
                while (W != v9);
                V0 = Array(50);
                v9 = -1;
                X6 = !1
            }
        },
        DZ = function(K, W) {
            if (typeof K !== "function") throw Error("Fn must not be null and must be a function");
            return g.qs.setTimeout(function() {
                K()
            }, W)
        },
        t$ = function() {
            if (DtF) return DtF;
            var K = g.SZ("yt-remote-device-id");
            K || (K = TlI(), g.SI("yt-remote-device-id", K, 31536E3));
            for (var W = fK(), U = 1, h = K; g.BX(W, h);) U++, h = K + "#" + U;
            return DtF = h
        },
        IB = function(K) {
            g.GP.call(this);
            this.G = K;
            this.screens = []
        },
        HSF = function() {
            return g.SZ("yt-remote-session-browser-channel")
        },
        o7 = function() {
            if (!qu) {
                qu = new g.n4(new EEh);
                var K = g.Cz("client_streamz_web_flush_count", -1);
                K !== -1 && (qu.N = K)
            }
            return qu
        },
        r7N = function() {
            g.nO.call(this, "o")
        },
        hgj = function(K, W) {
            if (U_(K)) {
                K.fg.unsubscribe("remotePlayerChange", K.dw, K);
                var U = Math.round(W.volume);
                W = !!W.muted;
                var h = h$(K.fg);
                if (U !== h.volume || W !== h.muted) K.fg.setVolume(U, W), K.jV.start();
                K.fg.subscribe("remotePlayerChange", K.dw, K)
            }
        },
        TcI = function(K, W, U) {
            LAh(K.j, W, U)
        },
        fK = function() {
            var K = g.SZ("yt-remote-connected-devices") || [];
            g.OM(K);
            return K
        },
        aWt = function(K) {
            g.tD(K.G, function(W) {
                this.W.unsubscribeByKey(W)
            }, K);
            K.G.length = 0
        },
        Bn4 = function() {
            var K = mt3(),
                W = [];
            if (K > 1) {
                var U = K - 1;
                W.push("//www.gstatic.com/eureka/clank/" + K + "/cast_sender.js");
                W.push("//www.gstatic.com/eureka/clank/" + U + "/cast_sender.js")
            }
            return W
        },
        LAh = function(K, W, U) {
            var h = $O(K.U, "/pairing/get_screen_availability");
            K.U.sendRequest("POST", h, {
                lounge_token: W.token
            }, (0, g.wr)(function(m) {
                m = m.screens || [];
                for (var S = m.length, f = 0; f < S; ++f)
                    if (m[f].loungeToken == W.token) {
                        U(m[f].status == "online");
                        return
                    }
                U(!1)
            }, K), (0, g.wr)(function() {
                U(!1)
            }, K))
        },
        MDb = function(K) {
            K.VI(1, 0);
            K.fQ = R7(K, null, K.eb);
            wYh(K)
        },
        Qyf = function(K, W) {
            K.info("sendYoutubeMessage_: " + W + " " + g.rc());
            var U = {};
            U.type = W;
            K.N ? K.N.sendMessage("urn:x-cast:com.google.youtube.mdx", U, function() {}, (0, g.wr)(function() {
                xt(this, "Failed to send message: " + W + ".")
            }, K)) : xt(K, "Sending yt message without session: " + g.rc(U))
        },
        uIN = function(K) {
            this.N = [];
            this.Cg = this.Ea = this.Le = this.Ez = this.j = this.bG = this.hK = this.eV = this.Y = this.W3 = this.jV = null;
            this.pC = this.JK = 0;
            this.qb = zH("failFast", !1, K);
            this.Bp = this.Ms = this.J = this.G = this.U = null;
            this.XI = !0;
            this.Pl = this.tK = -1;
            this.q5 = this.uX = this.Ns = 0;
            this.Ev = zH("baseRetryDelayMs", 5E3, K);
            this.rS = zH("retryDelaySeedMs", 1E4, K);
            this.M9 = zH("forwardChannelMaxRetries", 2, K);
            this.Iu = zH("forwardChannelRequestTimeoutMs", 2E4, K);
            this.QA = K && K.cem || void 0;
            this.Dp = K && K.I1K || void 0;
            this.QX = K && K.f7X || !1;
            this.Pp = void 0;
            this.vp = K && K.O_k ||
                !1;
            this.W = "";
            this.X = new $tO(K && K.drU);
            this.ZX = new Y2j;
            this.M5 = K && K.PQk || !1;
            this.gk = K && K.BNm || !1;
            this.M5 && this.gk && (this.gk = !1);
            this.u5 = K && K.NN5 || !1;
            K && K.xre && (this.XI = !1);
            this.oW = !this.M5 && this.XI && K && K.mrH || !1;
            this.AS = void 0;
            K && K.Sf && K.Sf > 0 && (this.AS = K.Sf);
            this.Qg = void 0;
            this.Ny = 0;
            this.Ik = !1;
            this.DO = this.DA = null
        },
        OSW = function() {},
        Dw = function(K) {
            g.y.call(this, {
                T: "div",
                Z: "ytp-remote",
                K: [{
                    T: "div",
                    Z: "ytp-remote-display-status",
                    K: [{
                        T: "div",
                        Z: "ytp-remote-display-status-icon",
                        K: [g.CED()]
                    }, {
                        T: "div",
                        Z: "ytp-remote-display-status-text",
                        bX: "{{statustext}}"
                    }]
                }]
            });
            this.api = K;
            this.fade = new g.Wr(this, 250);
            g.k(this, this.fade);
            this.S(K, "presentingplayerstatechange", this.onStateChange);
            this.Bl(K.getPlayerStateObject())
        },
        o2b = function(K) {
            K.screens = K.X.Ha();
            var W = K.U,
                U = {},
                h;
            for (h in W) U[W[h]] = h;
            W = K.screens.length;
            for (h = 0; h < W; ++h) {
                var m = K.screens[h];
                m.uuid = U[m.id] || ""
            }
            K.info("Updated manual screens: " + ZGh(K.screens))
        },
        c7t = function() {
            this.j = [];
            this.X = []
        },
        W0H = function(K) {
            if (K.j || K.J || K.uX >= 3) return !1;
            K.q5++;
            K.J = OO((0, g.wr)(K.du, K), UtO(K, K.uX));
            K.uX++;
            return !0
        },
        ZGh = function(K) {
            return Array.isArray(K) ? "[" + g.CB(K, kO).join(",") + "]" : "null"
        },
        nQW = function(K) {
            K.player.getPlayerStateObject().isPlaying() ? K.player.pauseVideo() : (K.En = function(W) {
                !K.Kd && g.M9(W, 8) && (K.player.pauseVideo(), Cs(K))
            }, K.player.addEventListener("presentingplayerstatechange", K.En));
            K.We && K.We.Kr();
            S4() || (P9 = !0)
        },
        F9f = function(K, W) {
            if (K.j == 0) throw Error("Invalid operation: sending map when state is closed");
            K.X.push(new gQW(K.wb++, W));
            K.j != 2 && K.j != 3 || wYh(K)
        },
        ubI = function(K) {
            hz("remote.onCastSessionChange_: " + kO(K));
            if (K) {
                var W = H9();
                if (W && W.id == K.id) {
                    if (Q0(W.id, "YouTube TV"), K.idType == "shortLived" && (K = K.token)) ps && (ps.token = K), (W = S4()) && W.mq(K)
                } else W && lM(), jM(K, 1)
            } else S4() && lM()
        },
        Ls = function(K) {
            S2n(K);
            g.vZ(K.E$);
            K.E$ = null;
            K.U.stop();
            K.N.removeAll();
            if (K.BN) {
                var W = K.BN;
                K.BN = null;
                W.abort();
                W.dispose()
            }
            K.Q5 && (K.Q5 = null)
        },
        k7t = function(K) {
            g.qE(K.J);
            K.J = 0;
            g.qE(K.G);
            K.G = 0;
            g.qE(K.Ms);
            K.Ms = 0;
            g.qE(K.U);
            K.U = 0;
            g.qE(K.Y);
            K.Y = 0
        },
        Kb = function(K) {
            K.gk = Date.now() + K.Ik;
            k$n(K, K.Ik)
        },
        WU = function(K) {
            m_("Controller", K)
        },
        iSI = function(K, W, U, h) {
            g.qE(K.G);
            K.G = 0;
            TcI(K.W, W, function(m) {
                m || h < 0 ? U(m) : K.G = g.FE(function() {
                    iSI(K, W, U, h - 1)
                }, 300)
            })
        },
        qA = function(K) {
            this.name = this.id = "";
            this.clientName = "UNKNOWN_INTERFACE";
            this.app = "";
            this.type = "REMOTE_CONTROL";
            this.ownerObfuscatedGaiaId = this.obfuscatedGaiaId = this.avatar = this.username = "";
            this.capabilities = new Set;
            this.compatibleSenderThemes = new Set;
            this.experiments = new Set;
            this.theme = "u";
            new Ue;
            this.model = this.brand = "";
            this.year = 0;
            this.chipset = this.osVersion = this.os = "";
            this.mdxDialServerType = "MDX_DIAL_SERVER_TYPE_UNKNOWN";
            K && (this.id = K.id || K.name, this.name = K.name, this.clientName = K.clientName ? K.clientName.toUpperCase() : "UNKNOWN_INTERFACE",
                this.app = K.app, this.type = K.type || "REMOTE_CONTROL", this.username = K.user || "", this.avatar = K.userAvatarUri || "", this.obfuscatedGaiaId = K.obfuscatedGaiaId || "", this.ownerObfuscatedGaiaId = K.ownerObfuscatedGaiaId || "", this.theme = K.theme || "u", zg4(this, K.capabilities || ""), eNZ(this, K.compatibleSenderThemes || ""), iXj(this, K.experiments || ""), this.brand = K.brand || "", this.model = K.model || "", this.year = K.year || 0, this.os = K.os || "", this.osVersion = K.osVersion || "", this.chipset = K.chipset || "", this.mdxDialServerType = K.mdxDialServerType ||
                "MDX_DIAL_SERVER_TYPE_UNKNOWN", K = K.deviceInfo) && (K = JSON.parse(K), this.brand = K.brand || "", this.model = K.model || "", this.year = K.year || 0, this.os = K.os || "", this.osVersion = K.osVersion || "", this.chipset = K.chipset || "", this.clientName = K.clientName ? K.clientName.toUpperCase() : "UNKNOWN_INTERFACE", this.mdxDialServerType = K.mdxDialServerType || "MDX_DIAL_SERVER_TYPE_UNKNOWN")
        },
        NcO = function(K, W, U) {
            if (W && !K.vp) throw Error("Can't create secondary domain capable XhrIo object.");
            W = K.QX && !K.QA ? new g.DK(new g.jW({
                Ab: U
            })) : new g.DK(K.QA);
            W.Y = K.vp;
            return W
        },
        A73 = function(K, W, U, h) {
            g.qE(K.G);
            K.G = 0;
            TcI(K.W, W, function(m) {
                m || h < 0 ? U(m) : K.G = g.FE(function() {
                    A73(K, W, U, h - 1)
                }, 300)
            })
        },
        Rgf = function() {
            var K = ZXN();
            if (g.Tb(K)) {
                K = t$();
                var W = g.SZ("yt-remote-session-name") || "",
                    U = g.SZ("yt-remote-session-app") || "";
                K = {
                    device: "REMOTE_CONTROL",
                    id: K,
                    name: W,
                    app: U,
                    mdxVersion: 3
                };
                K.authuser = String(g.TA("SESSION_INDEX", "0"));
                (W = g.TA("DELEGATED_SESSION_ID")) && (K.pageId = String(W));
                g.Vk("yt.mdx.remote.channelParams_", K)
            }
        },
        y7I = function(K) {
            v0("Channel opened");
            K.DA && (K.DA = !1, HX4(K), K.Ns = g.FE(function() {
                v0("Timing out waiting for a screen.");
                K.z3(1)
            }, 15E3))
        },
        MSO = function(K, W, U) {
            for (var h = 0; h < U; ++h) F9f(K.j, W[h]);
            Xv(K)
        },
        CpO = function() {
            var K = o7();
            this.j = K;
            K.jD("/client_streamz/youtube/living_room/mdx/channel/message_received", g.Mk("channel_type"))
        },
        rMH = function(K, W) {
            K.Y = W.params.videoId || null;
            K.publish("autoplayUpNext", K.Y)
        },
        bGF = function(K, W) {
            g.GP.call(this);
            this.G = W;
            W = (W = g.SZ("yt-remote-online-screen-ids") || "") ? W.split(",") : [];
            for (var U = {}, h = this.G(), m = h.length, S = 0; S < m; ++S) {
                var f = h[S].id;
                U[f] = g.BX(W, f)
            }
            this.j = U;
            this.U = K;
            this.N = this.W = NaN;
            this.X = null;
            PPH("Initialized with " + g.rc(this.j))
        },
        $t = function(K) {
            this.j = K
        },
        pYh = function(K) {
            if (K.DO) return g.EC();
            if (!K.Cg) return XNI(K);
            K.DA === null && (K.DA = XNI(K));
            return K.DA
        },
        oQ4 = function(K, W) {
            return W ? g.dG(K.N, function(U) {
                return j4(W, U.label)
            }, K) : null
        },
        hn = function(K, W) {
            K.X && (K.X.removeUpdateListener(K.jV), K.X.removeMediaListener(K.Y), K.Tr(null));
            K.X = W;
            K.X && (Nu("Setting cast session: " + K.X.sessionId), K.X.addUpdateListener(K.jV), K.X.addMediaListener(K.Y), K.X.media.length && K.Tr(K.X.media[0]))
        },
        ZSn = function(K) {
            return K.j ? K.DA == "GET" && K.tK != 2 && K.N.QX : !1
        },
        js = function(K) {
            return K.getState() == 1
        },
        OO = function(K, W) {
            if (typeof K !== "function") throw Error("Fn must not be null and must be a function");
            return g.qs.setTimeout(function() {
                K()
            }, W)
        },
        m3 = function(K) {
            return K.Y || !!K.N.length || !!K.j
        },
        Ss = function(K, W) {
            if (W.key !== K.UO.key)
                if (W.key === K.bA.key) lM();
                else if (ERj(K) && nQW(K), K.UO = W, !g.l1(K.player.V())) {
                var U = K.player.getPlaylistId();
                var h = K.player.getVideoData(1);
                var m = h.videoId;
                if (!U && !m || (K.player.getAppState() === 2 || K.player.getAppState() === 1) && K.player.V().L("should_clear_video_data_on_player_cued_unstarted")) h = null;
                else {
                    var S = K.player.getPlaylist();
                    if (S) {
                        var f = [];
                        for (var G = 0; G < S.length; G++) f[G] = g.M6(S, G).videoId
                    } else f = [m];
                    S = K.player.getCurrentTime(1);
                    K = {
                        videoIds: f,
                        listId: U,
                        videoId: m,
                        playerParams: h.playerParams,
                        clickTrackingParams: h.Ms,
                        index: Math.max(K.player.getPlaylistIndex(),
                            0),
                        currentTime: S === 0 ? void 0 : S
                    };
                    (h = G7f(h)) && (K.locationInfo = h);
                    h = K
                }
                hz("Connecting to: " + g.rc(W));
                W.key == "cast-selector-receiver" ? (rm(h || null), W = h || null, wm() ? Ks().setLaunchParams(W) : SM("setLaunchParams called before ready.")) : !h && fgh() && gm() == W.key ? W9("yt-remote-connection-change", !0) : (lM(), rm(h || null), h = TH().Ha(), (W = m4(h, W.key)) && jM(W, 1))
            }
        },
        U_ = function(K) {
            return h$(K.fg).videoId === K.D.getVideoData(1).videoId
        },
        gEW = function(K, W) {
            K.Ns = Date.now();
            Kb(K);
            K.JK = K.J.clone();
            uM(K.JK, "t", K.q5);
            K.Y = 0;
            var U = K.N.vp;
            K.X = new lgn;
            K.j = NcO(K.N, U ? W : null, !K.jV);
            K.Pp > 0 && (K.Bp = new g.VF((0, g.wr)(K.hX, K, K.j), K.Pp));
            K.M5.listen(K.j, "readystatechange", K.vk);
            W = K.Le ? g.Ni(K.Le) : {};
            K.jV ? (K.DA || (K.DA = "POST"), W["Content-Type"] = "application/x-www-form-urlencoded", K.j.send(K.JK, K.DA, K.jV, W)) : (K.DA = "GET", K.j.send(K.JK, K.DA, null, W));
            lA(1)
        },
        zg4 = function(K, W) {
            K.capabilities.clear();
            g.yb(W.split(","), g.jt(dqZ, bSj)).forEach(function(U) {
                K.capabilities.add(U)
            })
        },
        gm = function() {
            return g.vB("yt.mdx.remote.currentScreenId_")
        },
        z_Z = function(K) {
            g.Uj.call(this);
            this.j = K();
            this.j.subscribe("webChannelOpened", this.Ki, this);
            this.j.subscribe("webChannelClosed", this.onClosed, this);
            this.j.subscribe("webChannelError", this.onError, this);
            this.j.subscribe("webChannelMessage", this.onMessage, this)
        },
        eM = function(K, W) {
            K.j = W;
            K.publish("sessionScreen", K.j)
        },
        syt = function(K, W) {
            if (W) {
                var U = K.D.getOption("captions", "tracklist", {
                    B4: 1
                });
                U && U.length ? (K.D.setOption("captions", "track", W), K.U = !1) : (K.D.loadModule("captions"), K.U = !0)
            } else K.D.setOption("captions", "track", {})
        },
        wYh = function(K) {
            K.BS || K.F4 || (K.F4 = DZ((0, g.wr)(K.Yf, K), 0), K.IE = 0)
        },
        fb = function(K) {
            isNaN(K.N) || g.qE(K.N);
            K.N = g.FE((0, g.wr)(K.i4, K), K.W > 0 && K.W < g.hi() ? 2E4 : 1E4)
        },
        XYN = function(K, W) {
            var U = K.J.receiver.label,
                h = K.X.friendlyName;
            return (new Promise(function(m) {
                W9h(K.W, U, W, h, function(S) {
                    S && S.token && eM(K, S);
                    m(S)
                }, function(S) {
                    xt(K, "Failed to get DIAL screen: " + S);
                    m(null)
                })
            })).then(function(m) {
                return m && m.token ? new chrome.cast.DialLaunchResponse(!1) : VSN(K)
            })
        },
        SDj = function(K, W) {
            K.j && (K.j.token = W, Az(K.W, K.j));
            K.publish("sessionScreen", K.j)
        },
        xtO = function(K, W) {
            vQF();
            if (!tn || !tn.get("yt-remote-disable-remote-module-for-dev")) {
                W = g.TA("MDX_CONFIG") || W;
                GoO();
                XrF();
                ZZ || (ZZ = new GO(W ? W.loungeApiHost : void 0), b7v() && (ZZ.j = "/api/loungedev"));
                Tu || (Tu = g.vB("yt.mdx.remote.deferredProxies_") || [], g.Vk("yt.mdx.remote.deferredProxies_", Tu));
                Rgf();
                var U = TH();
                if (!U) {
                    var h = new Mu(ZZ, W ? W.disableAutomaticScreenCache || !1 : !1);
                    g.Vk("yt.mdx.remote.screenService_", h);
                    U = TH();
                    var m = {};
                    W && (m = {
                        appId: W.appId,
                        disableDial: W.disableDial,
                        theme: W.theme,
                        loadCastApiSetupScript: W.loadCastApiSetupScript,
                        disableCastApi: W.disableCastApi,
                        enableDialLoungeToken: W.enableDialLoungeToken,
                        enableCastLoungeToken: W.enableCastLoungeToken,
                        forceMirroring: W.forceMirroring
                    });
                    g.Vk("yt.mdx.remote.enableConnectWithInitialState_", W ? W.enableConnectWithInitialState || !1 : !1);
                    q2F(K, h, function(S) {
                        S ? gm() && Q0(gm(), "YouTube TV") : h.subscribe("onlineScreenChange", function() {
                            W9("yt-remote-receiver-availability-change")
                        })
                    }, m)
                }
                W && !g.vB("yt.mdx.remote.initialized_") && (g.Vk("yt.mdx.remote.initialized_", !0), hz("Initializing: " + g.rc(W)),
                    IY.push(g.BV("yt-remote-cast2-api-ready", function() {
                        W9("yt-remote-api-ready")
                    })), IY.push(g.BV("yt-remote-cast2-availability-change", function() {
                        W9("yt-remote-receiver-availability-change")
                    })), IY.push(g.BV("yt-remote-cast2-receiver-selected", function() {
                        rm(null);
                        W9("yt-remote-auto-connect", "cast-selector-receiver")
                    })), IY.push(g.BV("yt-remote-cast2-receiver-resumed", function() {
                        W9("yt-remote-receiver-resumed", "cast-selector-receiver")
                    })), IY.push(g.BV("yt-remote-cast2-session-change", ubI)), IY.push(g.BV("yt-remote-connection-change", function(S) {
                        S ? Q0(gm(), "YouTube TV") : r7() || (Q0(null, null), qKW())
                    })), IY.push(g.BV("yt-remote-cast2-session-failed", function() {
                        W9("yt-remote-connection-failed")
                    })), K = ZXN(), W.isAuto && (K.id += "#dial"), m = W.capabilities || [], m.length > 0 && (K.capabilities =
                        m), K.name = W.device, K.app = W.app, (W = W.theme) && (K.theme = W), hz(" -- with channel params: " + g.rc(K)), K ? (g.SI("yt-remote-session-app", K.app), g.SI("yt-remote-session-name", K.name)) : (g.HX("yt-remote-session-app"), g.HX("yt-remote-session-name")), g.Vk("yt.mdx.remote.channelParams_", K), U.start(), gm() || yMj())
            }
        },
        CPW = function(K) {
            K.Ym(0);
            K.X.stop();
            K.uY(new g.Kw(64))
        },
        q2F = function(K, W, U, h) {
            h.disableCastApi ? P0("Cannot initialize because disabled by Mdx config.") : lWZ() ? tS4(W, h) && (L93(!0), window.chrome && chrome.cast && chrome.cast.isAvailable ? KFt(K, U) : (window.__onGCastApiAvailable = function(m, S) {
                    m ? KFt(K, U) : (SM("Failed to load cast API: " + S), WFj(!1), L93(!1), g.HX("yt-remote-cast-available"), g.HX("yt-remote-cast-receiver"), zrN(), U(!1))
                }, h.loadCastApiSetupScript ? g.Vlp(U0h) : window.navigator.userAgent.indexOf("Android") >= 0 && window.navigator.userAgent.indexOf("Chrome/") >=
                0 && window.navigator.presentation ? mt3() >= 60 && R_O() : !window.chrome || !window.navigator.presentation || window.navigator.userAgent.indexOf("Edge") >= 0 ? y6h() : mt3() >= 89 ? Htf() : (MEW(), xO(DJW.map(OX4))))) : P0("Cannot initialize because not running Chrome")
        },
        q0n = function(K, W) {
            return K.X ? K.X == W : K.j ? K.j.has(W) : !1
        },
        m0O = function(K, W) {
            var U = K.Y,
                h = W.indexOf("\n", U);
            if (h == -1) return hmj;
            U = Number(W.substring(U, h));
            if (isNaN(U)) return jtv;
            h += 1;
            if (h + U > W.length) return hmj;
            W = W.slice(h, h + U);
            K.Y = h + U;
            return W
        },
        SIh = function(K) {
            K.NZ || K.cg || (K.Y = 1, K.cg = DZ((0, g.wr)(K.Zm, K), 0), K.FZ = 0)
        },
        fUn = function(K) {
            if (!ZSn(K)) return g.FU(K.j);
            var W = g.VS(K.j);
            if (W === "") return "";
            var U = "",
                h = W.length,
                m = g.ez(K.j) == 4;
            if (!K.X.N) {
                if (typeof TextDecoder === "undefined") return dC(K), NA(K), "";
                K.X.N = new g.qs.TextDecoder
            }
            for (var S = 0; S < h; S++) K.X.X = !0, U += K.X.N.decode(W[S], {
                stream: !(m && S == h - 1)
            });
            W.length = 0;
            K.X.j += U;
            K.Y = 0;
            return K.X.j
        },
        y9 = function(K) {
            Jn.dispatchEvent(new tRn(Jn, K))
        },
        sHN = function(K) {
            K.Hq = Date.now() + K.X;
            rin(K, K.X)
        },
        Ue = function(K, W) {
            this.X = {};
            this.j = [];
            this.Gk = this.size = 0;
            var U = arguments.length;
            if (U > 1) {
                if (U % 2) throw Error("Uneven number of arguments");
                for (var h = 0; h < U; h += 2) this.set(arguments[h], arguments[h + 1])
            } else if (K)
                if (K instanceof Ue)
                    for (U = K.FA(), h = 0; h < U.length; h++) this.set(U[h], K.get(U[h]));
                else
                    for (h in K) this.set(h, K[h])
        },
        es = function(K, W) {
            g.GP.call(this);
            var U = this;
            this.N = 0;
            this.W = K;
            this.G = [];
            this.U = new c7t;
            this.X = this.j = null;
            this.jV = (0, g.wr)(this.Zrr, this);
            this.Y = (0, g.wr)(this.Tr, this);
            this.J = (0, g.wr)(this.GKe, this);
            this.Ms = (0, g.wr)(this.vmK, this);
            var h = 0;
            K ? (h = K.getProxyState(), h != 3 && (K.subscribe("proxyStateChange", this.GQ, this), Sjf(this))) : h = 3;
            h != 0 && (W ? this.GQ(h) : g.FE(function() {
                U.GQ(h)
            }, 0));
            (K = GE4()) && hn(this, K);
            this.subscribe("yt-remote-cast2-session-change", this.Ms)
        },
        E2f = function(K, W) {
            if (K.j.playerState != -1E3) {
                var U = 1085;
                switch (parseInt(W.params.adState, 10)) {
                    case 1:
                        U = 1081;
                        break;
                    case 2:
                        U = 1084;
                        break;
                    case 0:
                        U = 1083
                }
                K.j.playerState = U;
                W = parseInt(W.params.currentTime, 10);
                F6(K.j, isNaN(W) ? 0 : W);
                K.publish("remotePlayerChange")
            }
        },
        Az = function(K, W) {
            var U = K.get(W.id);
            U ? (U.uuid = W.uuid, W = U) : ((U = m4(K.N, W.uuid)) ? (U.id = W.id, U.token = W.token, W = U) : K.N.push(W), K.Y || IUW(K));
            pNZ(K);
            K.U[W.uuid] = W.id;
            g.SI("yt-remote-device-id-map", K.U, 31536E3);
            return W
        },
        pNZ = function(K) {
            K.U = g.SZ("yt-remote-device-id-map") || {}
        },
        YKb = function(K, W) {
            var U = [];
            C03(W, function(h) {
                try {
                    var m = g.mI.prototype.xO.call(this, h, !0)
                } catch (S) {
                    if (S == "Storage: Invalid value was encountered") return;
                    throw S;
                }
                m === void 0 ? U.push(h) : g.jJs(m) && U.push(h)
            }, K);
            return U
        },
        vQF = function() {
            if (!tn) {
                var K = g.Ts();
                K && (tn = new g.jy(K))
            }
        },
        emj = function(K, W) {
            a: if (d0n(W) != d0n(K.j)) var U = !1;
                else {
                    U = g.N$(W);
                    for (var h = U.length, m = 0; m < h; ++m)
                        if (!K.j[U[m]]) {
                            U = !1;
                            break a
                        }
                    U = !0
                }U || (PPH("Updated online screens: " + g.rc(K.j)), K.j = W, K.publish("screenChange"));JCN(K)
        },
        lM = function() {
            wm() ? Ks().stopSession() : SM("stopSession called before API ready.");
            var K = S4();
            K && (K.disconnect(1), $JI(null))
        },
        kWH = function(K) {
            P0("setApiReady_ " + K);
            g.Vk("yt.mdx.remote.cloudview.apiReady_", K)
        },
        K9t = function(K, W, U, h) {
            K.info("requestLoungeToken_ for " + W);
            var m = {
                postParams: {
                    screen_ids: W
                },
                method: "POST",
                context: K,
                onSuccess: function(S, f) {
                    S = f && f.screens || [];
                    S[0] && S[0].screenId == W ? U(S[0].loungeToken) : h(Error("Missing lounge token in token response"))
                },
                onError: function() {
                    h(Error("Request screen lounge token failed"))
                }
            };
            g.ka($O(K.W, "/pairing/get_lounge_token_batch"), m)
        },
        GE4 = function() {
            return LK() ? Ks() ? Ks().getCastSession() : (SM("getCastSelector: Cast is not initialized."), null) : (SM("getCastSelector: Cast API is not installed!"), null)
        },
        IgH = function(K) {
            K.Le && !K.U && VDO(K, K.Le())
        },
        t8N = function(K, W) {
            g.qE(K.Ms);
            K.Ms = 0;
            W ? K.config_.enableCastLoungeToken && W.loungeToken ? W.deviceId ? K.j && K.j.uuid == W.deviceId || (W.loungeTokenRefreshIntervalMs ? BVf(K, {
                    name: K.X.friendlyName,
                    screenId: W.screenId,
                    loungeToken: W.loungeToken,
                    dialId: W.deviceId,
                    screenIdType: "shortLived"
                }, W.loungeTokenRefreshIntervalMs) : (g.aH(Error("No loungeTokenRefreshIntervalMs presents in mdxSessionStatusData: " + JSON.stringify(W) + ".")), E$O(K, W.screenId))) : (g.aH(Error("No device id presents in mdxSessionStatusData: " + JSON.stringify(W) + ".")), E$O(K, W.screenId)) :
                E$O(K, W.screenId) : K.uK(Error("Waiting for session status timed out."))
        },
        dm = function(K) {
            if (g.hc("deprecate_pair_servlet_enabled")) return kot(K, []);
            var W = Q1W(VE4());
            W = g.yb(W, function(U) {
                return !U.uuid
            });
            return kot(K, W)
        },
        GO = function(K) {
            this.scheme = "https";
            this.port = this.domain = "";
            this.j = "/api/lounge";
            this.X = !0;
            K = K || document.location.href;
            var W = Number(g.wB(K)[4] || null) || "";
            W && (this.port = ":" + W);
            this.domain = g.Qq(K) || "";
            K = g.i5();
            K.search("MSIE") >= 0 && (K = K.match(/MSIE ([\d.]+)/)[1], g.Il(K, "10.0") < 0 && (this.X = !1))
        },
        s_ = function(K) {
            var W;
            return !!(K.config_.enableDialLoungeToken && ((W = K.N) == null ? 0 : W.getDialAppInfo))
        },
        D0t = function(K) {
            var W = K.X.wu(),
                U = K.j && K.j.X;
            K = g.CB(W, function(h) {
                U && j4(h, U.label) && (U = null);
                var m = h.uuid ? h.uuid : h.id,
                    S = oQ4(this, h);
                S ? (S.label = m, S.friendlyName = h.name) : (S = new chrome.cast.Receiver(m, h.name), S.receiverType = chrome.cast.ReceiverType.CUSTOM);
                return S
            }, K);
            U && (U.receiverType != chrome.cast.ReceiverType.CUSTOM && (U = new chrome.cast.Receiver(U.label, U.friendlyName), U.receiverType = chrome.cast.ReceiverType.CUSTOM), K.push(U));
            return K
        },
        H0 = function() {
            g.y.call(this, {
                T: "div",
                Z: "ytp-mdx-popup-dialog",
                B: {
                    role: "dialog"
                },
                K: [{
                    T: "div",
                    Z: "ytp-mdx-popup-dialog-inner-content",
                    K: [{
                            T: "div",
                            Z: "ytp-mdx-popup-title",
                            bX: "B\u1ea1n \u0111\u00e3 \u0111\u0103ng xu\u1ea5t"
                        }, {
                            T: "div",
                            Z: "ytp-mdx-popup-description",
                            bX: "C\u00e1c video m\u00e0 b\u1ea1n xem c\u00f3 th\u1ec3 \u0111\u01b0\u1ee3c th\u00eam v\u00e0o nh\u1eadt k\u00fd xem v\u00e0 g\u00e2y \u1ea3nh h\u01b0\u1edfng \u0111\u1ebfn ph\u1ea7n \u0111\u1ec1 xu\u1ea5t tr\u00ean TV. \u0110\u1ec3 tr\u00e1nh \u0111i\u1ec1u n\u00e0y, h\u00e3y h\u1ee7y r\u1ed3i \u0111\u0103ng nh\u1eadp v\u00e0o YouTube tr\u00ean m\u00e1y t\u00ednh."
                        },
                        {
                            T: "div",
                            Z: "ytp-mdx-privacy-popup-buttons",
                            K: [{
                                T: "button",
                                Hp: ["ytp-button", "ytp-mdx-privacy-popup-cancel"],
                                bX: "H\u1ee7y"
                            }, {
                                T: "button",
                                Hp: ["ytp-button", "ytp-mdx-privacy-popup-confirm"],
                                bX: "X\u00e1c nh\u1eadn"
                            }]
                        }
                    ]
                }]
            });
            this.fade = new g.Wr(this, 250);
            this.cancelButton = this.yH("ytp-mdx-privacy-popup-cancel");
            this.confirmButton = this.yH("ytp-mdx-privacy-popup-confirm");
            g.k(this, this.fade);
            this.S(this.cancelButton, "click", this.j);
            this.S(this.confirmButton, "click", this.X)
        },
        xt = function(K, W) {
            m_(K.hK, W)
        },
        HzI = function(K) {
            var W,
                U;
            g.r(function(h) {
                if (h.j == 1) return g.bE(h, 2), g.T(h, pYh(K), 2);
                g.VY(h);
                W = K.N;
                K.N = [];
                U = W.length;
                MSO(K, W, U);
                Xv(K);
                return g.vr(h, 0)
            })
        },
        tRn = function(K) {
            g.nO.call(this, "statevent", K)
        },
        llt = function() {
            var K = o7();
            this.j = K;
            K.jD("/client_streamz/youtube/living_room/mdx/channel/error", g.Mk("channel_type"), g.Mk("error_type"))
        },
        m1f = function(K) {
            IB.call(this, "ScreenServiceProxy");
            this.di = K;
            this.j = [];
            this.j.push(this.di.$_s("screenChange", (0, g.wr)(this.jp, this)));
            this.j.push(this.di.$_s("onlineScreenChange", (0, g.wr)(this.qvk, this)))
        },
        PPH = function(K) {
            m_("OnlineScreenService", K)
        },
        rCj = function(K, W, U) {
            K.RR = U;
            K.player.publish("presentingplayerstatechange", new g.e0(U, W))
        },
        ns = function(K, W, U, h) {
            this.N = K;
            this.W = W;
            this.Cg = U;
            this.q5 = h || 1;
            this.M5 = new g.wv(this);
            this.Ik = 45E3;
            this.Le = null;
            this.G = !1;
            this.jV = this.JK = this.J = this.tK = this.Ns = this.gk = this.Ms = null;
            this.uX = [];
            this.j = null;
            this.Y = 0;
            this.U = this.DA = null;
            this.Qg = -1;
            this.eV = !1;
            this.Pp = 0;
            this.Bp = null;
            this.DO = this.vp = this.W3 = this.hK = !1;
            this.X = new lgn
        },
        TVN = function(K) {
            var W = {};
            g.tD(K.G(), function(U) {
                U.token ? W[U.token] = U.id : this.dS("Requesting availability of screen w/o lounge token.")
            });
            return W
        },
        KFt = function(K, W) {
            WFj(!0);
            L93(!1);
            aUO(K, function(U) {
                U ? (kWH(!0), g.KH("yt-remote-cast2-api-ready")) : (SM("Failed to initialize cast API."), WFj(!1), g.HX("yt-remote-cast-available"), g.HX("yt-remote-cast-receiver"), zrN());
                W(U)
            })
        },
        wRO = function(K, W, U, h) {
            g.nO.call(this, "timingevent", K);
            this.size = W;
            this.rtt = U;
            this.retries = h
        },
        dtH = function(K) {
            K.j = 0;
            K.df = -1;
            if (K.rj)
                if (K.N.length == 0 && K.X.length == 0) K.rj.t5();
                else {
                    var W = g.k4(K.N),
                        U = g.k4(K.X);
                    K.N.length = 0;
                    K.X.length = 0;
                    K.rj.t5(W, U)
                }
        },
        J7v = function(K, W) {
            g.qE(K.Y);
            K.Y = 0;
            W == 0 ? Qtn(K) : K.Y = g.FE(function() {
                Qtn(K)
            }, W)
        },
        WFj = function(K) {
            P0("setCastInstalled_ " + K);
            g.SI("yt-remote-cast-installed", K)
        },
        JCN = function(K) {
            K = g.N$(g.d6(K.j, function(W) {
                return W
            }));
            g.OM(K);
            K.length ? g.SI("yt-remote-online-screen-ids", K.join(","), 60) : g.HX("yt-remote-online-screen-ids")
        },
        $0n = function(K) {
            g.qE(K.G);
            K.G = 0;
            g.qE(K.Y);
            K.Y = 0;
            K.U();
            K.U = function() {};
            g.qE(K.jV)
        },
        YIH = function(K) {
            g.nO.call(this, "channelError");
            this.error = K
        },
        Y2j = function() {
            this.j = new Jz
        },
        OzI = function(K) {
            NvH.call(this);
            K.__headers__ && (this.headers = K.__headers__, this.statusCode = K.__status__, delete K.__headers__, delete K.__status__);
            var W = K.__sm__;
            W ? this.data = (this.j = g.qB(W)) ? g.Ug(W, this.j) : W : this.data = K
        },
        cCj = function(K) {
            if (K.screens.length) {
                var W = g.CB(K.screens, function(h) {
                        return h.id
                    }),
                    U = $O(K.X, "/pairing/get_lounge_token_batch");
                K.X.sendRequest("POST", U, {
                    screen_ids: W.join(",")
                }, (0, g.wr)(K.LrA, K), (0, g.wr)(K.nxs, K))
            }
        },
        Zth = function(K, W) {
            var U = 5E3 + Math.floor(Math.random() * 1E4);
            K.isActive() || (U *= 2);
            return U * W
        },
        dC = function(K) {
            Yjh(K);
            g.vZ(K.Bp);
            K.Bp = null;
            K.M5.removeAll();
            if (K.j) {
                var W = K.j;
                K.j = null;
                W.abort();
                W.dispose()
            }
        },
        Ks = function() {
            return g.vB("yt.mdx.remote.cloudview.instance_")
        },
        n$O = function(K, W) {
            var U = K.screens.length;
            K.screens = g.yb(K.screens, function(h) {
                return !(h || W ? !h != !W ? 0 : h.id == W.id : 1)
            });
            return K.screens.length < U
        },
        waj = function(K) {
            return new tz(K)
        },
        F1W = function() {
            var K = g.SZ("yt-remote-cast-receiver");
            return K ? K.friendlyName : null
        },
        Ee = function(K) {
            this.index = -1;
            this.videoId = this.listId = "";
            this.volume = this.playerState = -1;
            this.muted = !1;
            this.audioTrackId = null;
            this.U = this.G = 0;
            this.trackData = null;
            this.zP = this.cM = !1;
            this.J = this.N = this.Y = this.X = 0;
            this.j = NaN;
            this.W = !1;
            this.reset(K)
        },
        h$ = function(K) {
            return new Ee(K.W.getPlayerContextData())
        },
        HX4 = function(K) {
            g.qE(K.Ns);
            K.Ns = NaN
        },
        g$j = function(K) {
            var W = R7(K.j, K.vT, "/mail/images/cleardot.gif");
            g7(W);
            cif(W.toString(), 5E3, (0, g.wr)(K.Qf, K), 3, 2E3);
            K.Cn(1)
        },
        $tO = function(K) {
            this.U = K || 10;
            g.qs.PerformanceNavigationTiming ? (K = g.qs.performance.getEntriesByType("navigation"), K = K.length > 0 && (K[0].nextHopProtocol == "hq" || K[0].nextHopProtocol == "h2")) : K = !!(g.qs.chrome && g.qs.chrome.loadTimes && g.qs.chrome.loadTimes() && g.qs.chrome.loadTimes().wasFetchedViaSpdy);
            this.W = K ? this.U : 1;
            this.j = null;
            this.W > 1 && (this.j = new Set);
            this.X = null;
            this.N = []
        },
        FFv = function(K, W) {
            try {
                var U = K.N;
                if (U.p_ != 0 && (U.j == K || q0n(U.X, K)))
                    if (!K.vp && q0n(U.X, K) && U.p_ == 3) {
                        try {
                            var h = U.ZX.j.parse(W)
                        } catch (Q) {
                            h = null
                        }
                        if (Array.isArray(h) && h.length == 3) {
                            var m = h;
                            if (m[0] == 0) a: {
                                if (!U.J) {
                                    if (U.j)
                                        if (U.j.Ns + 3E3 < K.Ns) GH(U), J$(U);
                                        else break a;
                                    W0H(U);
                                    CK(18)
                                }
                            }
                            else U.Pl = m[1], 0 < U.Pl - U.tK && m[2] < 37500 && U.Bp && U.uX == 0 && !U.Ms && (U.Ms = OO((0, g.wr)(U.SS, U), 6E3));
                            if (AM3(U.X) <= 1 && U.Qg) {
                                try {
                                    U.Qg()
                                } catch (Q) {}
                                U.Qg = void 0
                            }
                        } else d7(U, 11)
                    } else if ((K.vp || U.j == K) && GH(U), !g.YD(W))
                    for (m = U.ZX.j.parse(W), W = 0; W < m.length; W++) {
                        var S = m[W],
                            f = S[0];
                        if (!(f <=
                                U.tK))
                            if (U.tK = f, S = S[1], U.p_ == 2)
                                if (S[0] == "c") {
                                    U.W = S[1];
                                    U.Cg = S[2];
                                    var G = S[3];
                                    G != null && (U.Ud = G);
                                    var I = S[5];
                                    I != null && typeof I === "number" && I > 0 && (U.Pp = 1.5 * I);
                                    h = U;
                                    var d = K.RO();
                                    if (d) {
                                        var J = g.i1(d, "X-Client-Wire-Protocol");
                                        if (J) {
                                            var e = h.X;
                                            !e.j && (g.so(J, "spdy") || g.so(J, "quic") || g.so(J, "h2")) && (e.W = e.U, e.j = new Set, e.X && ($1F(e, e.X), e.X = null))
                                        }
                                        if (h.hK) {
                                            var E = g.i1(d, "X-HTTP-Session-Id");
                                            E && (h.bG = E, g.aT(h.Le, h.hK, E))
                                        }
                                    }
                                    U.p_ = 3;
                                    U.U && U.U.zU();
                                    U.oW && (U.Ny = Date.now() - K.Ns);
                                    h = U;
                                    var B = K;
                                    h.Ea = e_W(h, h.vp ? h.Cg : null, h.Ez);
                                    if (B.vp) {
                                        xjb(h.X, B);
                                        var D = B,
                                            a = h.Pp;
                                        a && D.setTimeout(a);
                                        D.Ms && (Yjh(D), Kb(D));
                                        h.j = B
                                    } else Ld3(h);
                                    U.N.length > 0 && I7(U)
                                } else S[0] != "stop" && S[0] != "close" || d7(U, 7);
                        else U.p_ == 3 && (S[0] == "stop" || S[0] == "close" ? S[0] == "stop" ? d7(U, 7) : U.disconnect() : S[0] != "noop" && U.U && U.U.m2(S), U.uX = 0)
                    }
                lA(4)
            } catch (Q) {}
        },
        uxF = function(K, W, U) {
            this.j = 1;
            this.X = [];
            this.N = [];
            this.U = new Jz;
            this.jV = K || null;
            this.G = W != null ? W : null;
            this.J = U || !1
        },
        YDh = function(K, W) {
            var U = new a7,
                h = new AbortController,
                m = setTimeout(function() {
                    h.abort();
                    w7(U, "TestPingServer: timeout", !1, W)
                }, 1E4);
            fetch(K, {
                signal: h.signal
            }).then(function(S) {
                clearTimeout(m);
                S.ok ? w7(U, "TestPingServer: ok", !0, W) : w7(U, "TestPingServer: server error", !1, W)
            }).catch(function() {
                clearTimeout(m);
                w7(U, "TestPingServer: error", !1, W)
            })
        },
        qDj = function(K, W) {
            this.X = K;
            this.j = W
        },
        kEI = function() {
            sO || (sO = g.vB("yt.mdx.remote.debug.handlers_") || [], g.Vk("yt.mdx.remote.debug.handlers_", sO))
        },
        ACf = function(K, W) {
            return K.XI ? !0 : K.M5 ? Object.values(izj).includes(W) : K.Qg ? !Object.values(zmt).includes(W) : K.W3 ? Object.values(NVH).includes(W) : !1
        },
        gQW = function(K, W) {
            this.j = K;
            this.map = W;
            this.context = null
        },
        Rmb = function(K) {
            return K.W ? K.Y + kt(K) : K.Y
        },
        yCN = function(K) {
            var W = {};
            W.index = K.index;
            W.listId = K.listId;
            W.videoId = K.videoId;
            W.playerState = K.playerState;
            W.volume = K.volume;
            W.muted = K.muted;
            W.audioTrackId = K.audioTrackId;
            W.trackData = g.Dh(K.trackData);
            W.hasPrevious = K.cM;
            W.hasNext = K.zP;
            W.playerTime = K.G;
            W.playerTimeAt = K.U;
            W.seekableStart = K.X;
            W.seekableEnd = K.Y;
            W.duration = K.N;
            W.loadedTime = K.J;
            W.liveIngestionTime = K.j;
            return W
        },
        y6h = function() {
            var K = A6b();
            K && K(!1, "No cast extension found")
        },
        MRZ = function(K) {
            r7N.call(this);
            this.status = 1;
            this.errorCode = K
        },
        PyF = function() {
            LK() ? Ks() ? wm() ? (P0("Requesting cast selector."), Ks().requestSession()) : (P0("Wait for cast API to be ready to request the session."), iGb.push(g.BV("yt-remote-cast2-api-ready", PyF))) : SM("requestCastSelector: Cast is not initialized.") : SM("requestCastSelector: Cast API is not installed!")
        },
        pRZ = function(K) {
            var W = (v9 + 1) % 50;
            v9 = W;
            V0[W] = K;
            X6 || (X6 = W == 49)
        },
        dJf = function(K) {
            var W = 0;
            K.NZ && W++;
            K.BS && W++;
            return W
        },
        d0n = function(K) {
            var W = 0,
                U;
            for (U in K) W++;
            return W
        },
        lbj = function(K) {
            K.length > 5 && (K = K.slice(K.length - 5));
            var W = g.CB(VE4(), function(h) {
                    return h.loungeToken
                }),
                U = g.CB(K, function(h) {
                    return h.loungeToken
                });
            g.X9(U, function(h) {
                return !g.BX(W, h)
            }) && Xaj();
            g.SI("yt-remote-local-screens", K, 31536E3)
        },
        K0t = function(K, W) {
            if (AM3(K.X) >= K.X.W - (K.G ? 1 : 0)) return !1;
            if (K.G) return K.N = W.uX.concat(K.N), !0;
            if (K.p_ == 1 || K.p_ == 2 || K.Ns >= (K.qb ? 0 : K.M9)) return !1;
            K.G = OO((0, g.wr)(K.Dm, K, W), UtO(K, K.Ns));
            K.Ns++;
            return !0
        },
        g2b = function() {
            var K = Tnv(),
                W = H9();
            W || (W = r7());
            return g.dG(K, function(U) {
                return W && j4(W, U.key) ? !0 : !1
            })
        },
        c9 = function(K, W, U) {
            var h = K.videoId;
            K.videoId = W;
            K.index = U;
            W != h && n2W(K)
        },
        m_ = function(K, W) {
            kEI();
            var U = o$f(K, String(W));
            sO.length == 0 ? pRZ(U) : (BcH(), g.tD(sO, function(h) {
                h(U)
            }))
        },
        Qtn = function(K) {
            Qyf(K, "getLoungeToken");
            g.qE(K.U);
            K.U = g.FE(function() {
                egH(K, null)
            }, 3E4)
        },
        BU = function(K, W, U) {
            K.W.sendMessage(W, U)
        },
        L93 = function(K) {
            g.Vk("yt.mdx.remote.cloudview.initializing_", K)
        },
        P0 = function(K) {
            m_("cloudview", K)
        },
        Zzv = function(K) {
            if (K.p_ == 0) return K.DO;
            var W = [];
            g.Ms(W, IbZ(K.X));
            g.Ms(W, K.N);
            return W
        },
        wm = function() {
            return !!g.vB("yt.mdx.remote.cloudview.apiReady_")
        },
        RB = function(K, W, U) {
            g.p.call(this);
            this.G = U != null ? (0, g.wr)(K, U) : K;
            this.y6 = W;
            this.U = (0, g.wr)(this.Z8, this);
            this.j = !1;
            this.X = 0;
            this.N = this.In = null;
            this.W = []
        },
        bzZ = function(K) {
            g.nO.call(this, "serverreachability", K)
        },
        Cs = function(K) {
            K.En && (K.player.removeEventListener("presentingplayerstatechange", K.En), K.En = null)
        },
        uM = function(K, W, U) {
            Array.isArray(U) || (U = [String(U)]);
            g.gRe(K.W, W, U)
        },
        Ld3 = function(K) {
            K.j || K.J || (K.q5 = 1, g.kK(K.du, K), K.uX = 0)
        },
        fWO = function() {
            return g.vB("yt.mdx.remote.connectData_")
        },
        E$O = function(K, W) {
            W ? (K.info("onConnectedScreenId_: Received screenId: " + W), K.j && K.j.id == W || K.lJ(W, function(U) {
                eM(K, U)
            }, function() {
                return K.uK()
            }, 5)) : K.uK(Error("Waiting for session status timed out."))
        },
        G7f = function(K) {
            if (K.M5) {
                if (K.M5.locationOverrideToken) return {
                    locationOverrideToken: K.M5.locationOverrideToken
                };
                if (K.M5.latitudeE7 != null && K.M5.longitudeE7 != null) return {
                    latitudeE7: K.M5.latitudeE7,
                    longitudeE7: K.M5.longitudeE7
                }
            }
            return null
        },
        st3 = function(K) {
            Otv(K);
            K.uX = g.FE(function() {
                E_(K, "getNowPlaying")
            }, 2E4)
        },
        wyN = function(K) {
            return Zzv(K.j).map(function(W) {
                var U = K.X;
                W = W.map;
                "__data__" in W ? (W = W.__data__, U = U.W ? oEI(W) : W) : U = W;
                return U
            })
        },
        rm = function(K) {
            g.Vk("yt.mdx.remote.connectData_", K)
        },
        VRb = function() {
            var K = SKF;
            kEI();
            sO.push(K);
            BcH()
        },
        E_ = function(K, W, U) {
            U ? v0("Sending: action=" + W + ", params=" + g.rc(U)) : v0("Sending: action=" + W);
            K.X.sendMessage(W, U)
        },
        o$f = function(K, W) {
            var U = (Date.now() - XRj) / 1E3;
            U.toFixed && (U = U.toFixed(3));
            var h = [];
            h.push("[", U + "s", "] ");
            h.push("[", "yt.mdx.remote", "] ");
            h.push(K + ": " + W, "\n");
            return h.join("")
        },
        BVf = function(K, W, U) {
            K.info("onConnectedScreenData_: Received screenData: " + JSON.stringify(W));
            var h = new tz(W);
            A73(K, h, function(m) {
                m ? (K.Ns = !0, Az(K.W, h), eM(K, h), K.jV = "unknown", J7v(K, U)) : (g.aH(Error("CastSession, RemoteScreen from screenData: " + JSON.stringify(W) + " is not online.")), K.uK())
            }, 5)
        },
        v$N = function() {},
        NnI = function(K, W) {
            g.Uj.call(this);
            var U = this;
            this.handler = K();
            this.handler.subscribe("handlerOpened", this.EE, this);
            this.handler.subscribe("handlerClosed", this.onClosed, this);
            this.handler.subscribe("handlerError", function(h, m) {
                U.onError(m)
            });
            this.handler.subscribe("handlerMessage", this.onMessage, this);
            this.j = W
        },
        CK = function(K) {
            var W = CEO();
            W.dispatchEvent(new QhW(W, K))
        },
        RNn = function(K, W, U) {
            var h = document.createElement("script");
            h.onerror = W;
            U && (h.onload = U);
            g.sq(h, g.o4(K));
            (document.head || document.documentElement).appendChild(h)
        },
        b7v = function() {
            vQF();
            return tn ? !!tn.get("yt-remote-use-staging-server") : !1
        },
        Ilb = function(K, W) {
            g.BX(K, W) || K.push(W)
        },
        LK = function() {
            return !!g.SZ("yt-remote-cast-installed")
        },
        zu = function(K, W) {
            aWt(K);
            K.W.setPlayerContextData(yCN(W));
            Sjf(K)
        },
        oB = function(K, W, U, h) {
            h = h === void 0 ? !1 : h;
            g.GP.call(this);
            var m = this;
            this.G = NaN;
            this.DA = !1;
            this.jV = this.J = this.uX = this.Ns = NaN;
            this.Ms = [];
            this.U = this.Y = this.W = this.j = this.X = null;
            this.Le = K;
            this.eV = h;
            this.Ms.push(g.JD(window, "beforeunload", function() {
                m.z3(2)
            }));
            this.N = [];
            this.j = new Ee;
            this.tK = W.id;
            this.hK = W.idType;
            this.X = Ait(this.Le, U, this.Rm, this.hK == "shortLived", this.tK);
            this.X.listen("channelOpened", function() {
                y7I(m)
            });
            this.X.listen("channelClosed", function() {
                v0("Channel closed");
                isNaN(m.G) ? Fv(!0) : Fv();
                m.dispose()
            });
            this.X.listen("channelError", function(S) {
                Fv();
                isNaN(m.I2()) ? (S == 1 && m.hK == "shortLived" && m.publish("browserChannelAuthError", S), v0("Channel error: " + S + " without reconnection"), m.dispose()) : (m.DA = !0, v0("Channel error: " + S + " with reconnection in " + m.I2() + " ms"), e4(m, 2))
            });
            this.X.listen("channelMessage", function(S) {
                wN4(m, S)
            });
            this.X.mq(W.token);
            this.subscribe("remoteQueueChange", function() {
                var S = m.j.videoId;
                g.tA() && g.SI("yt-remote-session-video-id", S)
            })
        },
        dqZ = function(K, W) {
            return g.yT(K, W)
        },
        bM = function(K, W) {
            g.GP.call(this);
            this.config_ = W;
            this.X = K;
            this.J = W.appId || "233637DE";
            this.W = W.theme || "cl";
            this.jV = W.disableCastApi || !1;
            this.G = W.forceMirroring || !1;
            this.j = null;
            this.Y = !1;
            this.N = [];
            this.U = (0, g.wr)(this.LGA, this)
        },
        D_ = function(K, W, U) {
            return (0, g.wr)(function(h) {
                this.dS("Failed to " + W + " with cast v2 channel. Error code: " + h.code);
                h.code != chrome.cast.ErrorCode.TIMEOUT && (this.dS("Retrying " + W + " using MDx browser channel."), BU(this, W, U))
            }, K)
        },
        U1v = function(K, W, U) {
            K.F3 = 1;
            K.By = g7(W.clone());
            K.E2 = U;
            K.hK = !0;
            V8j(K, null)
        },
        qIW = function(K, W, U) {
            K.info("initOnConnectedScreenDataPromise_: Received screenData: " + JSON.stringify(W));
            var h = new tz(W);
            return (new Promise(function(m) {
                iSI(K, h, function(S) {
                    S ? (K.uX = !0, Az(K.W, h), eM(K, h), V9(K, U)) : g.aH(Error("DialSession, RemoteScreen from screenData: " + JSON.stringify(W) + " is not online."));
                    m(S)
                }, 5)
            })).then(function(m) {
                return m ? new chrome.cast.DialLaunchResponse(!1) : VSN(K)
            })
        },
        x0F = function(K) {
            return !!document.currentScript && (document.currentScript.src.indexOf("?" + K) != -1 || document.currentScript.src.indexOf("&" + K) != -1)
        },
        V9 = function(K, W) {
            K.info("getDialAppInfoWithTimeout_ " + W);
            s_(K) && (g.qE(K.Y), K.Y = 0, W == 0 ? flb(K) : K.Y = g.FE(function() {
                flb(K)
            }, W))
        },
        Cyh = function(K) {
            var W = K.j.G;
            W != null ? (y9(5), W ? (y9(11), fs(K.j, K, !1)) : (y9(12), fs(K.j, K, !0))) : (K.N4 = new bA(K), K.N4.w2 = K.LI, W = K.j, W = R7(W, W.Eg() ? K.PV : null, K.zn), y9(5), uM(W, "TYPE", "xmlhttp"), Xyf(K.N4, W, !1, K.PV, !1))
        },
        lUt = function(K) {
            var W = K.Ns();
            W ? K.W["x-youtube-lounge-xsrf-token"] = W : delete K.W["x-youtube-lounge-xsrf-token"]
        },
        aUO = function(K, W) {
            Ks().init(K, W)
        },
        w7 = function(K, W, U, h, m) {
            try {
                m && (m.onload = null, m.onerror = null, m.onabort = null, m.ontimeout = null), h(U)
            } catch (S) {}
        },
        VSN = function(K) {
            return new Promise(function(W) {
                K.DA = TlI();
                if (K.Le) {
                    var U = new chrome.cast.DialLaunchResponse(!0, sP4(K));
                    W(U);
                    UJv(K)
                } else K.Ms = function() {
                    g.qE(K.jV);
                    K.Ms = function() {};
                    K.jV = NaN;
                    var h = new chrome.cast.DialLaunchResponse(!0, sP4(K));
                    W(h);
                    UJv(K)
                }, K.jV = g.FE(function() {
                    K.Ms()
                }, 100)
            })
        },
        erH = function(K, W) {
            var U = parseInt(W.params.currentTime || W.params.current_time, 10);
            F6(K.j, isNaN(U) ? 0 : U);
            U = parseInt(W.params.state, 10);
            U = isNaN(U) ? -1 : U;
            U == -1 && K.j.playerState == -1E3 && (U = -1E3);
            K.j.playerState = U;
            U = Number(W.params.loadedTime);
            K.j.J = isNaN(U) ? 0 : U;
            K.j.BY(Number(W.params.duration));
            U = K.j;
            var h = Number(W.params.liveIngestionTime);
            U.j = h;
            U.W = isNaN(h) ? !1 : !0;
            U = K.j;
            h = Number(W.params.seekableStartTime);
            W = Number(W.params.seekableEndTime);
            U.X = isNaN(h) ? 0 : h;
            U.Y = isNaN(W) ? 0 : W;
            K.j.playerState == 1 ? st3(K) : Otv(K);
            K.publish("remotePlayerChange")
        },
        IUW = function(K) {
            K = g.yb(K.N, function(W) {
                return W.idType !=
                    "shortLived"
            });
            g.SI("yt-remote-automatic-screen-cache", g.CB(K, L0I))
        },
        LFv = function(K) {
            var W = K.j.media,
                U = K.j.customData;
            if (W && U) {
                var h = h$(K);
                W.contentId != h.videoId && Nu("Cast changing video to: " + W.contentId);
                h.videoId = W.contentId;
                h.playerState = U.playerState;
                F6(h, K.j.getEstimatedTime());
                zu(K, h)
            } else Nu("No cast media video. Ignoring state update.")
        },
        B0 = function(K, W) {
            g.It.call(this, "Ph\u00e1t tr\u00ean", 1, K, W);
            this.D = K;
            this.sS = {};
            this.S(K, "onMdxReceiversChange", this.X);
            this.S(K, "presentingplayerstatechange", this.X);
            this.X()
        },
        lWZ = function() {
            var K = g.i5().search(/ (CrMo|Chrome|CriOS)\//) >= 0;
            return g.Nl || K
        },
        HU = function(K) {
            switch (K.playerState) {
                case 1:
                case 1081:
                    return (g.hi() - K.U) / 1E3 + K.G;
                case -1E3:
                    return 0
            }
            return K.G
        },
        x1f = function() {
            var K = o7();
            this.j = K;
            K.jD("/client_streamz/youtube/living_room/mdx/channel/opened", g.Mk("channel_type"))
        },
        DqF = function(K) {
            g.qE(K.G);
            K.G = NaN
        };
    g.jL.prototype.Xb = g.on(49, function() {
        this.app.FK().Xb()
    });
    g.Nz.prototype.Xb = g.on(48, function() {
        this.zz = null
    });
    g.jL.prototype.vJ = g.on(47, function(K) {
        this.app.FK().vJ(K)
    });
    g.Nz.prototype.vJ = g.on(46, function(K) {
        this.zz = K
    });
    x1f.prototype.Vh = function(K) {
        this.j.xF("/client_streamz/youtube/living_room/mdx/channel/opened", K)
    };
    K1f.prototype.Vh = function(K) {
        this.j.xF("/client_streamz/youtube/living_room/mdx/channel/closed", K)
    };
    CpO.prototype.Vh = function(K) {
        this.j.xF("/client_streamz/youtube/living_room/mdx/channel/message_received", K)
    };
    nRZ.prototype.Vh = function() {
        this.j.xF("/client_streamz/youtube/living_room/mdx/channel/success")
    };
    llt.prototype.Vh = function(K, W) {
        this.j.xF("/client_streamz/youtube/living_room/mdx/channel/error", K, W)
    };
    jHI.prototype.Vh = function() {
        this.j.xF("/client_streamz/youtube/living_room/mdx/browser_channel/pending_maps")
    };
    tDO.prototype.Vh = function() {
        this.j.xF("/client_streamz/youtube/living_room/mdx/browser_channel/undelivered_maps")
    };
    g.H = Ue.prototype;
    g.H.hC = function() {
        O_(this);
        for (var K = [], W = 0; W < this.j.length; W++) K.push(this.X[this.j[W]]);
        return K
    };
    g.H.FA = function() {
        O_(this);
        return this.j.concat()
    };
    g.H.has = function(K) {
        return YO(this.X, K)
    };
    g.H.equals = function(K, W) {
        if (this === K) return !0;
        if (this.size != K.size) return !1;
        W = W || GWn;
        O_(this);
        for (var U, h = 0; U = this.j[h]; h++)
            if (!W(this.get(U), K.get(U))) return !1;
        return !0
    };
    g.H.isEmpty = function() {
        return this.size == 0
    };
    g.H.clear = function() {
        this.X = {};
        this.Gk = this.size = this.j.length = 0
    };
    g.H.remove = function(K) {
        return this.delete(K)
    };
    g.H.delete = function(K) {
        return YO(this.X, K) ? (delete this.X[K], --this.size, this.Gk++, this.j.length > 2 * this.size && O_(this), !0) : !1
    };
    g.H.get = function(K, W) {
        return YO(this.X, K) ? this.X[K] : W
    };
    g.H.set = function(K, W) {
        YO(this.X, K) || (this.size += 1, this.j.push(K), this.Gk++);
        this.X[K] = W
    };
    g.H.forEach = function(K, W) {
        for (var U = this.FA(), h = 0; h < U.length; h++) {
            var m = U[h],
                S = this.get(m);
            K.call(W, S, m, this)
        }
    };
    g.H.clone = function() {
        return new Ue(this)
    };
    g.H.keys = function() {
        return g.TyY(this.Cv(!0)).j()
    };
    g.H.values = function() {
        return g.TyY(this.Cv(!1)).j()
    };
    g.H.entries = function() {
        var K = this;
        return c6h(this.keys(), function(W) {
            return [W, K.get(W)]
        })
    };
    g.H.Cv = function(K) {
        O_(this);
        var W = 0,
            U = this.Gk,
            h = this,
            m = new g.Gl;
        m.next = function() {
            if (U != h.Gk) throw Error("The map has changed since the iterator was created");
            if (W >= h.j.length) return g.dg;
            var S = h.j[W++];
            return g.JN(K ? S : h.X[S])
        };
        return m
    };
    var bSj = {
            DNA: "atp",
            mRk: "ska",
            FuU: "que",
            vVx: "mus",
            nok: "sus",
            QCs: "dsp",
            u5e: "seq",
            m35: "mic",
            d4x: "dpa",
            ZlK: "mlm",
            hpr: "dsdtr",
            EVm: "ntb",
            NPx: "vsp",
            YC5: "scn",
            Rdm: "rpe",
            WyH: "dcn",
            TXU: "dcp",
            pMX: "pas",
            aaX: "drq",
            Plm: "opf",
            Zvx: "els",
            GPU: "isg",
            yfe: "svq",
            YYk: "mvp",
            HfX: "ads",
            Yws: "stcp",
            Owk: "sads",
            OvH: "dloc",
            HvA: "dcw",
            Lt5: "asw",
            nM5: "apw",
            m$r: "wrc",
            DXx: "pcw",
            fUm: "ipv",
            RhU: "ndt",
            xNe: "ctops"
        },
        J6t = {
            Qes: "u",
            som: "cl",
            grk: "k",
            zaK: "i",
            paU: "cr",
            SY5: "m",
            PTX: "g",
            L$: "up"
        },
        izj = {
            R4: "adPlaying",
            rV: "onAdStateChange"
        },
        zmt = {
            FRs: "nowPlaying",
            cFp: "onStateChange",
            R4: "adPlaying",
            rV: "onAdStateChange",
            jP: "nowPlayingShorts",
            bz: "onShortsStateChange"
        },
        NVH = {
            jP: "nowPlayingShorts",
            bz: "onShortsStateChange"
        };
    qA.prototype.equals = function(K) {
        return K ? this.id == K.id : !1
    };
    var DtF = "",
        tn = null;
    g.V(EEh, g.WH);
    var qu, NlN = x0F("loadCastFramework") || x0F("loadCastApplicationFramework"),
        DJW = ["pkedcjkdefgpdelpbcmbmeomcjbeemfm", "enhhojjnijigcajfphajepfemndkmdlo"];
    g.sJ(RB, g.p);
    g.H = RB.prototype;
    g.H.GF = function(K) {
        this.W = arguments;
        this.j = !1;
        this.In ? this.N = g.hi() + this.y6 : this.In = g.GB(this.U, this.y6)
    };
    g.H.stop = function() {
        this.In && (g.qs.clearTimeout(this.In), this.In = null);
        this.N = null;
        this.j = !1;
        this.W = []
    };
    g.H.pause = function() {
        ++this.X
    };
    g.H.resume = function() {
        this.X && (--this.X, !this.X && this.j && (this.j = !1, this.G.apply(null, this.W)))
    };
    g.H.QH = function() {
        this.stop();
        RB.j7.QH.call(this)
    };
    g.H.Z8 = function() {
        this.In && (g.qs.clearTimeout(this.In), this.In = null);
        this.N ? (this.In = g.GB(this.U, this.N - g.hi()), this.N = null) : this.X ? this.j = !0 : (this.j = !1, this.G.apply(null, this.W))
    };
    Jz.prototype.stringify = function(K) {
        return g.qs.JSON.stringify(K, void 0)
    };
    Jz.prototype.parse = function(K) {
        return g.qs.JSON.parse(K, void 0)
    };
    g.sJ(NvH, g.nO);
    g.sJ(r7N, g.nO);
    var RrI = null;
    g.sJ(cMH, g.nO);
    g.sJ(QhW, g.nO);
    g.sJ(l6F, g.nO);
    a7.prototype.debug = function() {};
    a7.prototype.info = function() {};
    a7.prototype.warning = function() {};
    var jtv = {},
        hmj = {};
    g.H = ns.prototype;
    g.H.setTimeout = function(K) {
        this.Ik = K
    };
    g.H.vk = function(K) {
        K = K.target;
        var W = this.Bp;
        W && g.ez(K) == 3 ? W.CQ() : this.hX(K)
    };
    g.H.hX = function(K) {
        try {
            if (K == this.j) a: {
                var W = g.ez(this.j),
                    U = this.j.X,
                    h = this.j.getStatus();
                if (!(W < 3) && (W != 3 || this.j && (this.X.X || g.FU(this.j) || g.VS(this.j)))) {
                    this.eV || W != 4 || U == 7 || (U == 8 || h <= 0 ? lA(3) : lA(2));
                    Yjh(this);
                    var m = this.j.getStatus();
                    this.Qg = m;
                    var S = fUn(this);
                    if (this.G = m == 200) {
                        if (this.W3 && !this.vp) {
                            b: {
                                if (this.j) {
                                    var f = g.i1(this.j, "X-HTTP-Initial-Response");
                                    if (f && !g.YD(f)) {
                                        var G = f;
                                        break b
                                    }
                                }
                                G = null
                            }
                            if (K = G) this.vp = !0,
                            FFv(this, K);
                            else {
                                this.G = !1;
                                this.U = 3;
                                CK(12);
                                dC(this);
                                NA(this);
                                break a
                            }
                        }
                        if (this.hK) {
                            K = !0;
                            for (var I; !this.eV && this.Y < S.length;)
                                if (I = m0O(this, S), I == hmj) {
                                    W == 4 && (this.U = 4, CK(14), K = !1);
                                    break
                                } else if (I == jtv) {
                                this.U = 4;
                                CK(15);
                                K = !1;
                                break
                            } else FFv(this, I);
                            ZSn(this) && this.Y != 0 && (this.X.j = this.X.j.slice(this.Y), this.Y = 0);
                            W != 4 || S.length != 0 || this.X.X || (this.U = 1, CK(16), K = !1);
                            this.G = this.G && K;
                            K ? S.length > 0 && !this.DO && (this.DO = !0, this.N.Jk(this)) : (dC(this), NA(this))
                        } else FFv(this, S);
                        W == 4 && dC(this);
                        this.G && !this.eV && (W == 4 ? UqI(this.N, this) : (this.G = !1, Kb(this)))
                    } else g.MEY(this.j), m == 400 && S.indexOf("Unknown SID") >
                        0 ? (this.U = 3, CK(12)) : (this.U = 0, CK(13)), dC(this), NA(this)
                }
            }
        } catch (d) {} finally {}
    };
    g.H.cancel = function() {
        this.eV = !0;
        dC(this)
    };
    g.H.Yb = function() {
        this.Ms = null;
        var K = Date.now();
        K - this.gk >= 0 ? (this.tK != 2 && (lA(3), CK(17)), dC(this), this.U = 2, NA(this)) : k$n(this, this.gk - K)
    };
    g.H.getLastError = function() {
        return this.U
    };
    g.H.RO = function() {
        return this.j
    };
    $tO.prototype.cancel = function() {
        this.N = IbZ(this);
        if (this.X) this.X.cancel(), this.X = null;
        else if (this.j && this.j.size !== 0) {
            for (var K = g.z(this.j.values()), W = K.next(); !W.done; W = K.next()) W.value.cancel();
            this.j.clear()
        }
    };
    g.H = uIN.prototype;
    g.H.Ud = 8;
    g.H.p_ = 1;
    g.H.connect = function(K, W, U, h) {
        CK(0);
        this.Ez = K;
        this.eV = W || {};
        U && h !== void 0 && (this.eV.OSID = U, this.eV.OAID = h);
        this.Bp = this.XI;
        this.Le = e_W(this, null, this.Ez);
        I7(this)
    };
    g.H.disconnect = function() {
        j1I(this);
        if (this.p_ == 3) {
            var K = this.JK++,
                W = this.Le.clone();
            g.aT(W, "SID", this.W);
            g.aT(W, "RID", K);
            g.aT(W, "TYPE", "terminate");
            Zw(this, W);
            K = new ns(this, this.W, K);
            K.tK = 2;
            K.J = g7(W.clone());
            W = !1;
            if (g.qs.navigator && g.qs.navigator.sendBeacon) try {
                W = g.qs.navigator.sendBeacon(K.J.toString(), "")
            } catch (U) {}!W && g.qs.Image && ((new Image).src = K.J, W = !0);
            W || (K.j = NcO(K.N, null), K.j.send(K.J));
            K.Ns = Date.now();
            Kb(K)
        }
        OG3(this)
    };
    g.H.CC = function() {
        return this.p_ == 0
    };
    g.H.getState = function() {
        return this.p_
    };
    g.H.Dm = function(K) {
        if (this.G)
            if (this.G = null, this.p_ == 1) {
                if (!K) {
                    this.JK = Math.floor(Math.random() * 1E5);
                    K = this.JK++;
                    var W = new ns(this, "", K),
                        U = this.jV;
                    this.W3 && (U ? (U = g.Ni(U), g.Zc(U, this.W3)) : U = this.W3);
                    this.Y !== null || this.gk || (W.Le = U, U = null);
                    var h;
                    if (this.M5) a: {
                        for (var m = h = 0; m < this.N.length; m++) {
                            b: {
                                var S = this.N[m];
                                if ("__data__" in S.map && (S = S.map.__data__, typeof S === "string")) {
                                    S = S.length;
                                    break b
                                }
                                S = void 0
                            }
                            if (S === void 0) break;h += S;
                            if (h > 4096) {
                                h = m;
                                break a
                            }
                            if (h === 4096 || m === this.N.length - 1) {
                                h = m + 1;
                                break a
                            }
                        }
                        h =
                        1E3
                    }
                    else h = 1E3;
                    h = KAv(this, W, h);
                    m = this.Le.clone();
                    g.aT(m, "RID", K);
                    g.aT(m, "CVER", 22);
                    this.hK && g.aT(m, "X-HTTP-Session-Id", this.hK);
                    Zw(this, m);
                    U && (this.gk ? h = "headers=" + g.kH(g.mKD(U)) + "&" + h : this.Y && g.w_(m, this.Y, U));
                    $1F(this.X, W);
                    this.u5 && g.aT(m, "TYPE", "init");
                    this.M5 ? (g.aT(m, "$req", h), g.aT(m, "SID", "null"), W.W3 = !0, F0O(W, m, null)) : F0O(W, m, h);
                    this.p_ = 2
                }
            } else this.p_ == 3 && (K ? xJn(this, K) : this.N.length == 0 || xqI(this.X) || xJn(this))
    };
    g.H.du = function() {
        this.J = null;
        pyZ(this);
        if (this.oW && !(this.Ik || this.j == null || this.Ny <= 0)) {
            var K = 4 * this.Ny;
            this.DA = OO((0, g.wr)(this.qaV, this), K)
        }
    };
    g.H.qaV = function() {
        this.DA && (this.DA = null, this.Bp = !1, this.Ik = !0, CK(10), J$(this), pyZ(this))
    };
    g.H.Jk = function(K) {
        this.j == K && this.oW && !this.Ik && (va4(this), this.Ik = !0, CK(11))
    };
    g.H.SS = function() {
        this.Ms != null && (this.Ms = null, J$(this), W0H(this), CK(19))
    };
    g.H.nqU = function(K) {
        K ? CK(2) : CK(1)
    };
    g.H.isActive = function() {
        return !!this.U && this.U.isActive(this)
    };
    g.H = v$N.prototype;
    g.H.zU = function() {};
    g.H.m2 = function() {};
    g.H.Lb = function() {};
    g.H.Hw = function() {};
    g.H.isActive = function() {
        return !0
    };
    g.H.A4 = function() {};
    g.sJ(Yt, g.Uj);
    Yt.prototype.open = function() {
        this.j.U = this.N;
        this.G && (this.j.vp = !0);
        this.j.connect(this.U, this.X || void 0)
    };
    Yt.prototype.close = function() {
        this.j.disconnect()
    };
    Yt.prototype.send = function(K) {
        var W = this.j;
        if (typeof K === "string") {
            var U = {};
            U.__data__ = K;
            K = U
        } else this.W && (U = {}, U.__data__ = g.rc(K), K = U);
        W.N.push(new zNn(W.pC++, K));
        W.p_ == 3 && I7(W)
    };
    Yt.prototype.QH = function() {
        this.j.U = null;
        delete this.N;
        this.j.disconnect();
        delete this.j;
        Yt.j7.QH.call(this)
    };
    g.sJ(OzI, NvH);
    g.sJ(MRZ, r7N);
    g.sJ($t, v$N);
    $t.prototype.zU = function() {
        this.j.dispatchEvent("m")
    };
    $t.prototype.m2 = function(K) {
        this.j.dispatchEvent(new OzI(K))
    };
    $t.prototype.Lb = function(K) {
        this.j.dispatchEvent(new MRZ(K))
    };
    $t.prototype.Hw = function() {
        this.j.dispatchEvent("n")
    };
    qDj.prototype.commit = function(K) {
        this.j.Qg = K
    };
    var Jn = new g.Uj;
    g.V(tRn, g.nO);
    g.H = bA.prototype;
    g.H.w2 = null;
    g.H.KM = !1;
    g.H.Ka = null;
    g.H.Hq = null;
    g.H.w8 = null;
    g.H.F3 = null;
    g.H.By = null;
    g.H.KQ = null;
    g.H.E2 = null;
    g.H.BN = null;
    g.H.Rs = 0;
    g.H.Q5 = null;
    g.H.Is = null;
    g.H.s2 = null;
    g.H.VG = -1;
    g.H.i6 = !0;
    g.H.Jo = !1;
    g.H.DK = 0;
    g.H.E$ = null;
    var M8W = {},
        yiZ = {};
    g.H = bA.prototype;
    g.H.setTimeout = function(K) {
        this.X = K
    };
    g.H.J4 = function(K) {
        K = K.target;
        var W = this.E$;
        W && g.ez(K) == 3 ? W.CQ() : this.kf(K)
    };
    g.H.kf = function(K) {
        try {
            if (K == this.BN) a: {
                var W = g.ez(this.BN),
                    U = this.BN.X,
                    h = this.BN.getStatus();
                if (g.$U && !g.rs("420+")) {
                    if (W < 4) break a
                } else if (W < 3 || W == 3 && !g.FU(this.BN)) break a;this.Jo || W != 4 || U == 7 || (U == 8 || h <= 0 ? this.j.Cn(3) : this.j.Cn(2));S2n(this);
                var m = this.BN.getStatus();this.VG = m;
                var S = g.FU(this.BN);
                if (this.KM = m == 200) {
                    W == 4 && Ls(this);
                    if (this.hK) {
                        for (K = !0; !this.Jo && this.Rs < S.length;) {
                            var f = PVW(this, S);
                            if (f == yiZ) {
                                W == 4 && (this.s2 = 4, y9(15), K = !1);
                                break
                            } else if (f == M8W) {
                                this.s2 = 4;
                                y9(16);
                                K = !1;
                                break
                            } else gRn(this,
                                f)
                        }
                        W == 4 && S.length == 0 && (this.s2 = 1, y9(17), K = !1);
                        this.KM = this.KM && K;
                        K || (Ls(this), oRZ(this))
                    } else gRn(this, S);
                    this.KM && !this.Jo && (W == 4 ? this.j.ma(this) : (this.KM = !1, sHN(this)))
                } else m == 400 && S.indexOf("Unknown SID") > 0 ? (this.s2 = 3, y9(13)) : (this.s2 = 0, y9(14)),
                Ls(this),
                oRZ(this)
            }
        } catch (G) {} finally {}
    };
    g.H.cancel = function() {
        this.Jo = !0;
        Ls(this)
    };
    g.H.Bk = function() {
        this.Ka = null;
        var K = Date.now();
        K - this.Hq >= 0 ? (this.F3 != 2 && this.j.Cn(3), Ls(this), this.s2 = 2, y9(18), oRZ(this)) : rin(this, this.Hq - K)
    };
    g.H.getLastError = function() {
        return this.s2
    };
    g.H = WAn.prototype;
    g.H.LI = null;
    g.H.N4 = null;
    g.H.vj = !1;
    g.H.zn = null;
    g.H.o5 = null;
    g.H.Pg = -1;
    g.H.PV = null;
    g.H.vT = null;
    g.H.connect = function(K) {
        this.zn = K;
        K = R7(this.j, null, this.zn);
        y9(3);
        Date.now();
        var W = this.j.jV;
        W != null ? (this.PV = W[0], (this.vT = W[1]) ? (this.o5 = 1, g$j(this)) : (this.o5 = 2, Cyh(this))) : (uM(K, "MODE", "init"), this.N4 = new bA(this), this.N4.w2 = this.LI, Xyf(this.N4, K, !1, null, !0), this.o5 = 0)
    };
    g.H.Qf = function(K) {
        if (K) this.o5 = 2, Cyh(this);
        else {
            y9(4);
            var W = this.j;
            W.df = W.aA.Pg;
            MA(W, 9)
        }
        K && this.Cn(2)
    };
    g.H.nI = function(K) {
        return this.j.nI(K)
    };
    g.H.abort = function() {
        this.N4 && (this.N4.cancel(), this.N4 = null);
        this.Pg = -1
    };
    g.H.CC = function() {
        return !1
    };
    g.H.qT = function(K, W) {
        this.Pg = K.VG;
        if (this.o5 == 0)
            if (W) {
                try {
                    var U = this.X.parse(W)
                } catch (h) {
                    K = this.j;
                    K.df = this.Pg;
                    MA(K, 2);
                    return
                }
                this.PV = U[0];
                this.vT = U[1]
            } else K = this.j, K.df = this.Pg, MA(K, 2);
        else this.o5 == 2 && (this.vj ? (y9(7), Date.now()) : W == "11111" ? (y9(6), this.vj = !0, Date.now(), this.Pg = 200, this.N4.cancel(), y9(12), fs(this.j, this, !0)) : (y9(8), Date.now(), this.vj = !1))
    };
    g.H.ma = function() {
        this.Pg = this.N4.VG;
        if (this.N4.KM) this.o5 == 0 ? this.vT ? (this.o5 = 1, g$j(this)) : (this.o5 = 2, Cyh(this)) : this.o5 == 2 && (this.vj ? (y9(12), fs(this.j, this, !0)) : (y9(11), fs(this.j, this, !1)));
        else {
            this.o5 == 0 ? y9(9) : this.o5 == 2 && y9(10);
            var K = this.j;
            this.N4.getLastError();
            K.df = this.Pg;
            MA(K, 2)
        }
    };
    g.H.Eg = function() {
        return this.j.Eg()
    };
    g.H.isActive = function() {
        return this.j.isActive()
    };
    g.H.Cn = function(K) {
        this.j.Cn(K)
    };
    g.H = uxF.prototype;
    g.H.Pa = null;
    g.H.KS = null;
    g.H.BS = null;
    g.H.NZ = null;
    g.H.eb = null;
    g.H.fQ = null;
    g.H.tX = null;
    g.H.qO = null;
    g.H.F2 = 0;
    g.H.wb = 0;
    g.H.rj = null;
    g.H.F4 = null;
    g.H.cg = null;
    g.H.Fq = null;
    g.H.aA = null;
    g.H.EN = null;
    g.H.RE = -1;
    g.H.GU = -1;
    g.H.df = -1;
    g.H.IE = 0;
    g.H.FZ = 0;
    g.H.K4 = 8;
    var Kub = {
        OK: 0,
        xXk: 2,
        hhm: 4,
        IF5: 5,
        bnx: 6,
        STOP: 7,
        iz: 8,
        zFK: 9,
        nT5: 10,
        mNk: 11,
        zQr: 12
    };
    g.sJ(wRO, g.nO);
    g.sJ(bzZ, g.nO);
    g.H = uxF.prototype;
    g.H.connect = function(K, W, U, h, m) {
        y9(0);
        this.eb = W;
        this.KS = U || {};
        h && m !== void 0 && (this.KS.OSID = h, this.KS.OAID = m);
        this.J ? (DZ((0, g.wr)(this.Zy, this, K), 100), MDb(this)) : this.Zy(K)
    };
    g.H.disconnect = function() {
        h_3(this);
        if (this.j == 3) {
            var K = this.F2++,
                W = this.fQ.clone();
            g.aT(W, "SID", this.W);
            g.aT(W, "RID", K);
            g.aT(W, "TYPE", "terminate");
            A$(this, W);
            K = new bA(this, this.W, K);
            K.F3 = 2;
            K.By = g7(W.clone());
            (new Image).src = K.By.toString();
            K.w8 = Date.now();
            sHN(K)
        }
        dtH(this)
    };
    g.H.Zy = function(K) {
        this.aA = new WAn(this);
        this.aA.LI = this.Pa;
        this.aA.X = this.U;
        this.aA.connect(K)
    };
    g.H.CC = function() {
        return this.j == 0
    };
    g.H.getState = function() {
        return this.j
    };
    g.H.Yf = function(K) {
        this.F4 = null;
        EQO(this, K)
    };
    g.H.Zm = function() {
        this.cg = null;
        this.NZ = new bA(this, this.W, "rpc", this.Y);
        this.NZ.w2 = this.Pa;
        this.NZ.DK = 0;
        var K = this.tX.clone();
        g.aT(K, "RID", "rpc");
        g.aT(K, "SID", this.W);
        g.aT(K, "CI", this.EN ? "0" : "1");
        g.aT(K, "AID", this.RE);
        A$(this, K);
        g.aT(K, "TYPE", "xmlhttp");
        Xyf(this.NZ, K, !0, this.qO, !1)
    };
    g.H.qT = function(K, W) {
        if (this.j != 0 && (this.NZ == K || this.BS == K))
            if (this.df = K.VG, this.BS == K && this.j == 3)
                if (this.K4 > 7) {
                    try {
                        var U = this.U.parse(W)
                    } catch (h) {
                        U = null
                    }
                    if (Array.isArray(U) && U.length == 3)
                        if (K = U, K[0] == 0) a: {
                            if (!this.cg) {
                                if (this.NZ)
                                    if (this.NZ.w8 + 3E3 < this.BS.w8) EO(this), this.NZ.cancel(), this.NZ = null;
                                    else break a;
                                btj(this);
                                y9(19)
                            }
                        }
                    else this.GU = K[1], 0 < this.GU - this.RE && K[2] < 37500 && this.EN && this.FZ == 0 && !this.Fq && (this.Fq = DZ((0, g.wr)(this.sE, this), 6E3));
                    else MA(this, 11)
                } else W != "y2f%" && MA(this, 11);
        else if (this.NZ ==
            K && EO(this), !g.YD(W))
            for (K = this.U.parse(W), W = 0; W < K.length; W++) U = K[W], this.RE = U[0], U = U[1], this.j == 2 ? U[0] == "c" ? (this.W = U[1], this.qO = U[2], U = U[3], U != null ? this.K4 = U : this.K4 = 6, this.j = 3, this.rj && this.rj.Bw(), this.tX = R7(this, this.Eg() ? this.qO : null, this.eb), SIh(this)) : U[0] == "stop" && MA(this, 7) : this.j == 3 && (U[0] == "stop" ? MA(this, 7) : U[0] != "noop" && this.rj && this.rj.AX(U), this.FZ = 0)
    };
    g.H.sE = function() {
        this.Fq != null && (this.Fq = null, this.NZ.cancel(), this.NZ = null, btj(this), y9(20))
    };
    g.H.ma = function(K) {
        if (this.NZ == K) {
            EO(this);
            this.NZ = null;
            var W = 2
        } else if (this.BS == K) this.BS = null, W = 1;
        else return;
        this.df = K.VG;
        if (this.j != 0)
            if (K.KM)
                if (W == 1) {
                    W = K.E2 ? K.E2.length : 0;
                    K = Date.now() - K.w8;
                    var U = Jn;
                    U.dispatchEvent(new wRO(U, W, K, this.IE));
                    wYh(this);
                    this.rj && this.rj.JX(this, this.N);
                    this.N.length = 0
                } else SIh(this);
        else {
            U = K.getLastError();
            var h;
            if (!(h = U == 3 || U == 7 || U == 0 && this.df > 0)) {
                if (h = W == 1) this.BS || this.F4 || this.j == 1 || this.IE >= 2 ? h = !1 : (this.F4 = DZ((0, g.wr)(this.Yf, this, K), Zth(this, this.IE)), this.IE++,
                    h = !0);
                h = !(h || W == 2 && btj(this))
            }
            if (h) switch (U) {
                case 1:
                    MA(this, 5);
                    break;
                case 4:
                    MA(this, 10);
                    break;
                case 3:
                    MA(this, 6);
                    break;
                case 7:
                    MA(this, 12);
                    break;
                default:
                    MA(this, 2)
            }
        }
    };
    g.H.VI = function(K) {
        if (!g.BX(arguments, this.j)) throw Error("Unexpected channel state: " + this.j);
    };
    g.H.H_V = function(K) {
        K ? y9(2) : (y9(1), vEN(this, 8))
    };
    g.H.nI = function(K) {
        if (K) throw Error("Can't create secondary domain capable XhrIo object.");
        K = new g.DK;
        K.Y = !1;
        return K
    };
    g.H.isActive = function() {
        return !!this.rj && this.rj.isActive(this)
    };
    g.H.Cn = function(K) {
        var W = Jn;
        W.dispatchEvent(new bzZ(W, K))
    };
    g.H.Eg = function() {
        return !1
    };
    g.H = OSW.prototype;
    g.H.Bw = function() {};
    g.H.AX = function() {};
    g.H.JX = function() {};
    g.H.Su = function() {};
    g.H.t5 = function() {};
    g.H.VW = function() {
        return {}
    };
    g.H.isActive = function() {
        return !0
    };
    g.H = c7t.prototype;
    g.H.enqueue = function(K) {
        this.X.push(K)
    };
    g.H.isEmpty = function() {
        return this.j.length === 0 && this.X.length === 0
    };
    g.H.clear = function() {
        this.j = [];
        this.X = []
    };
    g.H.contains = function(K) {
        return g.BX(this.j, K) || g.BX(this.X, K)
    };
    g.H.remove = function(K) {
        var W = this.j;
        var U = (0, g.HsL)(W, K);
        U >= 0 ? (g.wd(W, U), W = !0) : W = !1;
        return W || g.sS(this.X, K)
    };
    g.H.hC = function() {
        for (var K = [], W = this.j.length - 1; W >= 0; --W) K.push(this.j[W]);
        W = this.X.length;
        for (var U = 0; U < W; ++U) K.push(this.X[U]);
        return K
    };
    g.V(FAW, g.nO);
    g.V(YIH, g.nO);
    g.sJ(uA, g.p);
    g.H = uA.prototype;
    g.H.bCs = function() {
        this.y6 = Math.min(3E5, this.y6 * 2);
        this.X();
        this.QE && this.start()
    };
    g.H.start = function() {
        var K = this.y6 + 15E3 * Math.random();
        g.yG(this.j, K);
        this.QE = Date.now() + K
    };
    g.H.stop = function() {
        this.j.stop();
        this.QE = 0
    };
    g.H.isActive = function() {
        return this.j.isActive()
    };
    g.H.reset = function() {
        this.j.stop();
        this.y6 = 5E3
    };
    g.sJ(it3, OSW);
    g.H = it3.prototype;
    g.H.subscribe = function(K, W, U) {
        return this.G.subscribe(K, W, U)
    };
    g.H.unsubscribe = function(K, W, U) {
        return this.G.unsubscribe(K, W, U)
    };
    g.H.M2 = function(K) {
        return this.G.M2(K)
    };
    g.H.publish = function(K, W) {
        return this.G.publish.apply(this.G, arguments)
    };
    g.H.dispose = function() {
        this.Y || (this.Y = !0, g.vZ(this.G), this.disconnect(), g.vZ(this.X), this.X = null, this.eV = function() {
            return ""
        }, this.tK = function() {
            return g.EC({})
        })
    };
    g.H.qs = function() {
        return this.Y
    };
    g.H.connect = function(K, W, U) {
        var h = this,
            m, S, f, G;
        return g.r(function(I) {
            if (I.j == 1) return g.bE(I, 2), h.U ? g.T(I, h.W, 2) : I.O5(2);
            g.VY(I);
            if (h.Y || h.j && h.j.getState() == 2) return I.return();
            h.Ns = "";
            h.X.stop();
            h.jV = K || null;
            h.J = W || 0;
            m = h.vp + "/test";
            S = h.vp + "/bind";
            f = new uxF(U ? U.firstTestResults : null, U ? U.secondTestResults : null, h.q5);
            if (G = h.j) G.rj = null;
            f.rj = h;
            h.j = f;
            if (h.U) return h.W = pYh(h).then(function() {
                return Jih(h, m, S, G, U)
            }), I.return(h.W.then(function() {
                h.W = g.EC()
            }));
            Jih(h, m, S, G, U);
            return g.vr(I, 0)
        })
    };
    g.H.disconnect = function(K) {
        try {
            this.U && (this.W.cancel(), this.W = g.EC())
        } finally {
            this.uX = K || 0, this.X && this.X.stop(), G$b(this), this.j && (this.j.getState() == 3 && EQO(this.j), this.j.disconnect()), this.uX = 0
        }
    };
    g.H.sendMessage = function(K, W) {
        var U = this,
            h;
        return g.r(function(m) {
            switch (m.j) {
                case 1:
                    g.bE(m, 2);
                    if (!U.U) {
                        m.O5(2);
                        break
                    }
                    return g.T(m, U.W, 2);
                case 2:
                    g.VY(m);
                    if (U.Y) return m.return();
                    h = {
                        _sc: K
                    };
                    W && g.Zc(h, W);
                    if (U.X.isActive() || (U.j ? U.j.getState() : 0) == 2) {
                        U.N.push(h);
                        m.O5(6);
                        break
                    }
                    if (!U.Kj()) {
                        m.O5(6);
                        break
                    }
                    g.bE(m, 8);
                    if (!U.U || ACf(U, K)) {
                        m.O5(8);
                        break
                    }
                    return g.T(m, pYh(U), 8);
                case 8:
                    g.VY(m, 0, 0, 1);
                    U.Kj() && (ACf(U, K) || IgH(U), G$b(U), F9f(U.j, h));
                    g.vr(m, 6, 1);
                    break;
                case 6:
                    g.vr(m, 0)
            }
        })
    };
    g.H.Bw = function() {
        this.hK ? (g.vZ(this.X), this.X = new uA(this.O6, this), this.hK = !1) : this.X.reset();
        this.jV = null;
        this.J = 0;
        if (this.N.length)
            if (this.U) HzI(this);
            else {
                var K = this.N;
                this.N = [];
                var W = K.length;
                IgH(this);
                MSO(this, K, W);
                Xv(this)
            }
        else Xv(this)
    };
    g.H.Su = function(K) {
        var W = K == 2 && this.j.df == 401;
        K == 4 || W || this.X.start();
        this.publish("handlerError", K, W);
        W = Object.keys(Kub).find(function(U) {
            return Kub[U] === K
        });
        this.JK.Vh("BROWSER_CHANNEL", W != null ? W : "UNKNOWN")
    };
    g.H.t5 = function(K, W) {
        if (!this.X.isActive()) this.publish("handlerClosed");
        else if (W)
            for (var U = W.length, h = 0; h < U; ++h) {
                var m = W[h].map;
                m && this.N.push(m)
            }
        this.Bp.Vh("BROWSER_CHANNEL");
        K && this.oW.j.ZK("/client_streamz/youtube/living_room/mdx/browser_channel/pending_maps", K.length);
        W && this.Ny.j.ZK("/client_streamz/youtube/living_room/mdx/browser_channel/undelivered_maps", W.length)
    };
    g.H.JX = function(K, W) {
        W != null && K != null && this.gk.Vh()
    };
    g.H.VW = function() {
        var K = {
            v: 2
        };
        this.Ns && (K.gsessionid = this.Ns);
        this.J != 0 && (K.ui = "" + this.J);
        this.uX != 0 && (K.ui = "" + this.uX);
        this.jV && g.Zc(K, this.jV);
        return K
    };
    g.H.AX = function(K) {
        K[0] == "S" ? this.Ns = K[1] : K[0] == "gracefulReconnect" ? (this.X.start(), this.j.disconnect()) : this.publish("handlerMessage", new ag4(K[0], K[1]));
        this.Pp.Vh("BROWSER_CHANNEL")
    };
    g.H.Kj = function() {
        return !!this.j && this.j.getState() == 3
    };
    g.H.mq = function(K) {
        (this.Ms.loungeIdToken = K) || this.X.stop();
        if (this.Ez && this.j) {
            var W = this.j.Pa || {};
            K ? W["X-YouTube-LoungeId-Token"] = K : delete W["X-YouTube-LoungeId-Token"];
            this.j.Pa = W
        }
    };
    g.H.getDeviceId = function() {
        return this.Ms.id
    };
    g.H.JV = function() {
        return this.X.isActive() ? this.X.QE - Date.now() : NaN
    };
    g.H.fZ = function() {
        var K = this.X;
        g.PR(K.j);
        K.start()
    };
    g.H.O6 = function() {
        this.X.isActive();
        dJf(this.j) == 0 && this.connect(this.jV, this.J)
    };
    GO.prototype.sendRequest = function(K, W, U, h, m, S, f) {
        K = {
            format: S ? "RAW" : "JSON",
            method: K,
            context: this,
            timeout: 5E3,
            withCredentials: !!f,
            onSuccess: g.jt(this.W, h, !S),
            onError: g.jt(this.N, m),
            onTimeout: g.jt(this.U, m)
        };
        U && (K.postParams = U, K.headers = {
            "Content-Type": "application/x-www-form-urlencoded"
        });
        return g.ka(W, K)
    };
    GO.prototype.W = function(K, W, U, h) {
        W ? K(h) : K({
            text: U.responseText
        })
    };
    GO.prototype.N = function(K, W) {
        K(Error("Request error: " + W.status))
    };
    GO.prototype.U = function(K) {
        K(Error("request timed out"))
    };
    g.V(NnI, g.Uj);
    g.H = NnI.prototype;
    g.H.connect = function(K, W, U) {
        this.handler.connect(K, W, U)
    };
    g.H.disconnect = function(K) {
        this.handler.disconnect(K)
    };
    g.H.fZ = function() {
        this.handler.fZ()
    };
    g.H.getDeviceId = function() {
        return this.handler.getDeviceId()
    };
    g.H.JV = function() {
        return this.handler.JV()
    };
    g.H.Kj = function() {
        return this.handler.Kj()
    };
    g.H.EE = function() {
        this.dispatchEvent("channelOpened");
        var K = this.handler,
            W = this.j;
        g.SI("yt-remote-session-browser-channel", {
            firstTestResults: [""],
            secondTestResults: !K.j.EN,
            sessionId: K.j.W,
            arrayId: K.j.RE
        });
        g.SI("yt-remote-session-screen-id", W);
        K = fK();
        W = t$();
        g.BX(K, W) || K.push(W);
        fbW(K);
        XrF()
    };
    g.H.onClosed = function() {
        this.dispatchEvent("channelClosed")
    };
    g.H.onMessage = function(K) {
        this.dispatchEvent(new FAW(K))
    };
    g.H.onError = function(K) {
        this.dispatchEvent(new YIH(K ? 1 : 0))
    };
    g.H.sendMessage = function(K, W) {
        this.handler.sendMessage(K, W)
    };
    g.H.mq = function(K) {
        this.handler.mq(K)
    };
    g.H.dispose = function() {
        this.handler.dispose()
    };
    g.H = L1n.prototype;
    g.H.connect = function(K, W) {
        K = K === void 0 ? {} : K;
        W = W === void 0 ? 0 : W;
        this.G !== 2 && (this.N.stop(), this.J = K, this.Y = W, lUt(this), (K = g.TA("ID_TOKEN")) ? this.W["x-youtube-identity-token"] = K : delete this.W["x-youtube-identity-token"], this.j && (this.X.device = this.j.device, this.X.name = this.j.name, this.X.app = this.j.app, this.X.id = this.j.id, this.j.IO5 && (this.X.mdxVersion = "" + this.j.IO5), this.j.theme && (this.X.theme = this.j.theme), this.j.capabilities && (this.X.capabilities = this.j.capabilities), this.j.eZ && (this.X.cst = this.j.eZ),
            this.j.authuser && (this.X.authuser = this.j.authuser), this.j.pageId && (this.X.pageId = this.j.pageId)), this.Y !== 0 ? this.X.ui = "" + this.Y : delete this.X.ui, Object.assign(this.X, this.J), this.channel = new Yt(this.pathPrefix, {
            fAe: "gsessionid",
            fOx: this.W,
            c7k: this.X
        }), this.channel.open(), this.G = 2, QHN(this))
    };
    g.H.disconnect = function(K) {
        this.jV = K === void 0 ? 0 : K;
        this.N.stop();
        lUt(this);
        this.channel && (this.jV !== 0 ? this.X.ui = "" + this.jV : delete this.X.ui, this.channel.close());
        this.jV = 0
    };
    g.H.JV = function() {
        return this.N.isActive() ? this.N.QE - Date.now() : NaN
    };
    g.H.fZ = function() {
        var K = this.N;
        g.PR(K.j);
        K.start()
    };
    g.H.sendMessage = function(K, W) {
        this.channel && (lUt(this), K = Object.assign({}, {
            _sc: K
        }, W), this.channel.send(K))
    };
    g.H.mq = function(K) {
        K || this.N.stop();
        K ? this.W["X-YouTube-LoungeId-Token"] = K : delete this.W["X-YouTube-LoungeId-Token"]
    };
    g.H.getDeviceId = function() {
        return this.j ? this.j.id : ""
    };
    g.H.publish = function(K) {
        return this.U.publish.apply(this.U, [K].concat(g.z4(g.Xl.apply(1, arguments))))
    };
    g.H.subscribe = function(K, W, U) {
        return this.U.subscribe(K, W, U)
    };
    g.H.unsubscribe = function(K, W, U) {
        return this.U.unsubscribe(K, W, U)
    };
    g.H.M2 = function(K) {
        return this.U.M2(K)
    };
    g.H.dispose = function() {
        this.Ms || (this.Ms = !0, g.vZ(this.U), this.disconnect(), g.vZ(this.N), this.Ns = function() {
            return ""
        })
    };
    g.H.qs = function() {
        return this.Ms
    };
    g.V(z_Z, g.Uj);
    g.H = z_Z.prototype;
    g.H.connect = function(K, W) {
        this.j.connect(K, W)
    };
    g.H.disconnect = function(K) {
        this.j.disconnect(K)
    };
    g.H.fZ = function() {
        this.j.fZ()
    };
    g.H.getDeviceId = function() {
        return this.j.getDeviceId()
    };
    g.H.JV = function() {
        return this.j.JV()
    };
    g.H.Kj = function() {
        return this.j.G === 3
    };
    g.H.Ki = function() {
        this.dispatchEvent("channelOpened")
    };
    g.H.onClosed = function() {
        this.dispatchEvent("channelClosed")
    };
    g.H.onMessage = function(K) {
        this.dispatchEvent(new FAW(K))
    };
    g.H.onError = function() {
        this.dispatchEvent(new YIH(this.j.Bo === 401 ? 1 : 0))
    };
    g.H.sendMessage = function(K, W) {
        this.j.sendMessage(K, W)
    };
    g.H.mq = function(K) {
        this.j.mq(K)
    };
    g.H.dispose = function() {
        this.j.dispose()
    };
    var XRj = Date.now(),
        sO = null,
        V0 = Array(50),
        v9 = -1,
        X6 = !1;
    g.sJ(IB, g.GP);
    IB.prototype.Ha = function() {
        return this.screens
    };
    IB.prototype.contains = function(K) {
        return !!mq4(this.screens, K)
    };
    IB.prototype.get = function(K) {
        return K ? m4(this.screens, K) : null
    };
    IB.prototype.info = function(K) {
        m_(this.G, K)
    };
    g.V(IWH, g.GP);
    g.H = IWH.prototype;
    g.H.start = function() {
        !this.j && isNaN(this.In) && this.mV()
    };
    g.H.stop = function() {
        this.j && (this.j.abort(), this.j = null);
        isNaN(this.In) || (g.qE(this.In), this.In = NaN)
    };
    g.H.QH = function() {
        this.stop();
        g.GP.prototype.QH.call(this)
    };
    g.H.mV = function() {
        this.In = NaN;
        this.j = g.ka($O(this.N, "/pairing/get_screen"), {
            method: "POST",
            postParams: {
                pairing_code: this.Y
            },
            timeout: 5E3,
            onSuccess: (0, g.wr)(this.I3, this),
            onError: (0, g.wr)(this.FF, this),
            onTimeout: (0, g.wr)(this.R3, this)
        })
    };
    g.H.I3 = function(K, W) {
        this.j = null;
        K = W.screen || {};
        K.dialId = this.W;
        K.name = this.G;
        W = -1;
        this.U && K.shortLivedLoungeToken && K.shortLivedLoungeToken.value && K.shortLivedLoungeToken.refreshIntervalMs && (K.screenIdType = "shortLived", K.loungeToken = K.shortLivedLoungeToken.value, W = K.shortLivedLoungeToken.refreshIntervalMs);
        this.publish("pairingComplete", new tz(K), W)
    };
    g.H.FF = function(K) {
        this.j = null;
        K.status && K.status == 404 ? this.X >= Wuh.length ? this.publish("pairingFailed", Error("DIAL polling timed out")) : (K = Wuh[this.X], this.In = g.FE((0, g.wr)(this.mV, this), K), this.X++) : this.publish("pairingFailed", Error("Server error " + K.status))
    };
    g.H.R3 = function() {
        this.j = null;
        this.publish("pairingFailed", Error("Server not responding"))
    };
    var Wuh = [2E3, 2E3, 1E3, 1E3, 1E3, 2E3, 2E3, 5E3, 5E3, 1E4];
    g.sJ(Gu, IB);
    g.H = Gu.prototype;
    g.H.start = function() {
        dm(this) && this.publish("screenChange");
        !g.SZ("yt-remote-lounge-token-expiration") && cCj(this);
        g.qE(this.j);
        this.j = g.FE((0, g.wr)(this.start, this), 1E4)
    };
    g.H.add = function(K, W) {
        dm(this);
        uJt(this, K);
        pK(this, !1);
        this.publish("screenChange");
        W(K);
        K.token || cCj(this)
    };
    g.H.remove = function(K, W) {
        var U = dm(this);
        n$O(this, K) && (pK(this, !1), U = !0);
        W(K);
        U && this.publish("screenChange")
    };
    g.H.w3 = function(K, W, U, h) {
        var m = dm(this),
            S = this.get(K.id);
        S ? (S.name != W && (S.name = W, pK(this, !1), m = !0), U(K)) : h(Error("no such local screen."));
        m && this.publish("screenChange")
    };
    g.H.QH = function() {
        g.qE(this.j);
        Gu.j7.QH.call(this)
    };
    g.H.LrA = function(K) {
        dm(this);
        var W = this.screens.length;
        K = K && K.screens || [];
        for (var U = K.length, h = 0; h < U; ++h) {
            var m = K[h],
                S = this.get(m.screenId);
            S && (S.token = m.loungeToken, --W)
        }
        pK(this, !W);
        W && m_(this.G, "Missed " + W + " lounge tokens.")
    };
    g.H.nxs = function(K) {
        m_(this.G, "Requesting lounge tokens failed: " + K)
    };
    g.V(bGF, g.GP);
    g.H = bGF.prototype;
    g.H.start = function() {
        var K = parseInt(g.SZ("yt-remote-fast-check-period") || "0", 10);
        (this.W = g.hi() - 144E5 < K ? 0 : K) ? fb(this): (this.W = g.hi() + 3E5, g.SI("yt-remote-fast-check-period", this.W), this.i4())
    };
    g.H.isEmpty = function() {
        return g.Tb(this.j)
    };
    g.H.update = function() {
        PPH("Updating availability on schedule.");
        var K = this.G(),
            W = g.d6(this.j, function(U, h) {
                return U && !!m4(K, h)
            }, this);
        emj(this, W)
    };
    g.H.QH = function() {
        g.qE(this.N);
        this.N = NaN;
        this.X && (this.X.abort(), this.X = null);
        g.GP.prototype.QH.call(this)
    };
    g.H.i4 = function() {
        g.qE(this.N);
        this.N = NaN;
        this.X && this.X.abort();
        var K = TVN(this);
        if (d0n(K)) {
            var W = $O(this.U, "/pairing/get_screen_availability");
            this.X = this.U.sendRequest("POST", W, {
                lounge_token: g.N$(K).join(",")
            }, (0, g.wr)(this.R9e, this, K), (0, g.wr)(this.IEU, this))
        } else emj(this, {}), fb(this)
    };
    g.H.R9e = function(K, W) {
        this.X = null;
        var U = g.N$(TVN(this));
        if (g.zk(U, g.N$(K))) {
            W = W.screens || [];
            U = {};
            for (var h = W.length, m = 0; m < h; ++m) U[K[W[m].loungeToken]] = W[m].status == "online";
            emj(this, U);
            fb(this)
        } else this.dS("Changing Screen set during request."), this.i4()
    };
    g.H.IEU = function(K) {
        this.dS("Screen availability failed: " + K);
        this.X = null;
        fb(this)
    };
    g.H.dS = function(K) {
        m_("OnlineScreenService", K)
    };
    g.sJ(Mu, IB);
    g.H = Mu.prototype;
    g.H.start = function() {
        this.X.start();
        this.j.start();
        this.screens.length && (this.publish("screenChange"), this.j.isEmpty() || this.publish("onlineScreenChange"))
    };
    g.H.add = function(K, W, U) {
        this.X.add(K, W, U)
    };
    g.H.remove = function(K, W, U) {
        this.X.remove(K, W, U);
        this.j.update()
    };
    g.H.w3 = function(K, W, U, h) {
        this.X.contains(K) ? this.X.w3(K, W, U, h) : (K = "Updating name of unknown screen: " + K.name, m_(this.G, K), h(Error(K)))
    };
    g.H.Ha = function(K) {
        return K ? this.screens : g.fa(this.screens, g.yb(this.N, function(W) {
            return !this.contains(W)
        }, this))
    };
    g.H.wu = function() {
        return g.yb(this.Ha(!0), function(K) {
            return !!this.j.j[K.id]
        }, this)
    };
    g.H.Ed = function(K, W, U, h, m, S) {
        var f = this;
        this.info("getDialScreenByPairingCode " + K + " / " + W);
        var G = new IWH(this.W, K, W, U, h);
        G.subscribe("pairingComplete", function(I, d) {
            g.vZ(G);
            m(Az(f, I), d)
        });
        G.subscribe("pairingFailed", function(I) {
            g.vZ(G);
            S(I)
        });
        G.start();
        return (0, g.wr)(G.stop, G)
    };
    g.H.o3 = function(K, W, U, h) {
        g.ka($O(this.W, "/pairing/get_screen"), {
            method: "POST",
            postParams: {
                pairing_code: K
            },
            timeout: 5E3,
            onSuccess: (0, g.wr)(function(m, S) {
                m = new tz(S.screen || {});
                if (!m.name || bXZ(this, m.name)) {
                    a: {
                        S = m.name;
                        for (var f = 2, G = W(S, f); bXZ(this, G);) {
                            f++;
                            if (f > 20) break a;
                            G = W(S, f)
                        }
                        S = G
                    }
                    m.name = S
                }
                U(Az(this, m))
            }, this),
            onError: (0, g.wr)(function(m) {
                h(Error("pairing request failed: " + m.status))
            }, this),
            onTimeout: (0, g.wr)(function() {
                h(Error("pairing request timed out."))
            }, this)
        })
    };
    g.H.QH = function() {
        g.vZ(this.X);
        g.vZ(this.j);
        Mu.j7.QH.call(this)
    };
    g.H.Y5p = function() {
        o2b(this);
        this.publish("screenChange");
        this.j.update()
    };
    Mu.prototype.dispose = Mu.prototype.dispose;
    g.sJ(c0, g.GP);
    g.H = c0.prototype;
    g.H.uK = function(K) {
        this.qs() || (K && (xt(this, "" + K), this.publish("sessionFailed")), this.j = null, this.publish("sessionScreen", null))
    };
    g.H.info = function(K) {
        m_(this.hK, K)
    };
    g.H.Kb = function() {
        return null
    };
    g.H.k7 = function(K) {
        var W = this.X;
        K ? (W.displayStatus = new chrome.cast.ReceiverDisplayStatus(K, []), W.displayStatus.showStop = !0) : W.displayStatus = null;
        chrome.cast.setReceiverDisplayStatus(W, (0, g.wr)(function() {
            this.info("Updated receiver status for " + W.friendlyName + ": " + K)
        }, this), (0, g.wr)(function() {
            xt(this, "Failed to update receiver status for: " + W.friendlyName)
        }, this))
    };
    g.H.QH = function() {
        this.k7("");
        c0.j7.QH.call(this)
    };
    g.V(B9, c0);
    g.H = B9.prototype;
    g.H.mL = function(K) {
        if (this.N) {
            if (this.N == K) return;
            xt(this, "Overriding cast session with new session object");
            k7t(this);
            this.Ns = !1;
            this.jV = "unknown";
            this.N.removeUpdateListener(this.uX);
            this.N.removeMessageListener("urn:x-cast:com.google.youtube.mdx", this.DA)
        }
        this.N = K;
        this.N.addUpdateListener(this.uX);
        this.N.addMessageListener("urn:x-cast:com.google.youtube.mdx", this.DA);
        Qyf(this, "getMdxSessionStatus")
    };
    g.H.Zz = function(K) {
        this.info("launchWithParams no-op for Cast: " + g.rc(K))
    };
    g.H.stop = function() {
        this.N ? this.N.stop((0, g.wr)(function() {
            this.uK()
        }, this), (0, g.wr)(function() {
            this.uK(Error("Failed to stop receiver app."))
        }, this)) : this.uK(Error("Stopping cast device without session."))
    };
    g.H.k7 = function() {};
    g.H.QH = function() {
        this.info("disposeInternal");
        k7t(this);
        this.N && (this.N.removeUpdateListener(this.uX), this.N.removeMessageListener("urn:x-cast:com.google.youtube.mdx", this.DA));
        this.N = null;
        c0.prototype.QH.call(this)
    };
    g.H.HCx = function(K, W) {
        if (!this.qs())
            if (W)
                if (W = iA(W), g.SG(W)) switch (K = "" + W.type, W = W.data || {}, this.info("onYoutubeMessage_: " + K + " " + g.rc(W)), K) {
                    case "mdxSessionStatus":
                        t8N(this, W);
                        break;
                    case "loungeToken":
                        egH(this, W);
                        break;
                    default:
                        xt(this, "Unknown youtube message: " + K)
                } else xt(this, "Unable to parse message.");
                else xt(this, "No data in message.")
    };
    g.H.lJ = function(K, W, U, h) {
        g.qE(this.J);
        this.J = 0;
        W9h(this.W, this.X.label, K, this.X.friendlyName, (0, g.wr)(function(m) {
            m ? W(m) : h >= 0 ? (xt(this, "Screen " + K + " appears to be offline. " + h + " retries left."), this.J = g.FE((0, g.wr)(this.lJ, this, K, W, U, h - 1), 300)) : U(Error("Unable to fetch screen."))
        }, this), U)
    };
    g.H.Kb = function() {
        return this.N
    };
    g.H.Pk = function(K) {
        this.qs() || K || (xt(this, "Cast session died."), this.uK())
    };
    g.V(UO, c0);
    g.H = UO.prototype;
    g.H.mL = function(K) {
        this.N = K;
        this.N.addUpdateListener(this.eV)
    };
    g.H.Zz = function(K) {
        this.Le = K;
        this.Ms()
    };
    g.H.stop = function() {
        $0n(this);
        this.N ? this.N.stop((0, g.wr)(this.uK, this, null), (0, g.wr)(this.uK, this, "Failed to stop DIAL device.")) : this.uK()
    };
    g.H.QH = function() {
        $0n(this);
        this.N && this.N.removeUpdateListener(this.eV);
        this.N = null;
        c0.prototype.QH.call(this)
    };
    g.H.xb = function(K) {
        this.qs() || K || (xt(this, "DIAL session died."), this.U(), this.U = function() {}, this.uK())
    };
    g.V(nK, c0);
    nK.prototype.stop = function() {
        this.uK()
    };
    nK.prototype.mL = function() {};
    nK.prototype.Zz = function() {
        g.qE(this.N);
        this.N = NaN;
        var K = m4(this.W.Ha(), this.X.label);
        K ? eM(this, K) : this.uK(Error("No such screen"))
    };
    nK.prototype.QH = function() {
        g.qE(this.N);
        this.N = NaN;
        c0.prototype.QH.call(this)
    };
    g.V(bM, g.GP);
    g.H = bM.prototype;
    g.H.init = function(K, W) {
        chrome.cast.timeout.requestSession = 3E4;
        var U = new chrome.cast.SessionRequest(this.J, [chrome.cast.Capability.AUDIO_OUT]);
        g.hc("desktop_enable_cast_connect") && (U.androidReceiverCompatible = !0);
        this.jV || (U.dialRequest = new chrome.cast.DialRequest("YouTube"));
        var h = chrome.cast.AutoJoinPolicy.TAB_AND_ORIGIN_SCOPED;
        K = K || this.G ? chrome.cast.DefaultActionPolicy.CAST_THIS_TAB : chrome.cast.DefaultActionPolicy.CREATE_SESSION;
        var m = (0, g.wr)(this.k7k, this);
        U = new chrome.cast.ApiConfig(U, (0, g.wr)(this.ol,
            this), m, h, K);
        U.customDialLaunchCallback = (0, g.wr)(this.K6x, this);
        chrome.cast.initialize(U, (0, g.wr)(function() {
            this.qs() || (chrome.cast.addReceiverActionListener(this.U), VRb(), this.X.subscribe("onlineScreenChange", (0, g.wr)(this.FU, this)), this.N = D0t(this), chrome.cast.setCustomReceivers(this.N, function() {}, (0, g.wr)(function(S) {
                this.dS("Failed to set initial custom receivers: " + g.rc(S))
            }, this)), this.publish("yt-remote-cast2-availability-change", m3(this)), W(!0))
        }, this), (0, g.wr)(function(S) {
            this.dS("Failed to initialize API: " +
                g.rc(S));
            W(!1)
        }, this))
    };
    g.H.J3K = function(K, W) {
        WU("Setting connected screen ID: " + K + " -> " + W);
        if (this.j) {
            var U = this.j.j;
            if (!K || U && U.id != K) WU("Unsetting old screen status: " + this.j.X.friendlyName), iM(this, null)
        }
        if (K && W) {
            if (!this.j) {
                K = m4(this.X.Ha(), K);
                if (!K) {
                    WU("setConnectedScreenStatus: Unknown screen.");
                    return
                }
                if (K.idType == "shortLived") {
                    WU("setConnectedScreenStatus: Screen with id type to be short lived.");
                    return
                }
                U = oQ4(this, K);
                U || (WU("setConnectedScreenStatus: Connected receiver not custom..."), U = new chrome.cast.Receiver(K.uuid ?
                    K.uuid : K.id, K.name), U.receiverType = chrome.cast.ReceiverType.CUSTOM, this.N.push(U), chrome.cast.setCustomReceivers(this.N, function() {}, (0, g.wr)(function(h) {
                    this.dS("Failed to set initial custom receivers: " + g.rc(h))
                }, this)));
                WU("setConnectedScreenStatus: new active receiver: " + U.friendlyName);
                iM(this, new nK(this.X, U), !0)
            }
            this.j.k7(W)
        } else WU("setConnectedScreenStatus: no screen.")
    };
    g.H.ELx = function(K) {
        this.qs() ? this.dS("Setting connection data on disposed cast v2") : this.j ? this.j.Zz(K) : this.dS("Setting connection data without a session")
    };
    g.H.Ci = function() {
        this.qs() ? this.dS("Stopping session on disposed cast v2") : this.j ? (this.j.stop(), iM(this, null)) : WU("Stopping non-existing session")
    };
    g.H.requestSession = function() {
        chrome.cast.requestSession((0, g.wr)(this.ol, this), (0, g.wr)(this.PBr, this))
    };
    g.H.QH = function() {
        this.X.unsubscribe("onlineScreenChange", (0, g.wr)(this.FU, this));
        window.chrome && chrome.cast && chrome.cast.removeReceiverActionListener(this.U);
        var K = SKF,
            W = g.vB("yt.mdx.remote.debug.handlers_");
        g.sS(W || [], K);
        g.vZ(this.j);
        g.GP.prototype.QH.call(this)
    };
    g.H.dS = function(K) {
        m_("Controller", K)
    };
    g.H.fD = function(K, W) {
        this.j == K && (W || iM(this, null), this.publish("yt-remote-cast2-session-change", W))
    };
    g.H.LGA = function(K, W) {
        if (!this.qs())
            if (K) switch (K.friendlyName = chrome.cast.unescape(K.friendlyName), WU("onReceiverAction_ " + K.label + " / " + K.friendlyName + "-- " + W), W) {
                case chrome.cast.ReceiverAction.CAST:
                    if (this.j)
                        if (this.j.X.label != K.label) WU("onReceiverAction_: Stopping active receiver: " + this.j.X.friendlyName), this.j.stop();
                        else {
                            WU("onReceiverAction_: Casting to active receiver.");
                            this.j.j && this.publish("yt-remote-cast2-session-change", this.j.j);
                            break
                        }
                    switch (K.receiverType) {
                        case chrome.cast.ReceiverType.CUSTOM:
                            iM(this,
                                new nK(this.X, K));
                            break;
                        case chrome.cast.ReceiverType.DIAL:
                            iM(this, new UO(this.X, K, this.W, this.config_));
                            break;
                        case chrome.cast.ReceiverType.CAST:
                            iM(this, new B9(this.X, K, this.config_));
                            break;
                        default:
                            this.dS("Unknown receiver type: " + K.receiverType)
                    }
                    break;
                case chrome.cast.ReceiverAction.STOP:
                    this.j && this.j.X.label == K.label ? this.j.stop() : this.dS("Stopping receiver w/o session: " + K.friendlyName)
            } else this.dS("onReceiverAction_ called without receiver.")
    };
    g.H.K6x = function(K) {
        if (this.qs()) return Promise.reject(Error("disposed"));
        var W = K.receiver;
        W.receiverType != chrome.cast.ReceiverType.DIAL && (this.dS("Not DIAL receiver: " + W.friendlyName), W.receiverType = chrome.cast.ReceiverType.DIAL);
        var U = this.j ? this.j.X : null;
        if (!U || U.label != W.label) return this.dS("Receiving DIAL launch request for non-clicked DIAL receiver: " + W.friendlyName), Promise.reject(Error("illegal DIAL launch"));
        if (U && U.label == W.label && U.receiverType != chrome.cast.ReceiverType.DIAL) {
            if (this.j.j) return WU("Reselecting dial screen."),
                this.publish("yt-remote-cast2-session-change", this.j.j), Promise.resolve(new chrome.cast.DialLaunchResponse(!1));
            this.dS('Changing CAST intent from "' + U.receiverType + '" to "dial" for ' + W.friendlyName);
            iM(this, new UO(this.X, W, this.W, this.config_))
        }
        W = this.j;
        W.J = K;
        W.J.appState == chrome.cast.DialAppState.RUNNING ? (K = W.J.extraData || {}, U = K.screenId || null, s_(W) && K.loungeToken ? K.loungeTokenRefreshIntervalMs ? K = qIW(W, {
            name: W.X.friendlyName,
            screenId: K.screenId,
            loungeToken: K.loungeToken,
            dialId: W.J.receiver.label,
            screenIdType: "shortLived"
        }, K.loungeTokenRefreshIntervalMs) : (g.aH(Error("No loungeTokenRefreshIntervalMs presents in additionalData: " + JSON.stringify(K) + ".")), K = XYN(W, U)) : K = XYN(W, U)) : K = VSN(W);
        return K
    };
    g.H.ol = function(K) {
        var W = this;
        if (!this.qs() && !this.G) {
            WU("New cast session ID: " + K.sessionId);
            var U = K.receiver;
            if (U.receiverType != chrome.cast.ReceiverType.CUSTOM) {
                if (!this.j)
                    if (U.receiverType == chrome.cast.ReceiverType.CAST) WU("Got resumed cast session before resumed mdx connection."), U.friendlyName = chrome.cast.unescape(U.friendlyName), iM(this, new B9(this.X, U, this.config_), !0);
                    else {
                        this.dS("Got non-cast session without previous mdx receiver event, or mdx resume.");
                        return
                    }
                var h = this.j.X,
                    m = m4(this.X.Ha(),
                        h.label);
                m && j4(m, U.label) && h.receiverType != chrome.cast.ReceiverType.CAST && U.receiverType == chrome.cast.ReceiverType.CAST && (WU("onSessionEstablished_: manual to cast session change " + U.friendlyName), g.vZ(this.j), this.j = new B9(this.X, U, this.config_), this.j.subscribe("sessionScreen", (0, g.wr)(this.fD, this, this.j)), this.j.subscribe("sessionFailed", function() {
                    return qjN(W, W.j)
                }), this.j.Zz(null));
                this.j.mL(K)
            }
        }
    };
    g.H.lD = function() {
        return this.j ? this.j.Kb() : null
    };
    g.H.PBr = function(K) {
        this.qs() || (this.dS("Failed to estabilish a session: " + g.rc(K)), K.code != chrome.cast.ErrorCode.CANCEL && iM(this, null), this.publish("yt-remote-cast2-session-failed"))
    };
    g.H.k7k = function(K) {
        WU("Receiver availability updated: " + K);
        if (!this.qs()) {
            var W = m3(this);
            this.Y = K == chrome.cast.ReceiverAvailability.AVAILABLE;
            m3(this) != W && this.publish("yt-remote-cast2-availability-change", m3(this))
        }
    };
    g.H.FU = function() {
        this.qs() || (this.N = D0t(this), WU("Updating custom receivers: " + g.rc(this.N)), chrome.cast.setCustomReceivers(this.N, function() {}, (0, g.wr)(function() {
            this.dS("Failed to set custom receivers.")
        }, this)), this.publish("yt-remote-cast2-availability-change", m3(this)))
    };
    bM.prototype.setLaunchParams = bM.prototype.ELx;
    bM.prototype.setConnectedScreenStatus = bM.prototype.J3K;
    bM.prototype.stopSession = bM.prototype.Ci;
    bM.prototype.getCastSession = bM.prototype.lD;
    bM.prototype.requestSession = bM.prototype.requestSession;
    bM.prototype.init = bM.prototype.init;
    bM.prototype.dispose = bM.prototype.dispose;
    var Uxb = g.Le(["https://www.gstatic.com/cv/js/sender/v1/cast_sender.js"]),
        iGb = [],
        U0h = g.qi(Uxb);
    g.H = Ee.prototype;
    g.H.reset = function(K) {
        this.listId = "";
        this.index = -1;
        this.videoId = "";
        n2W(this);
        this.volume = -1;
        this.muted = !1;
        K && (this.index = K.index, this.listId = K.listId, this.videoId = K.videoId, this.playerState = K.playerState, this.volume = K.volume, this.muted = K.muted, this.audioTrackId = K.audioTrackId, this.trackData = K.trackData, this.cM = K.hasPrevious, this.zP = K.hasNext, this.G = K.playerTime, this.U = K.playerTimeAt, this.X = K.seekableStart, this.Y = K.seekableEnd, this.N = K.duration, this.J = K.loadedTime, this.j = K.liveIngestionTime, this.W = !isNaN(this.j))
    };
    g.H.isPlaying = function() {
        return this.playerState == 1
    };
    g.H.isBuffering = function() {
        return this.playerState == 3
    };
    g.H.BY = function(K) {
        this.N = isNaN(K) ? 0 : K
    };
    g.H.getDuration = function() {
        return this.W ? this.N + kt(this) : this.N
    };
    g.H.clone = function() {
        return new Ee(yCN(this))
    };
    g.V(es, g.GP);
    g.H = es.prototype;
    g.H.getState = function() {
        return this.N
    };
    g.H.JV = function() {
        return this.W.getReconnectTimeout()
    };
    g.H.fZ = function() {
        this.W.reconnect()
    };
    g.H.play = function() {
        js(this) ? (this.j ? this.j.play(null, g.Ac, D_(this, "play")) : BU(this, "play"), CVh(this, 1, HU(h$(this))), this.publish("remotePlayerChange")) : aB(this, this.play)
    };
    g.H.pause = function() {
        js(this) ? (this.j ? this.j.pause(null, g.Ac, D_(this, "pause")) : BU(this, "pause"), CVh(this, 2, HU(h$(this))), this.publish("remotePlayerChange")) : aB(this, this.pause)
    };
    g.H.seekTo = function(K) {
        if (js(this)) {
            if (this.j) {
                var W = h$(this),
                    U = new chrome.cast.media.SeekRequest;
                U.currentTime = K;
                W.isPlaying() || W.isBuffering() ? U.resumeState = chrome.cast.media.ResumeState.PLAYBACK_START : U.resumeState = chrome.cast.media.ResumeState.PLAYBACK_PAUSE;
                this.j.seek(U, g.Ac, D_(this, "seekTo", {
                    newTime: K
                }))
            } else BU(this, "seekTo", {
                newTime: K
            });
            CVh(this, 3, K);
            this.publish("remotePlayerChange")
        } else aB(this, g.jt(this.seekTo, K))
    };
    g.H.stop = function() {
        if (js(this)) {
            this.j ? this.j.stop(null, g.Ac, D_(this, "stopVideo")) : BU(this, "stopVideo");
            var K = h$(this);
            K.index = -1;
            K.videoId = "";
            n2W(K);
            zu(this, K);
            this.publish("remotePlayerChange")
        } else aB(this, this.stop)
    };
    g.H.setVolume = function(K, W) {
        if (js(this)) {
            var U = h$(this);
            if (this.X) {
                if (U.volume != K) {
                    var h = Math.round(K) / 100;
                    this.X.setReceiverVolumeLevel(h, (0, g.wr)(function() {
                        Nu("set receiver volume: " + h)
                    }, this), (0, g.wr)(function() {
                        this.dS("failed to set receiver volume.")
                    }, this))
                }
                U.muted != W && this.X.setReceiverMuted(W, (0, g.wr)(function() {
                    Nu("set receiver muted: " + W)
                }, this), (0, g.wr)(function() {
                    this.dS("failed to set receiver muted.")
                }, this))
            } else {
                var m = {
                    volume: K,
                    muted: W
                };
                U.volume != -1 && (m.delta = K - U.volume);
                BU(this, "setVolume", m)
            }
            U.muted = W;
            U.volume = K;
            zu(this, U)
        } else aB(this, g.jt(this.setVolume, K, W))
    };
    g.H.Im = function(K, W) {
        if (js(this)) {
            var U = h$(this);
            K = {
                videoId: K
            };
            W && (U.trackData = {
                trackName: W.name,
                languageCode: W.languageCode,
                sourceLanguageCode: W.translationLanguage ? W.translationLanguage.languageCode : "",
                languageName: W.languageName,
                kind: W.kind
            }, K.style = g.rc(W.style), g.Zc(K, U.trackData));
            BU(this, "setSubtitlesTrack", K);
            zu(this, U)
        } else aB(this, g.jt(this.Im, K, W))
    };
    g.H.setAudioTrack = function(K, W) {
        js(this) ? (W = W.getLanguageInfo().getId(), BU(this, "setAudioTrack", {
            videoId: K,
            audioTrackId: W
        }), K = h$(this), K.audioTrackId = W, zu(this, K)) : aB(this, g.jt(this.setAudioTrack, K, W))
    };
    g.H.playVideo = function(K, W, U, h, m, S, f) {
        h = h === void 0 ? null : h;
        m = m === void 0 ? null : m;
        S = S === void 0 ? null : S;
        f = f === void 0 ? null : f;
        var G = h$(this),
            I = {
                videoId: K
            };
        U !== void 0 && (I.currentIndex = U);
        c9(G, K, U || 0);
        W !== void 0 && (F6(G, W), I.currentTime = W);
        h && (I.listId = h);
        m && (I.playerParams = m);
        S && (I.clickTrackingParams = S);
        f && (I.locationInfo = g.rc(f));
        BU(this, "setPlaylist", I);
        h || zu(this, G)
    };
    g.H.Lq = function(K, W) {
        if (js(this)) {
            if (K && W) {
                var U = h$(this);
                c9(U, K, W);
                zu(this, U)
            }
            BU(this, "previous")
        } else aB(this, g.jt(this.Lq, K, W))
    };
    g.H.nextVideo = function(K, W) {
        if (js(this)) {
            if (K && W) {
                var U = h$(this);
                c9(U, K, W);
                zu(this, U)
            }
            BU(this, "next")
        } else aB(this, g.jt(this.nextVideo, K, W))
    };
    g.H.Er = function() {
        if (js(this)) {
            BU(this, "clearPlaylist");
            var K = h$(this);
            K.reset();
            zu(this, K);
            this.publish("remotePlayerChange")
        } else aB(this, this.Er)
    };
    g.H.CL = function() {
        js(this) ? BU(this, "dismissAutoplay") : aB(this, this.CL)
    };
    g.H.dispose = function() {
        if (this.N != 3) {
            var K = this.N;
            this.N = 3;
            this.publish("proxyStateChange", K, this.N)
        }
        g.GP.prototype.dispose.call(this)
    };
    g.H.QH = function() {
        aWt(this);
        this.W = null;
        this.U.clear();
        hn(this, null);
        g.GP.prototype.QH.call(this)
    };
    g.H.GQ = function(K) {
        if ((K != this.N || K == 2) && this.N != 3 && K != 0) {
            var W = this.N;
            this.N = K;
            this.publish("proxyStateChange", W, K);
            if (K == 1)
                for (; !this.U.isEmpty();) W = K = this.U, W.j.length === 0 && (W.j = W.X, W.j.reverse(), W.X = []), K.j.pop().apply(this);
            else K == 3 && this.dispose()
        }
    };
    g.H.DbH = function(K, W) {
        this.publish(K, W)
    };
    g.H.Zrr = function(K) {
        if (!K) this.Tr(null), hn(this, null);
        else if (this.X.receiver.volume) {
            K = this.X.receiver.volume;
            var W = h$(this),
                U = Math.round(100 * K.level || 0);
            if (W.volume != U || W.muted != K.muted) Nu("Cast volume update: " + K.level + (K.muted ? " muted" : "")), W.volume = U, W.muted = !!K.muted, zu(this, W)
        }
    };
    g.H.Tr = function(K) {
        Nu("Cast media: " + !!K);
        this.j && this.j.removeUpdateListener(this.J);
        if (this.j = K) this.j.addUpdateListener(this.J), LFv(this), this.publish("remotePlayerChange")
    };
    g.H.GKe = function(K) {
        K ? (LFv(this), this.publish("remotePlayerChange")) : this.Tr(null)
    };
    g.H.Qs = function() {
        BU(this, "sendDebugCommand", {
            debugCommand: "stats4nerds "
        })
    };
    g.H.vmK = function() {
        var K = GE4();
        K && hn(this, K)
    };
    g.H.dS = function(K) {
        m_("CP", K)
    };
    g.V(oB, g.GP);
    g.H = oB.prototype;
    g.H.connect = function(K, W) {
        if (W) {
            var U = W.listId,
                h = W.videoId,
                m = W.videoIds,
                S = W.playerParams,
                f = W.clickTrackingParams,
                G = W.index,
                I = {
                    videoId: h
                },
                d = W.currentTime,
                J = W.locationInfo;
            W = W.loopMode;
            d !== void 0 && (I.currentTime = d <= 5 ? 0 : d);
            S && (I.playerParams = S);
            J && (I.locationInfo = J);
            f && (I.clickTrackingParams = f);
            U && (I.listId = U);
            m && m.length > 0 && (I.videoIds = m.join(","));
            G !== void 0 && (I.currentIndex = G);
            this.eV && (I.loopMode = W || "LOOP_MODE_OFF");
            U && (this.j.listId = U);
            this.j.videoId = h;
            this.j.index = G || 0;
            this.j.state = 3;
            F6(this.j,
                d);
            this.U = "UNSUPPORTED";
            U = this.eV ? "setInitialState" : "setPlaylist";
            v0("Connecting with " + U + " and params: " + g.rc(I));
            this.X.connect({
                method: U,
                params: g.rc(I)
            }, K, HSF())
        } else v0("Connecting without params"), this.X.connect({}, K, HSF());
        PpH(this)
    };
    g.H.mq = function(K) {
        this.X.mq(K)
    };
    g.H.dispose = function() {
        this.qs() || (g.Vk("yt.mdx.remote.remoteClient_", null), this.publish("beforeDispose"), e4(this, 3));
        g.GP.prototype.dispose.call(this)
    };
    g.H.QH = function() {
        DqF(this);
        Otv(this);
        HX4(this);
        g.qE(this.J);
        this.J = NaN;
        g.qE(this.jV);
        this.jV = NaN;
        this.W = null;
        g.d9(this.Ms);
        this.Ms.length = 0;
        this.X.dispose();
        g.GP.prototype.QH.call(this);
        this.U = this.Y = this.N = this.j = this.X = null
    };
    g.H.l8 = function(K) {
        if (!this.N || this.N.length === 0) return !1;
        for (var W = g.z(this.N), U = W.next(); !U.done; U = W.next())
            if (!U.value.capabilities.has(K)) return !1;
        return !0
    };
    g.H.ies = function() {
        var K = 3;
        this.qs() || (K = 0, isNaN(this.I2()) ? this.X.Kj() && isNaN(this.G) && (K = 1) : K = 2);
        return K
    };
    g.H.z3 = function(K) {
        v0("Disconnecting with " + K);
        g.Vk("yt.mdx.remote.remoteClient_", null);
        DqF(this);
        this.publish("beforeDisconnect", K);
        K == 1 && Fv();
        this.X.disconnect(K);
        this.dispose()
    };
    g.H.PG = function() {
        var K = this.j;
        this.W && (K = this.j.clone(), c9(K, this.W, K.index));
        return yCN(K)
    };
    g.H.IwX = function(K) {
        var W = this,
            U = new Ee(K);
        U.videoId && U.videoId != this.j.videoId && (this.W = U.videoId, g.qE(this.J), this.J = g.FE(function() {
            if (W.W) {
                var m = W.W;
                W.W = null;
                W.j.videoId != m && E_(W, "getNowPlaying")
            }
        }, 5E3));
        var h = [];
        this.j.listId == U.listId && this.j.videoId == U.videoId && this.j.index == U.index || h.push("remoteQueueChange");
        this.j.playerState == U.playerState && this.j.volume == U.volume && this.j.muted == U.muted && HU(this.j) == HU(U) && g.rc(this.j.trackData) == g.rc(U.trackData) || h.push("remotePlayerChange");
        this.j.reset(K);
        g.tD(h, function(m) {
            this.publish(m)
        }, this)
    };
    g.H.IV = function() {
        var K = this.X.getDeviceId(),
            W = g.dG(this.N, function(U) {
                return U.type == "REMOTE_CONTROL" && U.id != K
            });
        return W ? W.id : ""
    };
    g.H.I2 = function() {
        return this.X.JV()
    };
    g.H.Z9 = function() {
        return this.U || "UNSUPPORTED"
    };
    g.H.Ye = function() {
        return this.Y || ""
    };
    g.H.gb = function() {
        !isNaN(this.I2()) && this.X.fZ()
    };
    g.H.vLr = function(K, W) {
        E_(this, K, W);
        hNZ(this)
    };
    g.H.Rm = function() {
        var K = g.LY("SAPISID", "") || g.LY("__Secure-1PAPISID") || "",
            W = g.LY("__Secure-3PAPISID", "") || "";
        if (!K && !W) return "";
        K = g.o0(g.Zv(K), 2);
        W = g.o0(g.Zv(W), 2);
        return g.o0(g.Zv("," + K + "," + W), 2)
    };
    oB.prototype.subscribe = oB.prototype.subscribe;
    oB.prototype.unsubscribeByKey = oB.prototype.M2;
    oB.prototype.getProxyState = oB.prototype.ies;
    oB.prototype.disconnect = oB.prototype.z3;
    oB.prototype.getPlayerContextData = oB.prototype.PG;
    oB.prototype.setPlayerContextData = oB.prototype.IwX;
    oB.prototype.getOtherConnectedRemoteId = oB.prototype.IV;
    oB.prototype.getReconnectTimeout = oB.prototype.I2;
    oB.prototype.getAutoplayMode = oB.prototype.Z9;
    oB.prototype.getAutoplayVideoId = oB.prototype.Ye;
    oB.prototype.reconnect = oB.prototype.gb;
    oB.prototype.sendMessage = oB.prototype.vLr;
    oB.prototype.getXsrfToken = oB.prototype.Rm;
    oB.prototype.isCapabilitySupportedOnConnectedDevices = oB.prototype.l8;
    g.V(m1f, IB);
    g.H = m1f.prototype;
    g.H.Ha = function(K) {
        return this.di.$_gs(K)
    };
    g.H.contains = function(K) {
        return !!this.di.$_c(K)
    };
    g.H.get = function(K) {
        return this.di.$_g(K)
    };
    g.H.start = function() {
        this.di.$_st()
    };
    g.H.add = function(K, W, U) {
        this.di.$_a(K, W, U)
    };
    g.H.remove = function(K, W, U) {
        this.di.$_r(K, W, U)
    };
    g.H.w3 = function(K, W, U, h) {
        this.di.$_un(K, W, U, h)
    };
    g.H.QH = function() {
        for (var K = this.j.length, W = 0; W < K; ++W) this.di.$_ubk(this.j[W]);
        this.j.length = 0;
        this.di = null;
        IB.prototype.QH.call(this)
    };
    g.H.jp = function() {
        this.publish("screenChange")
    };
    g.H.qvk = function() {
        this.publish("onlineScreenChange")
    };
    Mu.prototype.$_st = Mu.prototype.start;
    Mu.prototype.$_gspc = Mu.prototype.o3;
    Mu.prototype.$_gsppc = Mu.prototype.Ed;
    Mu.prototype.$_c = Mu.prototype.contains;
    Mu.prototype.$_g = Mu.prototype.get;
    Mu.prototype.$_a = Mu.prototype.add;
    Mu.prototype.$_un = Mu.prototype.w3;
    Mu.prototype.$_r = Mu.prototype.remove;
    Mu.prototype.$_gs = Mu.prototype.Ha;
    Mu.prototype.$_gos = Mu.prototype.wu;
    Mu.prototype.$_s = Mu.prototype.subscribe;
    Mu.prototype.$_ubk = Mu.prototype.M2;
    var ps = null,
        P9 = !1,
        ZZ = null,
        Tu = null,
        jhO = null,
        IY = [];
    g.V(jyn, g.p);
    g.H = jyn.prototype;
    g.H.QH = function() {
        g.p.prototype.QH.call(this);
        this.X.stop();
        this.N.stop();
        this.J.stop();
        var K = this.fg;
        K.unsubscribe("proxyStateChange", this.Il, this);
        K.unsubscribe("remotePlayerChange", this.dw, this);
        K.unsubscribe("remoteQueueChange", this.xQ, this);
        K.unsubscribe("previousNextChange", this.w7, this);
        K.unsubscribe("nowAutoplaying", this.v6, this);
        K.unsubscribe("autoplayDismissed", this.hN, this);
        this.fg = this.j = null
    };
    g.H.w_ = function(K) {
        var W = g.Xl.apply(1, arguments);
        if (this.fg.N != 2)
            if (U_(this)) {
                if (h$(this.fg).playerState != 1081 || K !== "control_seek") switch (K) {
                    case "control_toggle_play_pause":
                        h$(this.fg).isPlaying() ? this.fg.pause() : this.fg.play();
                        break;
                    case "control_play":
                        this.fg.play();
                        break;
                    case "control_pause":
                        this.fg.pause();
                        break;
                    case "control_seek":
                        this.Y.CQ(W[0], W[1]);
                        break;
                    case "control_subtitles_set_track":
                        Z7f(this, W[0]);
                        break;
                    case "control_set_audio_track":
                        this.setAudioTrack(W[0])
                }
            } else switch (K) {
                case "control_toggle_play_pause":
                case "control_play":
                case "control_pause":
                    W =
                        this.D.getCurrentTime();
                    y0(this, W === 0 ? void 0 : W);
                    break;
                case "control_seek":
                    y0(this, W[0]);
                    break;
                case "control_subtitles_set_track":
                    Z7f(this, W[0]);
                    break;
                case "control_set_audio_track":
                    this.setAudioTrack(W[0])
            }
    };
    g.H.eAp = function(K) {
        this.J.GF(K)
    };
    g.H.fce = function(K) {
        this.w_("control_subtitles_set_track", g.Tb(K) ? null : K)
    };
    g.H.sI = function() {
        var K = this.D.getOption("captions", "track");
        g.Tb(K) || Z7f(this, K)
    };
    g.H.Ym = function(K) {
        this.j.Ym(K, this.D.getVideoData().lengthSeconds)
    };
    g.H.W1K = function() {
        g.Tb(this.W) || syt(this, this.W);
        this.U = !1
    };
    g.H.Il = function(K, W) {
        this.N.stop();
        W === 2 && this.tb()
    };
    g.H.dw = function() {
        if (U_(this)) {
            this.X.stop();
            var K = h$(this.fg);
            switch (K.playerState) {
                case 1080:
                case 1081:
                case 1084:
                case 1085:
                    this.j.n_ = 1;
                    break;
                case 1082:
                case 1083:
                    this.j.n_ = 0;
                    break;
                default:
                    this.j.n_ = -1
            }
            switch (K.playerState) {
                case 1081:
                case 1:
                    this.uY(new g.Kw(8));
                    this.qx();
                    break;
                case 1085:
                case 3:
                    this.uY(new g.Kw(9));
                    break;
                case 1083:
                case 0:
                    this.uY(new g.Kw(2));
                    this.Y.stop();
                    this.Ym(this.D.getVideoData().lengthSeconds);
                    break;
                case 1084:
                    this.uY(new g.Kw(4));
                    break;
                case 2:
                    this.uY(new g.Kw(4));
                    this.Ym(HU(K));
                    break;
                case -1:
                    this.uY(new g.Kw(64));
                    break;
                case -1E3:
                    this.uY(new g.Kw(128, {
                        errorCode: "mdx.remoteerror",
                        errorMessage: "Video n\u00e0y kh\u00f4ng kh\u1ea3 d\u1ee5ng \u0111\u1ec3 ph\u00e1t l\u1ea1i t\u1eeb xa.",
                        BE: 2
                    }))
            }
            K = h$(this.fg).trackData;
            var W = this.W;
            (K || W ? K && W && K.trackName == W.trackName && K.languageCode == W.languageCode && K.languageName == W.languageName && K.kind == W.kind : 1) || (this.W = K, syt(this, K));
            K = h$(this.fg);
            K.volume === -1 || Math.round(this.D.getVolume()) === K.volume && this.D.isMuted() === K.muted || this.jV.isActive() ||
                this.Zn()
        } else CPW(this)
    };
    g.H.w7 = function() {
        this.D.publish("mdxpreviousnextchange")
    };
    g.H.xQ = function() {
        U_(this) || CPW(this)
    };
    g.H.v6 = function(K) {
        isNaN(K) || this.D.publish("mdxnowautoplaying", K)
    };
    g.H.hN = function() {
        this.D.publish("mdxautoplaycanceled")
    };
    g.H.setAudioTrack = function(K) {
        U_(this) && this.fg.setAudioTrack(this.D.getVideoData(1).videoId, K)
    };
    g.H.seekTo = function(K, W) {
        h$(this.fg).playerState === -1 ? y0(this, K) : W && this.fg.seekTo(K)
    };
    g.H.Zn = function() {
        var K = this;
        if (U_(this)) {
            var W = h$(this.fg);
            this.events.GK(this.Ms);
            W.muted ? this.D.mute() : this.D.unMute();
            this.D.setVolume(W.volume);
            this.Ms = this.events.S(this.D, "onVolumeChange", function(U) {
                hgj(K, U)
            })
        }
    };
    g.H.qx = function() {
        this.X.stop();
        if (!this.fg.qs()) {
            var K = h$(this.fg);
            K.isPlaying() && this.uY(new g.Kw(8));
            this.Ym(HU(K));
            this.X.start()
        }
    };
    g.H.tb = function() {
        this.N.stop();
        this.X.stop();
        var K = this.fg.JV();
        this.fg.N == 2 && !isNaN(K) && this.N.start()
    };
    g.H.uY = function(K) {
        this.N.stop();
        var W = this.G;
        if (!g.GY(W, K)) {
            var U = g.C(K, 2);
            U !== g.C(this.G, 2) && this.D.Ji(U);
            this.G = K;
            rCj(this.j, W, K)
        }
    };
    g.V(vRW, g.S$);
    g.H = vRW.prototype;
    g.H.getCurrentTime = function() {
        return this.j.getCurrentTime()
    };
    g.H.getDuration = function() {
        return this.j.getDuration()
    };
    g.H.hv = function() {
        return this.j.hv()
    };
    g.H.V1 = function() {
        return this.j.V1()
    };
    g.H.Id = function() {
        return this.j.Id()
    };
    g.H.Ln = function() {
        return this.j.Ln()
    };
    g.H.getPlayerState = function() {
        return this.j.RR
    };
    g.H.isAtLiveHead = function() {
        return this.j.isAtLiveHead()
    };
    g.H.pauseVideo = function() {
        this.j.SJ("control_pause")
    };
    g.H.playVideo = function() {
        var K = this;
        return g.r(function(W) {
            K.j.SJ("control_play");
            return W.return()
        })
    };
    g.H.seekTo = function(K, W) {
        this.j.SJ("control_seek", K, !(W == null ? 0 : W.QG))
    };
    g.H.La = function(K) {
        this.j.SJ("control_set_audio_track", K);
        return !0
    };
    g.V(H0, g.y);
    H0.prototype.Kr = function() {
        this.fade.show()
    };
    H0.prototype.z9 = function() {
        this.fade.hide()
    };
    H0.prototype.j = function() {
        W9("mdx-privacy-popup-cancel");
        this.z9()
    };
    H0.prototype.X = function() {
        W9("mdx-privacy-popup-confirm");
        this.z9()
    };
    g.V(Dw, g.y);
    Dw.prototype.onStateChange = function(K) {
        this.Bl(K.state)
    };
    Dw.prototype.Bl = function(K) {
        if (this.api.getPresentingPlayerType() === 3) {
            var W = {
                RECEIVER_NAME: this.api.getOption("remote", "currentReceiver").name
            };
            K = g.C(K, 128) ? g.BB("L\u1ed7i tr\u00ean $RECEIVER_NAME", W) : K.isPlaying() || K.isPaused() ? g.BB("\u0110ang ph\u00e1t tr\u00ean $RECEIVER_NAME", W) : g.BB("\u0110\u00e3 k\u1ebft n\u1ed1i v\u1edbi $RECEIVER_NAME", W);
            this.updateValue("statustext", K);
            this.fade.show()
        } else this.fade.hide()
    };
    g.V(B0, g.It);
    B0.prototype.X = function() {
        var K = this.D.getOption("remote", "receivers");
        K && K.length > 1 && !this.D.getOption("remote", "quickCast") ? (this.sS = g.GG(K, this.j, this), this.Wa(g.CB(K, this.j)), K = this.D.getOption("remote", "currentReceiver"), K = this.j(K), this.options[K] && this.b$(K), this.enable(!0)) : this.enable(!1)
    };
    B0.prototype.j = function(K) {
        return K.key
    };
    B0.prototype.mZ = function(K) {
        return K === "cast-selector-receiver" ? "Truy\u1ec1n..." : this.sS[K].name
    };
    B0.prototype.yv = function(K) {
        g.It.prototype.yv.call(this, K);
        this.D.setOption("remote", "currentReceiver", this.sS[K]);
        this.pg.z9()
    };
    g.V(abj, g.wP);
    g.H = abj.prototype;
    g.H.create = function() {
        var K = this.player.V(),
            W = g.EZ(K);
        K = {
            device: "Desktop",
            app: "youtube-desktop",
            loadCastApiSetupScript: K.L("mdx_load_cast_api_bootstrap_script"),
            enableDialLoungeToken: K.L("enable_dial_short_lived_lounge_token"),
            enableCastLoungeToken: K.L("enable_cast_short_lived_lounge_token")
        };
        xtO(W, K);
        this.subscriptions.push(g.BV("yt-remote-before-disconnect", this.kKX, this));
        this.subscriptions.push(g.BV("yt-remote-connection-change", this.q_x, this));
        this.subscriptions.push(g.BV("yt-remote-receiver-availability-change", this.F9,
            this));
        this.subscriptions.push(g.BV("yt-remote-auto-connect", this.z9x, this));
        this.subscriptions.push(g.BV("yt-remote-receiver-resumed", this.mbU, this));
        this.subscriptions.push(g.BV("mdx-privacy-popup-confirm", this.cO5, this));
        this.subscriptions.push(g.BV("mdx-privacy-popup-cancel", this.fpK, this));
        this.F9()
    };
    g.H.load = function() {
        this.player.cancelPlayback();
        g.wP.prototype.load.call(this);
        this.zz = new vRW(this.player.V(), this);
        this.player.vJ(this.zz);
        this.gX = new jyn(this, this.player, this.fg);
        var K = (K = fWO()) ? K.currentTime : 0;
        var W = fgh() ? new es(S4(), void 0) : null;
        K == 0 && W && (K = HU(h$(W)));
        K !== 0 && this.Ym(K);
        rCj(this, this.RR, this.RR);
        this.player.ZC(6)
    };
    g.H.unload = function() {
        this.player.publish("mdxautoplaycanceled");
        this.player.Xb();
        this.UO = this.bA;
        g.Pz(this.gX, this.fg);
        this.fg = this.zz = this.gX = null;
        g.wP.prototype.unload.call(this);
        this.player.ZC(5);
        Cs(this)
    };
    g.H.QH = function() {
        g.Df(this.subscriptions);
        g.wP.prototype.QH.call(this)
    };
    g.H.SJ = function(K) {
        var W = g.Xl.apply(1, arguments);
        this.loaded && this.gX.w_.apply(this.gX, [K].concat(g.z4(W)))
    };
    g.H.getAdState = function() {
        return this.n_
    };
    g.H.cM = function() {
        return this.fg ? h$(this.fg).cM : !1
    };
    g.H.zP = function() {
        return this.fg ? h$(this.fg).zP : !1
    };
    g.H.Ym = function(K, W) {
        this.Wc = K || 0;
        this.player.publish("progresssync", K, W);
        this.player.Ov("onVideoProgress", K || 0)
    };
    g.H.getCurrentTime = function() {
        return this.Wc
    };
    g.H.getDuration = function() {
        return h$(this.fg).getDuration() || 0
    };
    g.H.hv = function() {
        var K = h$(this.fg);
        return K.W ? K.j + kt(K) : K.j
    };
    g.H.V1 = function() {
        return h$(this.fg).J
    };
    g.H.Id = function() {
        return Rmb(h$(this.fg))
    };
    g.H.Ln = function() {
        var K = h$(this.fg);
        return K.X > 0 ? K.X + kt(K) : K.X
    };
    g.H.getProgressState = function() {
        var K = h$(this.fg),
            W = this.player.getVideoData();
        return {
            airingStart: 0,
            airingEnd: 0,
            allowSeeking: K.playerState != 1081 && this.player.gS(),
            clipEnd: W.clipEnd,
            clipStart: W.clipStart,
            current: this.getCurrentTime(),
            displayedStart: -1,
            duration: this.getDuration(),
            ingestionTime: this.hv(),
            isAtLiveHead: this.isAtLiveHead(),
            loaded: this.V1(),
            seekableEnd: this.Id(),
            seekableStart: this.Ln(),
            offset: 0,
            viewerLivestreamJoinMediaTime: 0
        }
    };
    g.H.isAtLiveHead = function() {
        return Rmb(h$(this.fg)) - this.getCurrentTime() <= 1
    };
    g.H.nextVideo = function() {
        this.fg && this.fg.nextVideo()
    };
    g.H.Lq = function() {
        this.fg && this.fg.Lq()
    };
    g.H.kKX = function(K) {
        K === 1 && (this.GW = this.fg ? h$(this.fg) : null)
    };
    g.H.q_x = function() {
        var K = fgh() ? new es(S4(), void 0) : null;
        if (K) {
            var W = this.UO;
            this.loaded && this.unload();
            this.fg = K;
            this.GW = null;
            W.key !== this.bA.key && (this.UO = W, this.load())
        } else g.vZ(this.fg), this.fg = null, this.loaded && (this.unload(), (K = this.GW) && K.videoId === this.player.getVideoData().videoId && this.player.cueVideoById(K.videoId, HU(K)));
        this.player.publish("videodatachange", "newdata", this.player.getVideoData(), 3)
    };
    g.H.F9 = function() {
        var K = [this.bA],
            W = K.concat,
            U = Tnv();
        LK() && g.SZ("yt-remote-cast-available") && U.push({
            key: "cast-selector-receiver",
            name: "Cast..."
        });
        this.sS = W.call(K, U);
        K = u33() || this.bA;
        Ss(this, K);
        this.player.Ov("onMdxReceiversChange")
    };
    g.H.z9x = function() {
        var K = u33();
        Ss(this, K)
    };
    g.H.mbU = function() {
        this.UO = u33()
    };
    g.H.cO5 = function() {
        this.Kd = !0;
        Cs(this);
        P9 = !1;
        ps && jM(ps, 1);
        ps = null
    };
    g.H.fpK = function() {
        this.Kd = !1;
        Cs(this);
        Ss(this, this.bA);
        this.UO = this.bA;
        P9 = !1;
        ps = null;
        this.player.playVideo()
    };
    g.H.yA = function(K, W) {
        switch (K) {
            case "casting":
                return this.loaded;
            case "receivers":
                return this.sS;
            case "currentReceiver":
                return W && (W.key === "cast-selector-receiver" ? PyF() : Ss(this, W)), this.loaded ? this.UO : this.bA;
            case "quickCast":
                return this.sS.length === 2 && this.sS[1].key === "cast-selector-receiver" ? (W && PyF(), !0) : !1
        }
    };
    g.H.Qs = function() {
        this.fg.Qs()
    };
    g.H.tZ = function() {
        return !1
    };
    g.H.getOptions = function() {
        return ["casting", "receivers", "currentReceiver", "quickCast"]
    };
    g.H.isLoggedIn = function() {
        var K, W;
        return ((K = g.TA("PLAYER_CONFIG")) == null ? void 0 : (W = K.args) == null ? void 0 : W.authuser) !== void 0 ? !0 : !(!g.TA("SESSION_INDEX") && !g.TA("LOGGED_IN"))
    };
    g.Q5("remote", abj);
})(_yt_player);