(function(g) {
    var window = this;
    'use strict';
    var UA = function(K) {
            var W = K.V();
            g.y.call(this, {
                T: "a",
                Hp: ["ytp-watermark", "yt-uix-sessionlink"],
                B: {
                    target: W.jV,
                    href: "{{url}}",
                    "aria-label": g.BB("Xem tr\u00ean $WEBSITE", {
                        WEBSITE: g.$b(W)
                    }),
                    "data-sessionlink": "feature=player-watermark"
                },
                bX: "{{logoSvg}}"
            });
            this.api = K;
            this.j = null;
            this.X = !1;
            this.state = K.getPlayerStateObject();
            this.S(K, "videodatachange", this.onVideoDataChange);
            this.S(K, "presentingplayerstatechange", this.onStateChange);
            this.S(K, "appresize", this.IW);
            this.onVideoDataChange();
            this.Bl(this.state);
            this.IW(K.xx().getPlayerSize())
        },
        hU = function(K) {
            g.To.call(this, K);
            var W = this;
            this.j = null;
            var U = K.V(),
                h = {
                    target: U.jV
                },
                m = ["ytp-small-redirect"];
            if (U.N) m.push("no-link");
            else {
                var S = g.pw(U);
                h.href = S;
                h["aria-label"] = "Truy c\u1eadp v\u00e0o YouTube \u0111\u1ec3 t\u00ecm ki\u1ebfm nhi\u1ec1u video h\u01a1n"
            }
            var f = new g.y({
                T: "a",
                Hp: m,
                B: h,
                K: [{
                    T: "svg",
                    B: {
                        fill: "#fff",
                        height: "100%",
                        viewBox: "0 0 24 24",
                        width: "100%"
                    },
                    K: [{
                        T: "path",
                        B: {
                            d: "M0 0h24v24H0V0z",
                            fill: "none"
                        }
                    }, {
                        T: "path",
                        B: {
                            d: "M21.58 7.19c-.23-.86-.91-1.54-1.77-1.77C18.25 5 12 5 12 5s-6.25 0-7.81.42c-.86.23-1.54.91-1.77 1.77C2 8.75 2 12 2 12s0 3.25.42 4.81c.23.86.91 1.54 1.77 1.77C5.75 19 12 19 12 19s6.25 0 7.81-.42c.86-.23 1.54-.91 1.77-1.77C22 15.25 22 12 22 12s0-3.25-.42-4.81zM10 15V9l5.2 3-5.2 3z"
                        }
                    }]
                }]
            });
            f.U5(this.element);
            K.createClientVe(f.element, this, 178053);
            this.S(f.element, "click", function(G) {
                zR4(W, G, f.element)
            });
            g.k(this, f);
            U.N || U.disableOrganicUi || (this.j = new NrN(K), this.j.U5(this.element), g.k(this, this.j));
            this.S(K, "videodatachange", function() {
                W.show()
            });
            this.resize(this.api.xx().getPlayerSize())
        },
        jX = function(K) {
            g.y.call(this, {
                T: "div",
                Hp: ["ytp-player-content", "ytp-iv-player-content"],
                K: [{
                    T: "div",
                    Z: "ytp-countdown-timer",
                    K: [{
                        T: "svg",
                        B: {
                            height: "100%",
                            version: "1.1",
                            viewBox: "0 0 72 72",
                            width: "100%"
                        },
                        K: [{
                            T: "circle",
                            Z: "ytp-svg-countdown-timer-ring",
                            B: {
                                cx: "-36",
                                cy: "36",
                                "fill-opacity": "0",
                                r: "33.5",
                                stroke: "#FFFFFF",
                                "stroke-dasharray": "211",
                                "stroke-dashoffset": "-211",
                                "stroke-width": "4",
                                transform: "rotate(-90)"
                            }
                        }, {
                            T: "circle",
                            Z: "ytp-svg-countdown-timer-background",
                            B: {
                                cx: "-36",
                                cy: "36",
                                "fill-opacity": "0",
                                r: "33.5",
                                stroke: "#FFFFFF",
                                "stroke-opacity": "0.3",
                                "stroke-width": "4",
                                transform: "rotate(-90)"
                            }
                        }]
                    }, {
                        T: "span",
                        Z: "ytp-countdown-timer-time",
                        bX: "{{duration}}"
                    }]
                }]
            });
            this.api = K;
            this.G = this.yH("ytp-svg-countdown-timer-ring");
            this.j = null;
            this.W = this.N = 0;
            this.X = !1;
            this.U = 0;
            this.api.createClientVe(this.element, this, 159628)
        },
        yy3 = function(K) {
            g.y.call(this, {
                T: "div",
                Z: "ytp-muted-autoplay-overlay",
                K: [{
                    T: "div",
                    Z: "ytp-muted-autoplay-bottom-buttons",
                    K: [{
                        T: "button",
                        Hp: ["ytp-muted-autoplay-equalizer", "ytp-button"],
                        B: {
                            "aria-label": "Ch\u1ec9 b\u00e1o cho bi\u1ebft video \u0111ang ph\u00e1t \u1edf ch\u1ebf \u0111\u1ed9 t\u1eaft ti\u1ebfng"
                        },
                        K: [{
                            T: "div",
                            Hp: ["ytp-muted-autoplay-equalizer-icon"],
                            K: [{
                                T: "svg",
                                B: {
                                    height: "100%",
                                    version: "1.1",
                                    viewBox: "-4 -4 24 24",
                                    width: "100%"
                                },
                                K: [{
                                    T: "g",
                                    B: {
                                        fill: "#fff"
                                    },
                                    K: [{
                                            T: "rect",
                                            Z: "ytp-equalizer-bar-left",
                                            B: {
                                                height: "9",
                                                width: "4",
                                                x: "1",
                                                y: "7"
                                            }
                                        },
                                        {
                                            T: "rect",
                                            Z: "ytp-equalizer-bar-middle",
                                            B: {
                                                height: "14",
                                                width: "4",
                                                x: "6",
                                                y: "2"
                                            }
                                        }, {
                                            T: "rect",
                                            Z: "ytp-equalizer-bar-right",
                                            B: {
                                                height: "12",
                                                width: "4",
                                                x: "11",
                                                y: "4"
                                            }
                                        }
                                    ]
                                }]
                            }]
                        }]
                    }]
                }]
            });
            var W = this;
            this.api = K;
            this.bottomButtons = this.yH("ytp-muted-autoplay-bottom-buttons");
            this.N = new g.QC(this.oxx, 4E3, this);
            this.X = !1;
            K.createClientVe(this.element, this, 39306);
            this.S(K, "presentingplayerstatechange", this.a$);
            this.S(K, "onMutedAutoplayStarts", function() {
                Ayh(W);
                W.a$();
                RRt(W);
                W.X = !1
            });
            this.S(K, "onAutoplayBlocked", this.onAutoplayBlocked);
            this.listen("click", this.onClick);
            this.S(K, "onMutedAutoplayEnds", this.onMutedAutoplayEnds);
            this.hide();
            K.isMutedByEmbedsMutedAutoplay() && (Ayh(this), this.a$(), RRt(this));
            g.k(this, this.N)
        },
        MAO = function(K) {
            K.mutedAutoplay = !1;
            K.endSeconds = NaN;
            K.limitedPlaybackDurationInSeconds = NaN;
            g.NZ(K)
        },
        PeO = function(K, W) {
            g.y.call(this, {
                T: "a",
                Hp: ["ytp-impression-link"],
                B: {
                    target: "{{target}}",
                    href: "{{url}}",
                    "aria-label": "Xem tr\u00ean YouTube"
                },
                K: [{
                    T: "div",
                    Z: "ytp-impression-link-content",
                    B: {
                        "aria-hidden": "true"
                    },
                    K: [{
                        T: "div",
                        Z: "ytp-impression-link-text",
                        bX: "Xem tr\u00ean"
                    }, {
                        T: "div",
                        Z: "ytp-impression-link-logo",
                        bX: "{{logoSvg}}"
                    }]
                }]
            });
            this.api = K;
            this.j = W;
            this.updateValue("target", K.V().jV);
            this.S(K, "videodatachange", this.onVideoDataChange);
            this.S(this.api, "presentingplayerstatechange", this.dg);
            this.S(this.api, "videoplayerreset", this.bU);
            this.S(this.element,
                "click", this.onClick);
            this.onVideoDataChange();
            this.bU()
        },
        oHh = function(K) {
            for (var W = 0; W < K.suggestionData.length; W++) {
                var U = K.suggestionData[W],
                    h = K.j[W],
                    m = U.shortViewCount ? U.shortViewCount : U.author,
                    S = U.cN(),
                    f = K.api.V();
                if (g.HB(f) && !f.L("web_player_log_click_before_generating_ve_conversion_params")) {
                    var G = {};
                    g.Zm(K.api, "addEmbedsConversionTrackingParams", [G]);
                    S = g.sL(S, G)
                }
                h.element.style.display = "";
                G = h.yH("ytp-suggestion-title");
                g.lCp.test(U.title) ? G.dir = "rtl" : g.hDH.test(U.title) && (G.dir = "ltr");
                G = h.yH("ytp-suggestion-author");
                g.lCp.test(m) ? G.dir = "rtl" : g.hDH.test(m) && (G.dir = "ltr");
                h.update({
                    views_or_author: m,
                    duration: U.isLivePlayback ? "Tr\u1ef1c ti\u1ebfp" : U.lengthSeconds ? g.sp(U.lengthSeconds) : "",
                    link: S,
                    hover_title: U.title,
                    title: U.title,
                    aria_label: U.ariaLabel || null,
                    is_live: U.isLivePlayback
                });
                m = U.S7();
                h.yH("ytp-suggestion-image").style.backgroundImage = m ? "url(" + m + ")" : "";
                f.L("web_player_log_click_before_generating_ve_conversion_params") && (K.api.createServerVe(h.element, h), (U = (U = U.sessionData) && U.itct) && K.api.setTrackingParams(h.element, U))
            }
            for (; W < K.j.length; W++) K.j[W].element.style.display = "none";
            pFI(K)
        },
        Z_F = function(K) {
            var W = K.D;
            K = !!W.isEmbedsShortsMode();
            g.JM(W.getRootNode(), "ytp-shorts-mode", K);
            if (W = W.getVideoData()) W.Td = K
        },
        sZ3 = function(K) {
            K.j || (K.N = 5E3, K.W = (0, g.AI)(), K.j = new g.x3(function() {
                b_F(K)
            }, null), b_F(K))
        },
        VAj = function(K) {
            var W = {};
            g.Zm(K.api, "addEmbedsConversionTrackingParams", [W]);
            K = K.api.getVideoUrl();
            return K = g.sL(K, W)
        },
        NrN = function(K) {
            g.y.call(this, {
                T: "div",
                Z: "ytp-related-on-error-overlay"
            });
            var W = this;
            this.api = K;
            this.U = this.X = 0;
            this.W = new g.Te(this);
            this.j = [];
            this.suggestionData = [];
            this.columns = this.containerWidth = 0;
            this.title = new g.y({
                T: "h2",
                Z: "ytp-related-title",
                bX: "{{title}}"
            });
            this.previous = new g.y({
                T: "button",
                Hp: ["ytp-button", "ytp-previous"],
                B: {
                    "aria-label": "Hi\u1ec3n th\u1ecb c\u00e1c video \u0111\u1ec1 xu\u1ea5t tr\u01b0\u1edbc \u0111\u00f3"
                },
                K: [g.As()]
            });
            this.J = new g.CN(function(S) {
                W.suggestions.element.scrollLeft = -S
            });
            this.N = this.scrollPosition = 0;
            this.G = !0;
            this.next = new g.y({
                T: "button",
                Hp: ["ytp-button", "ytp-next"],
                B: {
                    "aria-label": "Hi\u1ec7n th\u00eam video \u0111\u1ec1 xu\u1ea5t"
                },
                K: [g.Wq()]
            });
            g.k(this, this.W);
            K = K.V();
            this.Y = K.W;
            g.k(this, this.title);
            this.title.U5(this.element);
            this.suggestions = new g.y({
                T: "div",
                Z: "ytp-suggestions"
            });
            g.k(this, this.suggestions);
            this.suggestions.U5(this.element);
            g.k(this, this.previous);
            this.previous.U5(this.element);
            this.previous.listen("click", this.uD, this);
            g.k(this, this.J);
            for (var U = {
                    yJ: 0
                }; U.yJ < 16; U = {
                    yJ: U.yJ
                }, U.yJ++) {
                var h = new g.y({
                    T: "a",
                    Z: "ytp-suggestion-link",
                    B: {
                        href: "{{link}}",
                        target: K.jV,
                        "aria-label": "{{aria_label}}"
                    },
                    K: [{
                        T: "div",
                        Z: "ytp-suggestion-image",
                        K: [{
                            T: "div",
                            B: {
                                "data-is-live": "{{is_live}}"
                            },
                            Z: "ytp-suggestion-duration",
                            bX: "{{duration}}"
                        }]
                    }, {
                        T: "div",
                        Z: "ytp-suggestion-title",
                        B: {
                            title: "{{hover_title}}"
                        },
                        bX: "{{title}}"
                    }, {
                        T: "div",
                        Z: "ytp-suggestion-author",
                        bX: "{{views_or_author}}"
                    }]
                });
                g.k(this, h);
                h.U5(this.suggestions.element);
                var m = h.yH("ytp-suggestion-link");
                g.Zd(m, "transitionDelay",
                    U.yJ / 20 + "s");
                this.W.S(m, "click", function(S) {
                    return function(f) {
                        var G = S.yJ,
                            I = W.suggestionData[G],
                            d = I.sessionData;
                        g.HB(W.api.V()) && W.api.L("web_player_log_click_before_generating_ve_conversion_params") ? (W.api.logClick(W.j[G].element), G = I.cN(), I = {}, g.bo(W.api, I), G = g.sL(G, I), g.sf(G, W.api, f)) : g.Vs(f, W.api, W.Y, d || void 0) && W.api.PY(I.videoId, d, I.playlistId)
                    }
                }(U));
                this.j.push(h)
            }
            g.k(this, this.next);
            this.next.U5(this.element);
            this.next.listen("click", this.rb, this);
            this.W.S(this.api, "videodatachange", this.onVideoDataChange);
            this.resize(this.api.xx().getPlayerSize());
            this.onVideoDataChange();
            this.show()
        },
        XFZ = function(K, W) {
            K.X && (!g.C(W, 4) && !g.C(W, 2) || g.C(W, 1024) ? K.X.hide() : K.X.show())
        },
        vHn = function() {
            return {
                T: "svg",
                B: {
                    height: "100%",
                    version: "1.1",
                    viewBox: "0 0 110 26",
                    width: "100%"
                },
                K: [{
                    T: "path",
                    Qt: !0,
                    Z: "ytp-svg-fill",
                    B: {
                        d: "M 16.68,.99 C 13.55,1.03 7.02,1.16 4.99,1.68 c -1.49,.4 -2.59,1.6 -2.99,3 -0.69,2.7 -0.68,8.31 -0.68,8.31 0,0 -0.01,5.61 .68,8.31 .39,1.5 1.59,2.6 2.99,3 2.69,.7 13.40,.68 13.40,.68 0,0 10.70,.01 13.40,-0.68 1.5,-0.4 2.59,-1.6 2.99,-3 .69,-2.7 .68,-8.31 .68,-8.31 0,0 .11,-5.61 -0.68,-8.31 -0.4,-1.5 -1.59,-2.6 -2.99,-3 C 29.11,.98 18.40,.99 18.40,.99 c 0,0 -0.67,-0.01 -1.71,0 z m 72.21,.90 0,21.28 2.78,0 .31,-1.37 .09,0 c .3,.5 .71,.88 1.21,1.18 .5,.3 1.08,.40 1.68,.40 1.1,0 1.99,-0.49 2.49,-1.59 .5,-1.1 .81,-2.70 .81,-4.90 l 0,-2.40 c 0,-1.6 -0.11,-2.90 -0.31,-3.90 -0.2,-0.89 -0.5,-1.59 -1,-2.09 -0.5,-0.4 -1.10,-0.59 -1.90,-0.59 -0.59,0 -1.18,.19 -1.68,.49 -0.49,.3 -1.01,.80 -1.21,1.40 l 0,-7.90 -3.28,0 z m -49.99,.78 3.90,13.90 .18,6.71 3.31,0 0,-6.71 3.87,-13.90 -3.37,0 -1.40,6.31 c -0.4,1.89 -0.71,3.19 -0.81,3.99 l -0.09,0 c -0.2,-1.1 -0.51,-2.4 -0.81,-3.99 l -1.37,-6.31 -3.40,0 z m 29.59,0 0,2.71 3.40,0 0,17.90 3.28,0 0,-17.90 3.40,0 c 0,0 .00,-2.71 -0.09,-2.71 l -9.99,0 z m -53.49,5.12 8.90,5.18 -8.90,5.09 0,-10.28 z m 89.40,.09 c -1.7,0 -2.89,.59 -3.59,1.59 -0.69,.99 -0.99,2.60 -0.99,4.90 l 0,2.59 c 0,2.2 .30,3.90 .99,4.90 .7,1.1 1.8,1.59 3.5,1.59 1.4,0 2.38,-0.3 3.18,-1 .7,-0.7 1.09,-1.69 1.09,-3.09 l 0,-0.5 -2.90,-0.21 c 0,1 -0.08,1.6 -0.28,2 -0.1,.4 -0.5,.62 -1,.62 -0.3,0 -0.61,-0.11 -0.81,-0.31 -0.2,-0.3 -0.30,-0.59 -0.40,-1.09 -0.1,-0.5 -0.09,-1.21 -0.09,-2.21 l 0,-0.78 5.71,-0.09 0,-2.62 c 0,-1.6 -0.10,-2.78 -0.40,-3.68 -0.2,-0.89 -0.71,-1.59 -1.31,-1.99 -0.7,-0.4 -1.48,-0.59 -2.68,-0.59 z m -50.49,.09 c -1.09,0 -2.01,.18 -2.71,.68 -0.7,.4 -1.2,1.12 -1.49,2.12 -0.3,1 -0.5,2.27 -0.5,3.87 l 0,2.21 c 0,1.5 .10,2.78 .40,3.78 .2,.9 .70,1.62 1.40,2.12 .69,.5 1.71,.68 2.81,.78 1.19,0 2.08,-0.28 2.78,-0.68 .69,-0.4 1.09,-1.09 1.49,-2.09 .39,-1 .49,-2.30 .49,-3.90 l 0,-2.21 c 0,-1.6 -0.2,-2.87 -0.49,-3.87 -0.3,-0.89 -0.8,-1.62 -1.49,-2.12 -0.7,-0.5 -1.58,-0.68 -2.68,-0.68 z m 12.18,.09 0,11.90 c -0.1,.3 -0.29,.48 -0.59,.68 -0.2,.2 -0.51,.31 -0.81,.31 -0.3,0 -0.58,-0.10 -0.68,-0.40 -0.1,-0.3 -0.18,-0.70 -0.18,-1.40 l 0,-10.99 -3.40,0 0,11.21 c 0,1.4 .18,2.39 .68,3.09 .49,.7 1.21,1 2.21,1 1.4,0 2.48,-0.69 3.18,-2.09 l .09,0 .31,1.78 2.59,0 0,-14.99 c 0,0 -3.40,.00 -3.40,-0.09 z m 17.31,0 0,11.90 c -0.1,.3 -0.29,.48 -0.59,.68 -0.2,.2 -0.51,.31 -0.81,.31 -0.3,0 -0.58,-0.10 -0.68,-0.40 -0.1,-0.3 -0.21,-0.70 -0.21,-1.40 l 0,-10.99 -3.40,0 0,11.21 c 0,1.4 .21,2.39 .71,3.09 .5,.7 1.18,1 2.18,1 1.39,0 2.51,-0.69 3.21,-2.09 l .09,0 .28,1.78 2.62,0 0,-14.99 c 0,0 -3.40,.00 -3.40,-0.09 z m 20.90,2.09 c .4,0 .58,.11 .78,.31 .2,.3 .30,.59 .40,1.09 .1,.5 .09,1.21 .09,2.21 l 0,1.09 -2.5,0 0,-1.09 c 0,-1 -0.00,-1.71 .09,-2.21 0,-0.4 .11,-0.8 .31,-1 .2,-0.3 .51,-0.40 .81,-0.40 z m -50.49,.12 c .5,0 .8,.18 1,.68 .19,.5 .28,1.30 .28,2.40 l 0,4.68 c 0,1.1 -0.08,1.90 -0.28,2.40 -0.2,.5 -0.5,.68 -1,.68 -0.5,0 -0.79,-0.18 -0.99,-0.68 -0.2,-0.5 -0.31,-1.30 -0.31,-2.40 l 0,-4.68 c 0,-1.1 .11,-1.90 .31,-2.40 .2,-0.5 .49,-0.68 .99,-0.68 z m 39.68,.09 c .3,0 .61,.10 .81,.40 .2,.3 .27,.67 .37,1.37 .1,.6 .12,1.51 .12,2.71 l .09,1.90 c 0,1.1 .00,1.99 -0.09,2.59 -0.1,.6 -0.19,1.08 -0.49,1.28 -0.2,.3 -0.50,.40 -0.90,.40 -0.3,0 -0.51,-0.08 -0.81,-0.18 -0.2,-0.1 -0.39,-0.29 -0.59,-0.59 l 0,-8.5 c .1,-0.4 .29,-0.7 .59,-1 .3,-0.3 .60,-0.40 .90,-0.40 z"
                    }
                }]
            }
        },
        mk = function(K, W) {
            var U = K.D.V();
            K = {
                adSource: "EMBEDS_AD_SOURCE_YOUTUBE",
                breakType: K.D.getCurrentTime() === 0 ? "EMBEDS_AD_BREAK_TYPE_PRE_ROLL" : K.D.getPlayerState() === 0 ? "EMBEDS_AD_BREAK_TYPE_POST_ROLL" : "EMBEDS_AD_BREAK_TYPE_MID_ROLL",
                embedUrl: g.$Me(K.D.V().loaderUrl),
                eventType: W,
                youtubeHost: g.Qq(K.D.V().M$) || ""
            };
            K.embeddedPlayerMode = U.hK;
            g.N_("embedsAdEvent", K)
        },
        qfj = function(K) {
            var W = K.api.getVideoData(),
                U = K.api.V().AS && !g.C(K.state, 2) && !K.api.getVideoData(1).Mk;
            W.mutedAutoplay || K.J7(U);
            K.api.logVisibility(K.element, U)
        },
        SX = function(K) {
            g.y.call(this, {
                T: "div",
                Z: "ytp-pause-overlay",
                B: {
                    tabIndex: "-1"
                }
            });
            var W = this;
            this.api = K;
            this.N = new g.Te(this);
            this.fade = new g.Wr(this, 1E3, !1, 100, function() {
                W.j.X = !1
            }, function() {
                W.j.X = !0
            });
            this.X = !1;
            this.expandButton = new g.y({
                T: "button",
                Hp: ["ytp-button", "ytp-expand"],
                bX: this.api.isEmbedsShortsMode() ? "Video ng\u1eafn kh\u00e1c" : "Video kh\u00e1c"
            });
            K.V().controlsType === "0" && g.$C(K.getRootNode(), "ytp-pause-overlay-controls-hidden");
            g.k(this, this.N);
            g.k(this, this.fade);
            var U = new g.y({
                T: "button",
                Hp: ["ytp-button", "ytp-collapse"],
                B: {
                    "aria-label": this.api.isEmbedsShortsMode() ? "\u1ea8n ph\u1ea7n video ng\u1eafn kh\u00e1c" : "\u1ea8n ph\u1ea7n Video kh\u00e1c"
                },
                K: [{
                    T: "div",
                    Z: "ytp-collapse-icon",
                    K: [g.KM()]
                }]
            });
            g.k(this, U);
            U.U5(this.element);
            U.listen("click", this.W, this);
            g.k(this, this.expandButton);
            this.expandButton.U5(this.element);
            this.expandButton.listen("click", this.U, this);
            this.j = new g.h8(K);
            g.k(this, this.j);
            this.j.X = !1;
            this.j.U5(this.element);
            this.api.isEmbedsShortsMode() ? this.api.createClientVe(this.element, this, 157212) : this.api.createClientVe(this.element, this, 172777);
            this.N.S(this.api, "presentingplayerstatechange", this.SV);
            this.N.S(this.api, "videodatachange", this.SV);
            this.hide()
        },
        xhn = function(K, W) {
            K.yH("ytp-error-content").style.paddingTop = "0px";
            var U = K.yH("ytp-error-content"),
                h = U.clientHeight;
            K.j && K.j.resize(W, W.height - h);
            U.style.paddingTop = (W.height - (K.j ? K.j.element.clientHeight : 0)) / 2 - h / 2 + "px"
        },
        Cef = function(K, W) {
            if (K.api.V().L("web_player_log_click_before_generating_ve_conversion_params"))
                for (var U = Math.floor(-K.scrollPosition / (K.N + K.X)), h = Math.min(U + K.columns, K.suggestionData.length) - 1; U <= h; U++) K.api.logVisibility(K.j[U].element, W)
        },
        fx = function(K) {
            g.y.call(this, {
                T: "div",
                Z: "ytp-muted-autoplay-endscreen-overlay",
                K: [{
                    T: "div",
                    Z: "ytp-muted-autoplay-end-panel",
                    K: [{
                        T: "button",
                        Hp: ["ytp-muted-autoplay-end-text", "ytp-button"],
                        bX: "{{text}}"
                    }]
                }]
            });
            this.api = K;
            this.W = this.yH("ytp-muted-autoplay-end-panel");
            this.X = !1;
            this.api.createClientVe(this.element, this, 52428);
            this.S(this.api, "presentingplayerstatechange", this.N);
            this.S(K, "onMutedAutoplayStarts", this.onMutedAutoplayStarts);
            this.listen("click", this.onClick);
            this.hide()
        },
        Kyt = function(K, W) {
            var U = K.api.V(),
                h;
            W.reason && (lob(W.reason) ? h = g.p7(W.reason) : h = g.UU(g.Rb(W.reason)), K.setContent(h, "content"));
            var m;
            W.subreason && (lob(W.subreason) ? m = g.p7(W.subreason) : m = g.UU(g.Rb(W.subreason)), K.setContent(m, "subreason"));
            if (W.proceedButton && W.proceedButton.buttonRenderer) {
                h = K.yH("ytp-error-content-wrap-subreason");
                W = W.proceedButton.buttonRenderer;
                var S = g.k$("A");
                if (W.text && W.text.simpleText && (m = W.text.simpleText, S.textContent = m, !Lif(h, m) && (!U.N || U.embedsErrorLinks))) {
                    var f;
                    U = (f = g.P(W == null ? void 0 : W.navigationEndpoint,
                        g.ok)) == null ? void 0 : f.url;
                    var G;
                    f = (G = g.P(W == null ? void 0 : W.navigationEndpoint, g.ok)) == null ? void 0 : G.target;
                    U && (S.setAttribute("href", U), K.api.createClientVe(S, K, 178424), K.S(S, "click", function(I) {
                        zR4(K, I, S)
                    }));
                    f && S.setAttribute("target", f);
                    G = g.k$("DIV");
                    G.appendChild(S);
                    h.appendChild(G)
                }
            }
        },
        pFI = function(K) {
            K.next.element.style.bottom = K.U + "px";
            K.previous.element.style.bottom = K.U + "px";
            var W = K.scrollPosition,
                U = K.containerWidth - K.suggestionData.length * (K.N + K.X);
            g.JM(K.element, "ytp-scroll-min", W >= 0);
            g.JM(K.element, "ytp-scroll-max", W <= U)
        },
        Ayh = function(K) {
            K.watermark || (K.watermark = new UA(K.api), g.k(K, K.watermark), K.watermark.U5(K.bottomButtons, 0), g.JM(K.watermark.element, "ytp-muted-autoplay-watermark", !0), K.j = new g.Wr(K.watermark, 0, !0, 100), g.k(K, K.j))
        },
        tU = function(K) {
            g.y.call(this, {
                T: "div",
                Hp: ["ytp-mobile-a11y-hidden-seek-button"],
                K: [{
                    T: "button",
                    Hp: ["ytp-mobile-a11y-hidden-seek-button-rewind", "ytp-button"],
                    B: {
                        "aria-label": "Tua l\u1ea1i 10 gi\u00e2y",
                        "aria-hidden": "false"
                    }
                }, {
                    T: "button",
                    Hp: ["ytp-mobile-a11y-hidden-seek-button-forward", "ytp-button"],
                    B: {
                        "aria-label": "Tua \u0111i 10 gi\u00e2y",
                        "aria-hidden": "false"
                    }
                }]
            });
            this.api = K;
            this.j = this.yH("ytp-mobile-a11y-hidden-seek-button-rewind");
            this.forwardButton = this.yH("ytp-mobile-a11y-hidden-seek-button-forward");
            this.api.createClientVe(this.j,
                this, 141902);
            this.api.createClientVe(this.forwardButton, this, 141903);
            this.S(this.api, "presentingplayerstatechange", this.dg);
            this.S(this.j, "click", this.X);
            this.S(this.forwardButton, "click", this.N);
            this.dg()
        },
        Wyb = function() {
            return {
                T: "svg",
                B: {
                    fill: "none",
                    height: "100%",
                    viewBox: "0 0 143 51",
                    width: "100%"
                },
                K: [{
                    T: "path",
                    B: {
                        d: "M58.37 41.39H62.79V27.23C62.79 23.03 62.69 18.69 62.43 13.59H62.93L63.69 16.89L68.67 41.39H73.17L78.07 16.89L78.89 13.59H79.37C79.15 18.45 79.03 22.89 79.03 27.23V41.39H83.45V8.79H75.95L73.41 20.81C72.35 25.85 71.51 32.01 71.01 35.19H70.73C70.33 31.95 69.49 25.81 68.41 20.85L65.81 8.79H58.37V41.39Z",
                        fill: "white"
                    }
                }, {
                    T: "path",
                    B: {
                        d: "M91.45 41.73C93.91 41.73 95.83 40.59 97.17 38.13H97.35L97.69 41.39H101.43V17.73H96.47V36.61C95.91 37.67 94.81 38.29 93.73 38.29C92.33 38.29 91.89 37.17 91.89 35.13V17.73H86.93V35.43C86.93 39.49 88.19 41.73 91.45 41.73Z",
                        fill: "white"
                    }
                }, {
                    T: "path",
                    B: {
                        d: "M110.79 41.89C115.15 41.89 117.75 39.83 117.75 35.65C117.75 31.79 115.93 30.39 111.85 27.47C109.67 25.91 108.39 25.09 108.39 22.95C108.39 21.47 109.27 20.61 110.89 20.61C112.69 20.61 113.33 21.81 113.33 25.29L117.45 25.07C117.77 19.57 115.71 17.23 110.97 17.23C106.57 17.23 104.17 19.27 104.17 23.45C104.17 27.25 105.97 28.83 108.93 31.03C111.89 33.23 113.55 34.53 113.55 36.23C113.55 37.75 112.51 38.61 111.01 38.61C109.13 38.61 108.11 36.97 108.29 34.41L104.21 34.49C103.51 39.25 105.89 41.89 110.79 41.89Z",
                        fill: "white"
                    }
                }, {
                    T: "path",
                    B: {
                        d: "M122.5 14.59C124.22 14.59 125.04 13.99 125.04 11.59C125.04 9.33 124.16 8.65 122.5 8.65C120.84 8.65 119.94 9.27 119.94 11.59C119.94 13.99 120.82 14.59 122.5 14.59ZM120.2 41.39H125V17.73H120.2V41.39Z",
                        fill: "white"
                    }
                }, {
                    T: "path",
                    B: {
                        d: "M134.95 41.79C137.31 41.79 138.63 41.49 139.71 40.47C141.31 39.01 141.97 36.63 141.85 33.11L137.41 32.87C137.41 36.87 136.81 38.45 135.03 38.45C133.13 38.45 132.77 36.45 132.77 31.97V27.21C132.77 22.41 133.23 20.51 135.07 20.51C136.67 20.51 137.29 22.01 137.29 26.47L141.65 26.15C141.97 22.93 141.59 20.29 140.09 18.83C139.01 17.77 137.37 17.29 135.15 17.29C129.65 17.29 127.75 20.73 127.75 28.03V31.17C127.75 38.47 129.23 41.79 134.95 41.79Z",
                        fill: "white"
                    }
                }, {
                    T: "path",
                    B: {
                        "clip-rule": "evenodd",
                        d: "M24.99 49C29.74 49.00 34.38 47.59 38.32 44.95C42.27 42.32 45.35 38.57 47.17 34.18C48.98 29.80 49.46 24.97 48.53 20.32C47.61 15.66 45.32 11.38 41.97 8.03C38.61 4.67 34.33 2.38 29.68 1.46C25.02 .53 20.20 1.01 15.81 2.82C11.43 4.64 7.68 7.71 5.04 11.66C2.40 15.61 1 20.25 1 25C0.99 28.15 1.61 31.27 2.82 34.18C4.03 37.09 5.79 39.74 8.02 41.97C10.25 44.19 12.89 45.96 15.81 47.17C18.72 48.37 21.84 49 24.99 49ZM24.99 12.36C27.49 12.36 29.94 13.10 32.02 14.48C34.10 15.87 35.72 17.84 36.68 20.15C37.64 22.46 37.89 25.01 37.41 27.46C36.92 29.91 35.72 32.17 33.95 33.94C32.18 35.70 29.93 36.91 27.48 37.40C25.02 37.89 22.48 37.64 20.17 36.68C17.86 35.72 15.88 34.10 14.50 32.02C13.11 29.94 12.37 27.50 12.37 25C12.37 21.65 13.70 18.44 16.07 16.07C18.43 13.70 21.64 12.37 24.99 12.36ZM24.99 10.43C22.11 10.43 19.29 11.28 16.89 12.88C14.50 14.48 12.63 16.76 11.53 19.42C10.42 22.09 10.13 25.02 10.70 27.85C11.26 30.67 12.65 33.27 14.69 35.31C16.73 37.35 19.32 38.73 22.15 39.30C24.98 39.86 27.91 39.57 30.57 38.46C33.23 37.36 35.51 35.49 37.11 33.09C38.71 30.70 39.57 27.88 39.56 25C39.56 23.08 39.19 21.19 38.46 19.42C37.72 17.65 36.65 16.04 35.30 14.69C33.94 13.34 32.34 12.27 30.57 11.53C28.80 10.80 26.90 10.43 24.99 10.43ZM32.63 24.99L20.36 32.09V17.91L32.63 24.99Z",
                        fill: "white",
                        "fill-rule": "evenodd"
                    }
                }]
            }
        },
        RRt = function(K) {
            K.Xo && K.j && (K.j.show(), K.N.start())
        },
        lob = function(K) {
            if (K.runs)
                for (var W = 0; W < K.runs.length; W++)
                    if (K.runs[W].navigationEndpoint) return !0;
            return !1
        },
        UCZ = function(K) {
            var W = g.kD_(K.D);
            W !== K.jV && (K.jV = W, K.U && (K.U.dispose(), K.U = null), K.N && (K.N.dispose(), K.N = null), K.W && (K.W.dispose(), K.W = null), K.X && (K.X.stop(), K.X.dispose(), K.X = null), W && (W = g.dK(K.D), K.D.isEmbedsShortsMode() && (K.W = new g.y({
                T: "div",
                Z: "ytp-pause-overlay-backdrop",
                B: {
                    tabIndex: "-1"
                }
            }), g.k(K, K.W), g.HW(K.D, K.W.element, 4), K.X = new g.Wr(K.W, 1E3, !1, 100), g.k(K, K.X), K.W.hide()), K.U = new g.y({
                T: "div",
                Z: "ytp-pause-overlay-container",
                B: {
                    tabIndex: "-1"
                }
            }), g.k(K, K.U), K.N = new SX(K.D, W), g.k(K, K.N), K.N.U5(K.U.element), g.HW(K.D, K.U.element,
                4), XFZ(K, K.D.getPlayerStateObject())))
        },
        zR4 = function(K, W, U) {
            W.preventDefault();
            K.api.logClick(U);
            W = U.getAttribute("href");
            U = {};
            g.Zm(K.api, "addEmbedsConversionTrackingParams", [U]);
            W = g.Tb(U) ? W : g.sL(W, U);
            g.xv(window, W)
        },
        Lif = function(K, W) {
            K = g.K4("A", K);
            for (var U = 0; U < K.length; U++)
                if (K[U].textContent === W) return !0;
            return !1
        },
        h$j = function(K) {
            g.wP.call(this, K);
            this.D = K;
            this.j = new g.Te(this);
            this.X = null;
            this.Y = !1;
            this.countdownTimer = null;
            this.jV = !1;
            Z_F(this);
            g.k(this, this.j);
            this.load()
        },
        b_F = function(K) {
            if (!K.X) {
                var W = Math.min((0, g.AI)() - K.W, K.N);
                var U = K.N - W;
                W = K.N === 0 ? 0 : Math.max(U / K.N, 0);
                U = Math.round(U / 1E3);
                K.G.setAttribute("stroke-dashoffset", "" + -211 * (W + 1));
                K.updateValue("duration", U);
                W <= 0 && K.j ? K.stopTimer() : K.j && K.j.start()
            }
        };
    g.V(NrN, g.y);
    g.H = NrN.prototype;
    g.H.hide = function() {
        this.G = !0;
        g.y.prototype.hide.call(this);
        Cef(this, !1)
    };
    g.H.show = function() {
        this.G = !1;
        g.y.prototype.show.call(this);
        Cef(this, !0)
    };
    g.H.isHidden = function() {
        return this.G
    };
    g.H.rb = function() {
        this.scrollTo(this.scrollPosition - this.containerWidth)
    };
    g.H.uD = function() {
        this.scrollTo(this.scrollPosition + this.containerWidth)
    };
    g.H.resize = function(K, W) {
        var U = this.api.V(),
            h = 16 / 9,
            m = K.width >= 650,
            S = K.width < 480 || K.height < 290,
            f = Math.min(this.suggestionData.length, this.j.length);
        if (Math.min(K.width, K.height) <= 150 || f === 0 || !U.Ny) this.hide();
        else {
            var G;
            if (m) {
                var I = G = 28;
                this.X = 16
            } else this.X = I = G = 8;
            if (S) {
                var d = 6;
                m = 14;
                var J = 12;
                S = 24;
                U = 12
            } else d = 8, m = 18, J = 16, S = 36, U = 16;
            K = K.width - (48 + G + I);
            G = Math.ceil(K / 150);
            G = Math.min(3, G);
            I = K / G - this.X;
            var e = Math.floor(I / h);
            W && e + 100 > W && I > 50 && (e = Math.max(W, 50 / h), G = Math.ceil(K / (h * (e - 100) + this.X)), I = K / G - this.X,
                e = Math.floor(I / h));
            I < 50 || g.Gj(this.api) ? this.hide() : this.show();
            for (W = 0; W < f; W++) {
                h = this.j[W];
                var E = h.yH("ytp-suggestion-image");
                E.style.width = I + "px";
                E.style.height = e + "px";
                h.yH("ytp-suggestion-title").style.width = I + "px";
                h.yH("ytp-suggestion-author").style.width = I + "px";
                h = h.yH("ytp-suggestion-duration");
                h.style.display = h && I < 100 ? "none" : ""
            }
            f = m + d + J + 4;
            this.U = f + U + (e - S) / 2;
            this.suggestions.element.style.height = e + f + "px";
            this.N = I;
            this.containerWidth = K;
            this.columns = G;
            this.scrollPosition = 0;
            this.suggestions.element.scrollLeft = -0;
            pFI(this)
        }
    };
    g.H.onVideoDataChange = function() {
        var K = this.api.getVideoData(),
            W = this.api.V();
        this.Y = K.Mk ? !1 : W.W;
        K.suggestions ? this.suggestionData = g.yb(K.suggestions, function(U) {
            return U && !U.playlistId
        }) : this.suggestionData.length = 0;
        oHh(this);
        K.Mk ? this.title.update({
            title: g.BB("Video kh\u00e1c t\u1eeb $DNI_RELATED_CHANNEL", {
                DNI_RELATED_CHANNEL: K.author
            })
        }) : this.title.update({
            title: "Xem th\u00eam video tr\u00ean YouTube"
        })
    };
    g.H.scrollTo = function(K) {
        K = g.Jk(K, this.containerWidth - this.suggestionData.length * (this.N + this.X), 0);
        this.J.start(this.scrollPosition, K, 1E3);
        this.scrollPosition = K;
        pFI(this);
        Cef(this, !0)
    };
    g.V(hU, g.To);
    hU.prototype.show = function() {
        g.To.prototype.show.call(this);
        xhn(this, this.api.xx().getPlayerSize())
    };
    hU.prototype.resize = function(K) {
        g.To.prototype.resize.call(this, K);
        this.j && (xhn(this, K), g.JM(this.element, "related-on-error-overlay-visible", !this.j.isHidden()))
    };
    hU.prototype.X = function(K) {
        g.To.prototype.X.call(this, K);
        var W = this.api.getVideoData();
        if (W.j5 || W.playerErrorMessageRenderer)(K = W.j5) ? Kyt(this, K) : W.playerErrorMessageRenderer && Kyt(this, W.playerErrorMessageRenderer);
        else {
            var U;
            K.hF && (W.I0 ? lob(W.I0) ? U = g.p7(W.I0) : U = g.UU(g.Rb(W.I0)) : U = g.UU(K.hF), this.setContent(U, "subreason"))
        }
    };
    g.V(PeO, g.y);
    g.H = PeO.prototype;
    g.H.onVideoDataChange = function() {
        var K = this.api.getVideoData(),
            W = vHn(),
            U = 96714;
        g.oz(K) ? (W = Wyb(), U = 216165, g.$C(this.element, "ytp-music-impression-link")) : g.WR(this.element, "ytp-music-impression-link");
        this.updateValue("logoSvg", W);
        this.api.hasVe(this.element) && this.api.destroyVe(this.element);
        this.api.createClientVe(this.element, this, U)
    };
    g.H.dg = function() {
        this.api.getPlayerStateObject().isCued() || (this.hide(), this.api.logVisibility(this.element, !1))
    };
    g.H.bU = function() {
        var K = this.api.getVideoData(),
            W = this.api.V(),
            U = this.api.getVideoData().Mk,
            h = !W.Ny,
            m = this.j.je(),
            S = W.N;
        W.AS || m || U || h || S || this.api.isEmbedsShortsMode() || !K.videoId ? (this.hide(), this.api.logVisibility(this.element, !1)) : (K = VAj(this), this.updateValue("url", K), this.show())
    };
    g.H.onClick = function(K) {
        this.api.L("web_player_log_click_before_generating_ve_conversion_params") && this.api.logClick(this.element);
        var W = VAj(this);
        g.sf(W, this.api, K);
        this.api.L("web_player_log_click_before_generating_ve_conversion_params") || this.api.logClick(this.element)
    };
    g.H.show = function() {
        this.api.getPlayerStateObject().isCued() && (g.y.prototype.show.call(this), this.api.hasVe(this.element) && this.api.logVisibility(this.element, !0))
    };
    g.V(tU, g.y);
    tU.prototype.dg = function() {
        var K = this.api.getPlayerStateObject();
        !this.api.gS() || g.C(K, 2) && g.si(this.api) || g.C(K, 64) ? (this.api.logVisibility(this.j, !1), this.api.logVisibility(this.forwardButton, !1), this.hide()) : (this.show(), this.api.logVisibility(this.j, !0), this.api.logVisibility(this.forwardButton, !0))
    };
    tU.prototype.X = function() {
        this.api.seekBy(-10 * this.api.getPlaybackRate(), void 0, void 0, 83);
        this.api.logClick(this.j)
    };
    tU.prototype.N = function() {
        this.api.seekBy(10 * this.api.getPlaybackRate(), void 0, void 0, 82);
        this.api.logClick(this.forwardButton)
    };
    g.V(fx, g.y);
    fx.prototype.N = function() {
        var K = this.api.getPlayerStateObject(),
            W = this.api.getVideoData();
        g.JM(this.element, "ytp-shorts-mode", this.api.isEmbedsShortsMode());
        !W.mutedAutoplay || W.limitedPlaybackDurationInSeconds === 0 && W.endSeconds === 0 && W.mutedAutoplayDurationMode === 2 || (g.C(K, 2) && !this.Xo ? (this.show(), this.j || (this.j = new g.AS(this.api), g.k(this, this.j), this.j.U5(this.W, 0), this.j.show()), K = this.api.getVideoData(), this.updateValue("text", K.r7), g.JM(this.element, "ytp-muted-autoplay-show-end-panel", !0), this.api.logVisibility(this.element,
            this.Xo), this.api.Ov("onMutedAutoplayEnds")) : this.hide())
    };
    fx.prototype.onClick = function() {
        if (!this.X) {
            this.j && (this.j.QH(), this.j = null);
            g.JM(this.api.getRootNode(), "ytp-muted-autoplay", !1);
            var K = this.api.getVideoData(),
                W = this.api.getCurrentTime();
            MAO(K);
            this.api.loadVideoById(K.videoId, W);
            this.api.BL();
            this.api.logClick(this.element);
            this.hide();
            this.X = !0
        }
    };
    fx.prototype.onMutedAutoplayStarts = function() {
        this.X = !1;
        this.j && (this.j.QH(), this.j = null)
    };
    g.V(UA, g.y);
    g.H = UA.prototype;
    g.H.onStateChange = function(K) {
        this.Bl(K.state)
    };
    g.H.Bl = function(K) {
        this.state !== K && (this.state = K);
        qfj(this)
    };
    g.H.onVideoDataChange = function() {
        var K = this.api.V();
        K.N && g.$C(this.element, "ytp-no-hover");
        var W = this.api.getVideoData();
        W.videoId && !K.N ? (K = this.api.getVideoUrl(!0, !1, !1, !0), this.updateValue("url", K), this.j || (this.j = this.listen("click", this.onClick))) : this.j && (this.updateValue("url", null), this.GK(this.j), this.j = null);
        K = vHn();
        var U = 76758;
        g.oz(W) && (K = Wyb(), U = 216164);
        this.updateValue("logoSvg", K);
        this.api.hasVe(this.element) && this.api.destroyVe(this.element);
        this.api.createClientVe(this.element, this,
            U);
        qfj(this)
    };
    g.H.onClick = function(K) {
        this.api.L("web_player_log_click_before_generating_ve_conversion_params") && this.api.logClick(this.element);
        var W = this.api.getVideoUrl(!g.oZ(K), !1, !0, !0);
        if (this.api.L("web_player_log_click_before_generating_ve_conversion_params")) {
            var U = {};
            g.Zm(this.api, "addEmbedsConversionTrackingParams", [U]);
            W = g.sL(W, U)
        }
        g.sf(W, this.api, K);
        this.api.L("web_player_log_click_before_generating_ve_conversion_params") || this.api.logClick(this.element)
    };
    g.H.IW = function(K) {
        if ((K = K.width < 480) && !this.X || !K && this.X) {
            var W = new g.y(vHn()),
                U = this.yH("ytp-watermark");
            g.JM(U, "ytp-watermark-small", K);
            g.QG(U);
            W.U5(U);
            this.X = K
        }
    };
    g.V(yy3, g.y);
    g.H = yy3.prototype;
    g.H.a$ = function() {
        var K = this.api.getPlayerStateObject();
        !this.api.getVideoData().mutedAutoplay || g.C(K, 2) ? this.hide() : this.Xo || (g.y.prototype.show.call(this), this.api.logVisibility(this.element, this.Xo))
    };
    g.H.oxx = function() {
        this.j && this.j.hide()
    };
    g.H.onAutoplayBlocked = function() {
        this.hide();
        MAO(this.api.getVideoData())
    };
    g.H.onClick = function() {
        if (!this.X) {
            g.JM(this.api.getRootNode(), "ytp-muted-autoplay", !1);
            var K = this.api.getVideoData(),
                W = this.api.getCurrentTime();
            MAO(K);
            this.api.loadVideoById(K.videoId, W);
            this.api.BL();
            this.api.logClick(this.element);
            this.api.Ov("onMutedAutoplayEnds");
            this.X = !0
        }
    };
    g.H.onMutedAutoplayEnds = function() {
        this.watermark && (this.watermark.QH(), this.watermark = null)
    };
    g.V(SX, g.y);
    SX.prototype.hide = function() {
        g.WR(this.api.getRootNode(), "ytp-expand-pause-overlay");
        g.y.prototype.hide.call(this)
    };
    SX.prototype.W = function() {
        this.X = !0;
        g.WR(this.api.getRootNode(), "ytp-expand-pause-overlay");
        this.api.isEmbedsShortsMode() && this.api.logVisibility(this.element, !1);
        this.expandButton.focus()
    };
    SX.prototype.U = function() {
        this.X = !1;
        g.$C(this.api.getRootNode(), "ytp-expand-pause-overlay");
        this.api.isEmbedsShortsMode() && this.api.logVisibility(this.element, !0);
        this.focus()
    };
    SX.prototype.SV = function() {
        var K = this.api.getPlayerStateObject();
        g.C(K, 1) || g.C(K, 16) || g.C(K, 32) || (!g.C(K, 4) || g.C(K, 2) || g.C(K, 1024) ? (this.X || this.api.logVisibility(this.element, !1), this.fade.hide()) : this.j.hasSuggestions() && (this.X || (g.$C(this.api.getRootNode(), "ytp-expand-pause-overlay"), g.Bo(this.j), this.j.show(), this.api.logVisibility(this.element, !0)), this.fade.show()))
    };
    g.V(jX, g.y);
    jX.prototype.show = function() {
        g.y.prototype.show.call(this);
        this.api.logVisibility(this.element, !0)
    };
    jX.prototype.stopTimer = function() {
        this.j && (this.j.dispose(), this.j = null, this.X = !1)
    };
    jX.prototype.QH = function() {
        this.stopTimer();
        g.y.prototype.QH.call(this)
    };
    g.V(h$j, g.wP);
    g.H = h$j.prototype;
    g.H.tZ = function() {
        return !1
    };
    g.H.create = function() {
        var K = this.D.V(),
            W = g.dK(this.D),
            U, h = (U = this.D.getVideoData()) == null ? void 0 : U.clientPlaybackNonce;
        h && g.y2({
            clientPlaybackNonce: h
        });
        K.JK && !K.disableOrganicUi && UCZ(this);
        var m;
        (m = K.getWebPlayerContextConfig()) != null && m.embedsEnableEmc3ds || (this.J = new yy3(this.D), g.k(this, this.J), g.HW(this.D, this.J.element, 4), this.uX = new fx(this.D), g.k(this, this.uX), g.HW(this.D, this.uX.element, 4));
        K.AS && (this.watermark = new UA(this.D), g.k(this, this.watermark), g.HW(this.D, this.watermark.element, 8));
        W && !K.disableOrganicUi && (this.G = new PeO(this.D, W), g.k(this, this.G), g.HW(this.D, this.G.element, 8), this.D.isMutedByEmbedsMutedAutoplay() && (this.onMutedAutoplayStarts(), this.G.hide()));
        K.X && !K.disableOrganicUi && (this.Ms = new tU(this.D), g.k(this, this.Ms), g.HW(this.D, this.Ms.element, 4));
        this.j.S(this.D, "appresize", this.IW);
        this.j.S(this.D, "presentingplayerstatechange", this.dg);
        this.j.S(this.D, "videodatachange", this.onVideoDataChange);
        this.j.S(this.D, "videoplayerreset", this.onReset);
        this.j.S(this.D, "onMutedAutoplayStarts",
            this.onMutedAutoplayStarts);
        this.j.S(this.D, "onAdStart", this.onAdStart);
        this.j.S(this.D, "onAdComplete", this.onAdComplete);
        this.j.S(this.D, "onAdSkip", this.onAdSkip);
        this.j.S(this.D, "onAdStateChange", this.onAdStateChange);
        if (this.Y = g.bX(g.mC(K))) this.countdownTimer = new jX(this.D), g.k(this, this.countdownTimer), g.HW(this.D, this.countdownTimer.element, 4), this.countdownTimer.hide(), this.j.S(this.D, g.$w("embeds"), this.onCueRangeEnter), this.j.S(this.D, g.g8("embeds"), this.onCueRangeExit);
        this.uY(this.D.getPlayerStateObject());
        var S, f;
        ((S = this.D.V().getWebPlayerContextConfig()) == null ? 0 : (f = S.embedsHostFlags) == null ? 0 : f.allowOverridingVisitorDataPlayerVars) && (K = g.TA("IDENTITY_MEMENTO")) && this.D.Bd("onMementoChange", K)
    };
    g.H.onCueRangeEnter = function(K) {
        K.getId() === "countdown timer" && this.countdownTimer && (this.countdownTimer.show(), sZ3(this.countdownTimer))
    };
    g.H.onCueRangeExit = function(K) {
        K.getId() === "countdown timer" && this.countdownTimer && (this.countdownTimer.stopTimer(), this.countdownTimer.hide())
    };
    g.H.IW = function() {
        var K = this.D.xx().getPlayerSize();
        this.Zp && this.Zp.resize(K)
    };
    g.H.onReset = function() {
        Z_F(this)
    };
    g.H.dg = function(K) {
        this.uY(K.state)
    };
    g.H.uY = function(K) {
        g.C(K, 128) ? (this.Zp || (this.Zp = new hU(this.D), g.k(this, this.Zp), g.HW(this.D, this.Zp.element, 4)), this.Zp.X(K.wi), this.Zp.show(), g.$C(this.D.getRootNode(), "ytp-embed-error")) : this.Zp && (this.Zp.dispose(), this.Zp = null, g.WR(this.D.getRootNode(), "ytp-embed-error"));
        if (this.countdownTimer && this.countdownTimer.j)
            if (g.C(K, 64)) this.countdownTimer.hide(), this.countdownTimer.stopTimer();
            else if (K.isPaused()) {
            var W = this.countdownTimer;
            W.X || (W.X = !0, W.U = (0, g.AI)())
        } else K.isPlaying() && this.countdownTimer.X &&
            (W = this.countdownTimer, W.X && (W.W += (0, g.AI)() - W.U, W.X = !1, b_F(W)));
        XFZ(this, K)
    };
    g.H.onMutedAutoplayStarts = function() {
        this.D.getVideoData().mutedAutoplay && this.J && g.JM(this.D.getRootNode(), "ytp-muted-autoplay", !0)
    };
    g.H.onVideoDataChange = function(K, W) {
        var U = this.Ar !== W.videoId;
        K = !U && K === "dataloaded";
        var h = {
            isShortsModeEnabled: !!this.D.isEmbedsShortsMode()
        };
        g.N_("embedsVideoDataDidChange", {
            clientPlaybackNonce: W.clientPlaybackNonce,
            isReload: K,
            runtimeEnabledFeatures: h
        });
        U && (this.Ar = W.videoId, this.countdownTimer && (this.countdownTimer.show(), this.countdownTimer.hide()), this.Y && (this.D.L5("embeds"), W.isAd() || W.limitedPlaybackDurationInSeconds < 5 || g.Gj(this.D) || (W = Math.max((W.startSeconds + W.limitedPlaybackDurationInSeconds -
            5) * 1E3, 0), W = new g.g0(W, W + 5E3, {
            id: "countdown timer",
            namespace: "embeds"
        }), this.D.lG([W]))), this.D.V().JK && !this.D.V().disableOrganicUi && (Z_F(this), UCZ(this)));
        this.D.V().N && this.N && this.N.detach()
    };
    g.H.onAdStart = function() {
        mk(this, "EMBEDS_AD_EVENT_TYPE_AD_STARTED")
    };
    g.H.onAdComplete = function() {
        mk(this, "EMBEDS_AD_EVENT_TYPE_AD_COMPLETED")
    };
    g.H.onAdSkip = function() {
        mk(this, "EMBEDS_AD_EVENT_TYPE_AD_SKIPPED")
    };
    g.H.onAdStateChange = function(K) {
        K === 2 && mk(this, "EMBEDS_AD_EVENT_TYPE_AD_PAUSED")
    };
    g.Q5("embed", h$j);
})(_yt_player);